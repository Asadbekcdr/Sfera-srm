# Security release notes

**Status: BLOCKED for production.** The following are targeted code changes, not a complete security certification.

## Verified in the canonical code and tests

The backend continues to use Spring Security, method authorization and JWT. JWT filtering no longer installs a principal for disabled accounts, and inactive students are excluded from phone lookup. Task services now check principal scope on list/detail/mutations and teacher assignments; a teacher cannot move a task to another teacher’s group or manipulate another teacher’s task. Attendance and mark detail reads use the authenticated principal. Teacher mark writes are limited to their own groups, and a mark cannot be reassigned to a student in another teacher’s group. Attendance SSE emitters and broadcasts are group-scoped. Credentialed CORS now rejects wildcard or malformed origin configuration and requires explicit HTTP(S) origins. The attendance bulk adapter delegates to the same authorized service as the original endpoint. Regression tests for these behaviors are included in the final PostgreSQL-backed suite (29 tests on each fixture).

## Not closed / not fully verified

The frontend token remains accessible to JavaScript; the audit requirement for a backend-set HttpOnly/Secure session or equivalent is unmet. Clerk routes/dependency coexist with the custom JWT flow. Refresh rotation, logout/session revocation, password reset/recovery and multi-device session management remain absent or unverified; brute-force/rate limits are not verified. The full role/permission matrix, Parent-versus-Student mapping, admin/super-admin boundary and academy/tenant isolation across every route lack comprehensive tests. Production CORS allowlist values, preflight behavior, secret rotation/manager, deployment profile and CSRF/session policy need production-specific validation.

File upload/download security was not audited against a real storage service (MIME/content signature, malware, authorization and retention). Telegram behavior and real multi-client SSE delivery were not exercised in deployment. Audit-event actor/tenant/before-after completeness, schema constraints, concurrency and operational controls remain open. Targeted ownership unit tests are not substitutes for role×resource×tenant integration tests. See `RELEASE_AUDIT.md`, `RELEASE_TEST_REPORT.md` and `SUPPLEMENTAL_AUDIT_REVIEW.md`; passing the included tests is not a security approval.
