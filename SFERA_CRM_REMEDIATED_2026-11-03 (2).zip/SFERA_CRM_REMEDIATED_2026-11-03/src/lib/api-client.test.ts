import { afterEach, describe, expect, it, vi } from 'vitest'
import { apiClient, backendEnabledForEnvironment, postApiData } from './api-client'

describe('api-client backend route aliases', () => {
  afterEach(() => vi.restoreAllMocks())

  it('cannot disable the backend in production builds', () => {
    expect(backendEnabledForEnvironment(true, 'false')).toBe(true)
    expect(backendEnabledForEnvironment(false, 'false')).toBe(false)
  })

  it('posts bulk attendance to the canonical backend endpoint', async () => {
    const post = vi.spyOn(apiClient, 'post').mockResolvedValue({
      data: { success: true, message: 'saved', data: null },
    } as never)

    await postApiData('/api/v1/attendance/bulk', {
      groupId: 7,
      sessionDate: '2026-10-30',
      records: [{ studentId: 22, status: 'KELDI' }],
    })

    expect(post).toHaveBeenCalledWith('/attendance/bulk', expect.objectContaining({
      groupId: 7,
      sessionDate: '2026-10-30',
    }))
  })
})
