import axios from 'axios'
import { useAuthStore } from '@/stores/auth-store'

export const apiClient = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '/',
  timeout: 15_000,
  headers: { 'Content-Type': 'application/json' },
})

apiClient.interceptors.request.use((config) => {
  const token = useAuthStore.getState().auth.accessToken
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (axios.isAxiosError(error) && error.response?.status === 401) useAuthStore.getState().auth.reset()
    return Promise.reject(error)
  }
)

/** Frontend aliaslarini Sfera-Education Spring route'lariga yo'naltiradi. */
function backendPath(path: string) {
  const aliases: Array<[RegExp, string]> = [
    [/^\/api\/v1\/auth\/login$/, '/auth/login'],
    [/^\/api\/v1\/auth\/(.*)$/, '/auth/$1'],
    [/^\/api\/v1\/groups\/(\d+)\/students$/, '/group/$1'],
    [/^\/api\/v1\/groups$/, '/group/all'],
    [/^\/api\/v1\/groups\/(\d+)$/, '/group/$1'],
    [/^\/api\/v1\/students$/, '/student'],
    [/^\/api\/v1\/students\/(.*)$/, '/student/$1'],
    [/^\/api\/v1\/teachers$/, '/teacher'],
    [/^\/api\/v1\/teachers\/(.*)$/, '/teacher/$1'],
    [/^\/api\/v1\/dashboard\/summary$/, '/dashboard'],
    [/^\/api\/v1\/dashboard\/teacher$/, '/dashboard/teacher'],
    [/^\/teacher\/dashboard$/, '/dashboard/teacher'],
    [/^\/teacher\/groups$/, '/group/all'],
    [/^\/api\/v1\/attendance\/bulk$/, '/attendance/bulk'],
    [/^\/api\/v1\/attendance$/, '/attendance'],
    [/^\/api\/v1\/tasks$/, '/tasks'],
    [/^\/api\/v1\/tasks\/(.*)$/, '/tasks/$1'],
  ]
  for (const [pattern, replacement] of aliases) if (pattern.test(path)) return path.replace(pattern, replacement)
  return path
}

function unwrap<T>(payload: T | { data: T }) {
  if (payload && typeof payload === 'object' && 'data' in payload) return payload.data
  return payload as T
}

function tokenUser(token: string) {
  try {
    const encoded = token.split('.')[1]
    const claims = JSON.parse(atob(encoded.replace(/-/g, '+').replace(/_/g, '/')))
    const rawRole = String(claims.role || claims.authorities?.[0] || '')
    const roleKey = rawRole.replace(/^ROLE_/, '').toUpperCase()
    const role = roleKey === 'SUPER_ADMIN' ? 'Super Admin' : roleKey === 'ADMIN' ? 'Admin' : roleKey === 'TEACHER' ? 'Teacher' : roleKey === 'PARENT' ? 'Student' : roleKey === 'STUDENT' ? 'Student' : roleKey === 'MANAGER' ? 'Manager' : roleKey === 'FINANCE' ? 'Finance' : roleKey === 'DIRECTOR' ? 'Director' : 'Unknown'
    return { accountNo: String(claims.sub || ''), name: String(claims.name || claims.fullName || ''), email: String(claims.email || ''), role: [role], exp: Number(claims.exp || 0) * 1000 }
  } catch {
    return { accountNo: '', name: '', email: '', role: ['User'], exp: 0 }
  }
}

export async function getApiData<T>(path: string, params?: Record<string, string | undefined>) {
  const response = await apiClient.get<T | { data: T }>(backendPath(path), { params })
  const payload = unwrap(response.data) as unknown
  if (path.startsWith('/api/v1/finance/payments') && payload && typeof payload === 'object' && 'items' in payload) {
    const page = payload as { items?: Array<{ status?: string; paidAt?: string | null }> }
    return { ...page, items: (page.items ?? []).map((item) => ({ ...item, status: item.status === 'PENDING_APPROVAL' || item.status === 'PENDING' ? 'pending_approval' : item.status === 'APPROVED' ? 'approved' : item.status?.toLowerCase(), paidAt: item.paidAt ?? '' })) } as T
  }
  if (/^\/api\/v1\/groups\/\d+\/students$/.test(path) && payload && typeof payload === 'object' && 'students' in payload) {
    const students = (payload as { students?: Array<{ id?: number | string; fullName?: string }> }).students ?? []
    return students.map((student) => {
      const [firstName = '', ...lastNameParts] = String(student.fullName ?? '').trim().split(/\s+/)
      return { studentId: String(student.id ?? ''), firstName, lastName: lastNameParts.join(' ') }
    }) as T
  }
  return payload as T
}

export const backendEnabledForEnvironment = (production: boolean, configured?: string) =>
  production || configured !== 'false'

export const isBackendEnabled = () =>
  backendEnabledForEnvironment(import.meta.env.PROD, import.meta.env.VITE_API_ENABLED)

export type ManagerDashboardApi = { totalStudents: number; totalGroups: number; totalTeachers: number; pendingApplications: number; monthlyRevenue: number; pendingDebts: number; averageAttendance: number; revenueTrend?: Array<{ label: string; revenue: number }> }
export type FinancePaymentsApi = { items: Array<{ id: string; invoiceId: string; studentId: string; studentFirstName: string; studentLastName: string; groupName?: string | null; courseName?: string | null; invoiceNumber?: string | null; amount: number; paymentMethod: string; referenceNumber?: string | null; receivedBy?: string | null; receivedByFirstName?: string | null; receivedByLastName?: string | null; rejectionReason?: string | null; status: string; paidAt: string; createdAt?: string }>; page: number; pageSize: number; total: number; totalPages: number }
export type TeacherDashboardApi = { totalGroups: number; totalStudents: number; averageGrade: number; assignmentCompletionRate: number; attendanceRate: number }
export type FinanceSummaryApi = { currency: string; periodDays: number; invoicesIssued: number | null; collectedRevenue: number; outstandingBalance: number | null; overdueBalance: number | null; totalRefunded: number; netRevenue: number; collectionRate: number | null; counts: { invoices: number | null; pendingInvoices: number | null; partiallyPaidInvoices: number | null; overdueInvoices: number | null; payments: number; pendingPayments: number; approvedPayments: number; refunds: number } }
export const formatApiCurrency = (value: number | null, locale = 'uz-UZ') => value == null ? '—' : `${new Intl.NumberFormat(locale).format(value)} UZS`
export const apiErrorMessage = (error: unknown) => axios.isAxiosError(error) ? (!error.response ? 'API serveriga ulanib bo‘lmadi. Backend va PostgreSQL xizmatini tekshiring.' : error.response.status === 401 ? 'Sessiya tugagan. Iltimos, qayta kiring.' : error.response.status === 403 ? 'Bu amal uchun ruxsat mavjud emas.' : error.response.status === 404 ? 'So‘ralgan backend resursi topilmadi.' : error.response.status >= 500 ? 'Server vaqtincha ishlamayapti.' : 'Yuborilgan ma’lumotlarni tekshiring.') : error instanceof Error ? error.message : 'API serveriga ulanib bo‘lmadi.'

export async function postApiData<T>(path: string, body: unknown): Promise<T> {
  const normalized = backendPath(path)
  if (normalized === '/auth/login' && body && typeof body === 'object') {
    const input = body as { phone?: string; email?: string; password?: string }
    const response = await apiClient.post<{ data: string }>('/auth/login', { phone: input.phone || input.email, password: input.password })
    const token = unwrap(response.data)
    return { accessToken: token, user: tokenUser(token) } as T
  }
  const response = await apiClient.post<T | { data: T }>(normalized, body)
  return unwrap(response.data)
}

export async function putApiData<T>(path: string, body: unknown): Promise<T> {
  const response = await apiClient.put<T | { data: T }>(backendPath(path), body)
  return unwrap(response.data)
}

export async function deleteApiData<T = unknown>(path: string): Promise<T> {
  const response = await apiClient.delete<T | { data: T }>(backendPath(path))
  return unwrap(response.data)
}
