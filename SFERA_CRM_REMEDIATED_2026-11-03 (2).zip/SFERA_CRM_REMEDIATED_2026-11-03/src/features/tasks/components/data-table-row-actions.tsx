import { DotsHorizontalIcon } from '@radix-ui/react-icons'
import { type Row } from '@tanstack/react-table'
import { Trash2 } from 'lucide-react'
import { toast } from 'sonner'
import { apiErrorMessage } from '@/lib/api-client'
import { Button } from '@/components/ui/button'
import { useLanguage } from '@/context/language-provider'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { labels } from '../data/data'
import { taskSchema } from '../data/schema'
import { useTasks } from './tasks-provider'

type DataTableRowActionsProps<TData> = {
  row: Row<TData>
}

export function DataTableRowActions<TData>({
  row,
}: DataTableRowActionsProps<TData>) {
  const task = taskSchema.parse(row.original)

  const { setOpen, setCurrentRow, updateTask } = useTasks()
  const { language } = useLanguage()
  const english = language === 'en'

  return (
    <DropdownMenu modal={false}>
      <DropdownMenuTrigger asChild>
        <Button
          variant='ghost'
          className='flex h-8 w-8 p-0 data-[state=open]:bg-muted'
        >
          <DotsHorizontalIcon className='h-4 w-4' />
          <span className='sr-only'>{english ? 'Open menu' : 'Menyuni ochish'}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align='end' className='w-40'>
        <DropdownMenuItem
          onClick={() => {
            setCurrentRow(task)
            setOpen('update')
          }}
        >
          {english ? 'Edit' : 'Tahrirlash'}
        </DropdownMenuItem>
        <DropdownMenuItem disabled>{english ? 'Make a copy' : 'Nusxa olish'}</DropdownMenuItem>
        <DropdownMenuItem disabled>{english ? 'Favorite' : 'Sevimlilarga qo‘shish'}</DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuSub>
          <DropdownMenuSubTrigger>{english ? 'Labels' : 'Teglar'}</DropdownMenuSubTrigger>
          <DropdownMenuSubContent>
            <DropdownMenuRadioGroup
              value={task.label}
              onValueChange={async (value) => {
                try {
                  const { id, ...draft } = taskSchema.parse({
                    ...task,
                    label: value,
                  })
                  await updateTask(id, draft)
                  toast.success(
                    english
                      ? 'Task label updated.'
                      : 'Vazifa tegi yangilandi.'
                  )
                } catch (error) {
                  toast.error(
                    error instanceof Error
                      ? error.message
                      : apiErrorMessage(error)
                  )
                }
              }}
            >
              {labels.map((label) => (
                <DropdownMenuRadioItem key={label.value} value={label.value}>
                  {english
                    ? label.label
                    : ({ documentation: 'Hujjatlashtirish', feature: 'Funksiya', bug: 'Xato' } as Record<string, string>)[label.value]}
                </DropdownMenuRadioItem>
              ))}
            </DropdownMenuRadioGroup>
          </DropdownMenuSubContent>
        </DropdownMenuSub>
        <DropdownMenuSeparator />
        <DropdownMenuItem
          onClick={() => {
            setCurrentRow(task)
            setOpen('delete')
          }}
        >
          {english ? 'Delete' : 'O‘chirish'}
          <DropdownMenuShortcut>
            <Trash2 size={16} />
          </DropdownMenuShortcut>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
