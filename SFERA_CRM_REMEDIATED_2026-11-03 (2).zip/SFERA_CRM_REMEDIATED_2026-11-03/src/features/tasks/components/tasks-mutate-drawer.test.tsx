import { useState } from 'react'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { renderEnglish as render } from '@/test-utils/render-english'
import { userEvent } from 'vitest/browser'
import { type Task } from '../data/schema'
import { TasksMutateDrawer } from './tasks-mutate-drawer'

const mocks = vi.hoisted(() => ({
  createTask: vi.fn(),
  updateTask: vi.fn(),
}))

vi.mock('./tasks-provider', () => ({
  useTasks: () => ({ createTask: mocks.createTask, updateTask: mocks.updateTask }),
}))
vi.mock('@/stores/auth-store', () => ({
  useAuthStore: (selector: (state: unknown) => unknown) => selector({
    auth: { user: { accountNo: 'account-42', name: 'Test User', email: 'test@example.com' } },
  }),
}))

const MOCK_TASK = {
  id: 'task-1',
  title: 'Existing task',
  status: 'in progress',
  label: 'feature',
  priority: 'medium',
  assignee: 'account-42',
  description: 'Existing description',
  dueDate: '2026-11-10',
} satisfies Task

const selectOption = async (screen: Awaited<ReturnType<typeof render>>, label: RegExp, option: RegExp) => {
  const select = screen.getByRole('combobox', { name: label })
  await userEvent.click(select)
  await userEvent.click(screen.getByRole('option', { name: option }))
  return select
}

describe('TasksMutateDrawer', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    mocks.createTask.mockImplementation(async (task) => ({ ...task, id: 'task-created' }))
    mocks.updateTask.mockImplementation(async (id, task) => ({ ...task, id }))
  })

  it('renders create title and description', async () => {
    const screen = await render(<TasksMutateDrawer open onOpenChange={vi.fn()} />)
    await expect.element(screen.getByRole('heading', { level: 2, name: /Create task/i })).toBeInTheDocument()
    await expect.element(screen.getByText(/Add a new task/i)).toBeInTheDocument()
  })

  it('renders edit title, description and prefilled task fields', async () => {
    const screen = await render(<TasksMutateDrawer open onOpenChange={vi.fn()} currentRow={MOCK_TASK} />)
    await expect.element(screen.getByRole('heading', { level: 2, name: /Update task/i })).toBeInTheDocument()
    await expect.element(screen.getByText(/Update the task/i)).toBeInTheDocument()
    await expect.element(screen.getByRole('textbox', { name: /Title/i })).toHaveValue(MOCK_TASK.title)
    await expect.element(screen.getByRole('textbox', { name: /Details/i })).toHaveValue(MOCK_TASK.description)
    await expect.element(screen.getByRole('combobox', { name: /Status/i })).toHaveTextContent(/In Progress/i)
    await expect.element(screen.getByRole('combobox', { name: /Category/i })).toHaveTextContent(/Feature/i)
    await expect.element(screen.getByRole('combobox', { name: /Priority/i })).toHaveTextContent(/Medium/i)
    await expect.element(screen.getByRole('combobox', { name: /Assign to/i })).toHaveTextContent(/Test User/i)
  })

  it('shows validation messages when submitting an empty form', async () => {
    const screen = await render(<TasksMutateDrawer open onOpenChange={vi.fn()} />)
    await userEvent.click(screen.getByRole('button', { name: /Save changes/i }))
    await expect.element(screen.getByText(/Title is required\.$/i)).toBeInTheDocument()
    await expect.element(screen.getByText(/Please select a status\.$/i)).toBeInTheDocument()
    await expect.element(screen.getByText(/Please select a label\.$/i)).toBeInTheDocument()
    await expect.element(screen.getByText(/Please choose a priority\.$/i)).toBeInTheDocument()
  })

  it('persists a new task with all form values and closes the drawer', async () => {
    const onOpenChange = vi.fn()
    const screen = await render(<TasksMutateDrawer open onOpenChange={onOpenChange} />)
    await userEvent.fill(screen.getByRole('textbox', { name: /Title/i }), 'New task title')
    await selectOption(screen, /Status/i, /Todo/i)
    await selectOption(screen, /Category/i, /^Bug$/i)
    await selectOption(screen, /Priority/i, /^Low$/i)
    await userEvent.fill(screen.getByRole('textbox', { name: /Details/i }), 'Ship the task workflow')
    await userEvent.click(screen.getByRole('button', { name: /Save changes/i }))

    await vi.waitFor(() => expect(mocks.createTask).toHaveBeenCalledOnce())
    expect(mocks.createTask).toHaveBeenCalledWith(expect.objectContaining({
      title: 'New task title', status: 'todo', label: 'bug', priority: 'low',
      assignee: 'account-42', description: 'Ship the task workflow',
    }))
    expect(onOpenChange).toHaveBeenCalledWith(false)
  })

  it('updates an existing task by immutable id and preserves all submitted fields', async () => {
    const screen = await render(<TasksMutateDrawer open onOpenChange={vi.fn()} currentRow={MOCK_TASK} />)
    await userEvent.fill(screen.getByRole('textbox', { name: /Title/i }), 'Updated task title')
    await userEvent.click(screen.getByRole('button', { name: /Save changes/i }))
    await vi.waitFor(() => expect(mocks.updateTask).toHaveBeenCalledOnce())
    expect(mocks.updateTask).toHaveBeenCalledWith('task-1', expect.objectContaining({
      title: 'Updated task title', status: MOCK_TASK.status, label: MOCK_TASK.label,
      priority: MOCK_TASK.priority, assignee: MOCK_TASK.assignee,
    }))
  })

  it('closes when Close is clicked', async () => {
    const onOpenChange = vi.fn()
    const screen = await render(<TasksMutateDrawer open onOpenChange={onOpenChange} />)
    const closeButtons = screen.getByRole('dialog').getByRole('button', { name: /Close/i }).all()
    expect(closeButtons).toHaveLength(2)
    await userEvent.click(closeButtons[1])
    expect(onOpenChange).toHaveBeenCalledWith(false)
  })

  it('resets entered values when the sheet is closed and reopened', async () => {
    function Harness() {
      const [open, setOpen] = useState(true)
      return <><button type='button' onClick={() => setOpen(true)}>Reopen</button><TasksMutateDrawer open={open} onOpenChange={setOpen} /></>
    }
    const screen = await render(<Harness />)
    const titleInput = screen.getByRole('textbox', { name: /Title/i })
    await userEvent.fill(titleInput, 'Draft title')
    await selectOption(screen, /Status/i, /Todo/i)
    await selectOption(screen, /Category/i, /Documentation/i)
    await selectOption(screen, /Priority/i, /High/i)
    await userEvent.click(screen.getByRole('dialog').getByRole('button', { name: /Close/i }).first())
    await userEvent.click(screen.getByRole('button', { name: /Reopen/i }))

    await expect.element(titleInput).toHaveValue('')
    await expect.element(screen.getByRole('combobox', { name: /Status/i })).not.toHaveTextContent(/Todo/i)
    await expect.element(screen.getByRole('combobox', { name: /Category/i })).not.toHaveTextContent(/Documentation/i)
    await expect.element(screen.getByRole('combobox', { name: /Priority/i })).not.toHaveTextContent(/High/i)
  })
})
