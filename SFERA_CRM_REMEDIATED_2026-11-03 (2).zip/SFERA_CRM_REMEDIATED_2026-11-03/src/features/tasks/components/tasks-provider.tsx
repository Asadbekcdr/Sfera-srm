import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  apiClient,
  apiErrorMessage,
  getApiData,
  isBackendEnabled,
  postApiData,
  putApiData,
} from '@/lib/api-client'
import useDialogState from '@/hooks/use-dialog-state'
import { type Task } from '../data/schema'
import { tasks as initialTasks } from '../data/tasks'
import { createTaskRepository, TASKS_STORAGE_KEY } from '../data/task-repository'

type TasksDialogType = 'create' | 'update' | 'delete' | 'import'
type TasksContextType = {
  open: TasksDialogType | null
  setOpen: (str: TasksDialogType | null) => void
  currentRow: Task | null
  setCurrentRow: React.Dispatch<React.SetStateAction<Task | null>>
  tasks: Task[]
  isLoading: boolean
  loadError: string | null
  reloadTasks: () => Promise<void>
  createTask: (task: Omit<Task, 'id'>) => Promise<Task>
  updateTask: (id: string, task: Omit<Task, 'id'>) => Promise<Task>
  deleteTask: (id: string) => Promise<void>
  deleteTasks: (ids: string[]) => Promise<void>
  updateTasks: (
    ids: string[],
    changes: Partial<Omit<Task, 'id'>>
  ) => Promise<void>
}

const TasksContext = React.createContext<TasksContextType | null>(null)
const backendEnabled = isBackendEnabled()
const taskStorage = {
  getItem(key: string) {
    try {
      return typeof window === 'undefined' ? null : window.localStorage.getItem(key)
    } catch {
      return null
    }
  },
  setItem(key: string, value: string) {
    if (typeof window === 'undefined') {
      throw new Error('Local task storage is unavailable in this environment.')
    }
    window.localStorage.setItem(key, value)
  },
}

export function TasksProvider({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useDialogState<TasksDialogType>(null)
  const [currentRow, setCurrentRow] = useState<Task | null>(null)
  const [tasks, setTasks] = useState<Task[]>(backendEnabled ? [] : (initialTasks as Task[]))
  const [isLoading, setIsLoading] = useState(backendEnabled)
  const [loadError, setLoadError] = useState<string | null>(null)
  const tasksRef = useRef(tasks)
  const repository = useMemo(
    () =>
      createTaskRepository({
        backendEnabled,
        storage: taskStorage,
        seedTasks: initialTasks as Task[],
        api: {
          list: () => getApiData('/tasks'),
          create: (body) => postApiData('/tasks', body),
          update: (id, body) => putApiData(`/tasks/${id}`, body),
          delete: async (id) => apiClient.delete(`/tasks/${id}`),
        },
      }),
    []
  )

  const replaceTasks = useCallback((next: Task[]) => {
    tasksRef.current = next
    setTasks(next)
  }, [])

  const reloadTasks = useCallback(async () => {
    setIsLoading(true)
    setLoadError(null)
    try {
      replaceTasks(await repository.load())
    } catch (error) {
      setLoadError(apiErrorMessage(error))
      throw error
    } finally {
      setIsLoading(false)
    }
  }, [repository, replaceTasks])

  useEffect(() => {
    let active = true
    void repository
      .load()
      .then((loadedTasks) => {
        if (!active) return
        replaceTasks(loadedTasks)
        setLoadError(null)
      })
      .catch((error: unknown) => {
        if (active) setLoadError(apiErrorMessage(error))
      })
      .finally(() => {
        if (active) setIsLoading(false)
      })
    return () => {
      active = false
    }
  }, [repository, replaceTasks])

  const createTask = useCallback(
    async (draft: Omit<Task, 'id'>) => {
      const created = await repository.create(draft)
      replaceTasks([created, ...tasksRef.current])
      return created
    },
    [repository, replaceTasks]
  )

  const updateTask = useCallback(
    async (id: string, draft: Omit<Task, 'id'>) => {
      const current = tasksRef.current.find((task) => task.id === id)
      if (!current) throw new Error('Task no longer exists. Reload and retry.')
      const saved = await repository.update(current, { ...draft, id })
      replaceTasks(tasksRef.current.map((task) => (task.id === id ? saved : task)))
      return saved
    },
    [repository, replaceTasks]
  )

  const deleteTask = useCallback(
    async (id: string) => {
      await repository.delete(id)
      replaceTasks(tasksRef.current.filter((task) => task.id !== id))
    },
    [repository, replaceTasks]
  )

  const deleteTasks = useCallback(
    async (ids: string[]) => {
      try {
        await repository.deleteMany(ids)
      } catch (error) {
        if (backendEnabled) await reloadTasks().catch(() => undefined)
        throw error
      }
      const selected = new Set(ids)
      replaceTasks(tasksRef.current.filter((task) => !selected.has(task.id)))
    },
    [repository, reloadTasks, replaceTasks]
  )

  const updateTasks = useCallback(
    async (ids: string[], changes: Partial<Omit<Task, 'id'>>) => {
      let savedTasks: Task[]
      try {
        savedTasks = await repository.updateMany(ids, changes)
      } catch (error) {
        if (backendEnabled) await reloadTasks().catch(() => undefined)
        throw error
      }
      const savedById = new Map(savedTasks.map((task) => [task.id, task]))
      replaceTasks(tasksRef.current.map((task) => savedById.get(task.id) ?? task))
    },
    [repository, reloadTasks, replaceTasks]
  )

  return (
    <TasksContext
      value={{
        open,
        setOpen,
        currentRow,
        setCurrentRow,
        tasks,
        isLoading,
        loadError,
        reloadTasks,
        createTask,
        updateTask,
        deleteTask,
        deleteTasks,
        updateTasks,
      }}
    >
      {children}
    </TasksContext>
  )
}

// eslint-disable-next-line react-refresh/only-export-components
export const useTasks = () => {
  const tasksContext = React.useContext(TasksContext)
  if (tasksContext) return tasksContext
  return {
    open: null,
    setOpen: () => undefined,
    currentRow: null,
    setCurrentRow: () => undefined,
    tasks: initialTasks as Task[],
    isLoading: false,
    loadError: null,
    reloadTasks: async () => undefined,
    createTask: async (task: Omit<Task, 'id'>) => ({ ...task, id: '' }),
    updateTask: async (id: string, task: Omit<Task, 'id'>) => ({ ...task, id }),
    deleteTask: async () => undefined,
    deleteTasks: async () => undefined,
    updateTasks: async () => undefined,
  }
}

export { TASKS_STORAGE_KEY }
