import { taskSchema, type Task } from './schema'

export const TASKS_STORAGE_KEY = 'sfera-crm-tasks'

type ApiTask = {
  id: string
  title: string
  status: string
  category?: string
  priority: string
  assignees?: string[]
  description?: string
  dueDate?: string | null
}

type TaskApi = {
  list: () => Promise<ApiTask[]>
  create: (task: Record<string, unknown>) => Promise<ApiTask>
  update: (id: string, task: Record<string, unknown>) => Promise<ApiTask>
  delete: (id: string) => Promise<unknown>
}

type TaskStorage = Pick<Storage, 'getItem' | 'setItem'>

type TaskRepositoryOptions = {
  backendEnabled: boolean
  storage: TaskStorage
  seedTasks: Task[]
  api?: TaskApi
  createId?: () => string
}

const fromApiTask = (item: ApiTask): Task => ({
  id: item.id,
  title: item.title,
  status:
    item.status === 'in_progress'
      ? 'in progress'
      : item.status === 'completed'
        ? 'done'
        : item.status,
  label:
    item.category === 'administration'
      ? 'documentation'
      : item.category === 'academic'
        ? 'feature'
        : 'bug',
  priority: item.priority === 'urgent' ? 'critical' : item.priority,
  assignee: Array.isArray(item.assignees) ? item.assignees[0] : '',
  description: item.description,
  dueDate: item.dueDate?.slice(0, 10) ?? '',
})

const toApiTask = (task: Partial<Task>) => {
  const dueDate = task.dueDate ? new Date(`${task.dueDate}T00:00:00`) : null
  return {
    title: task.title,
    description: task.description || task.title,
    status:
      task.status === 'in progress'
        ? 'in_progress'
        : task.status === 'done'
          ? 'completed'
          : task.status,
    category:
      task.label === 'documentation'
        ? 'administration'
        : task.label === 'feature'
          ? 'academic'
          : 'technical',
    priority: task.priority === 'critical' ? 'urgent' : task.priority,
    dueDate:
      dueDate && !Number.isNaN(dueDate.getTime()) ? dueDate.toISOString() : null,
    assignees: task.assignee ? [task.assignee] : [],
  }
}

function parseTasks(value: string | null, fallback: Task[]): Task[] {
  if (!value) return fallback
  try {
    const parsed: unknown = JSON.parse(value)
    const result = taskSchema.array().safeParse(parsed)
    return result.success ? result.data : fallback
  } catch {
    return fallback
  }
}

function requireApi(api: TaskApi | undefined): TaskApi {
  if (!api) throw new Error('Task API is not configured.')
  return api
}

export function createTaskRepository(options: TaskRepositoryOptions) {
  const { backendEnabled, storage, seedTasks } = options
  const api = options.api
  const createId =
    options.createId ??
    (() =>
      globalThis.crypto?.randomUUID?.() ??
      `TASK-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`)

  const readLocal = () => parseTasks(storage.getItem(TASKS_STORAGE_KEY), seedTasks)
  const writeLocal = (tasks: Task[]) =>
    storage.setItem(TASKS_STORAGE_KEY, JSON.stringify(tasks))

  return {
    async load(): Promise<Task[]> {
      if (backendEnabled) {
        const items = await requireApi(api).list()
        return items.map(fromApiTask)
      }
      return readLocal()
    },

    async create(draft: Omit<Task, 'id'>): Promise<Task> {
      if (backendEnabled) {
        return fromApiTask(await requireApi(api).create(toApiTask(draft)))
      }
      const task = taskSchema.parse({ ...draft, id: createId() })
      writeLocal([task, ...readLocal()])
      return task
    },

    async update(current: Task, changes: Task): Promise<Task> {
      if (current.id !== changes.id) {
        throw new Error('Task IDs cannot be changed during an update.')
      }
      if (backendEnabled) {
        return fromApiTask(
          await requireApi(api).update(current.id, toApiTask(changes))
        )
      }
      const updated = taskSchema.parse(changes)
      const tasks = readLocal()
      if (!tasks.some((task) => task.id === current.id)) {
        throw new Error('Task no longer exists. Reload the task list and retry.')
      }
      writeLocal(tasks.map((task) => (task.id === current.id ? updated : task)))
      return updated
    },

    async delete(id: string): Promise<void> {
      if (backendEnabled) {
        await requireApi(api).delete(id)
        return
      }
      const tasks = readLocal()
      if (!tasks.some((task) => task.id === id)) {
        throw new Error('Task no longer exists. Reload the task list and retry.')
      }
      writeLocal(tasks.filter((task) => task.id !== id))
    },

    async deleteMany(ids: string[]): Promise<void> {
      if (backendEnabled) {
        const client = requireApi(api)
        await Promise.all(ids.map((id) => client.delete(id)))
        return
      }
      const selected = new Set(ids)
      const tasks = readLocal()
      writeLocal(tasks.filter((task) => !selected.has(task.id)))
    },

    async updateMany(
      ids: string[],
      changes: Partial<Omit<Task, 'id'>>
    ): Promise<Task[]> {
      const selected = new Set(ids)
      const tasks = await this.load()
      const updated = tasks.filter((task) => selected.has(task.id)).map((task) => ({
        ...task,
        ...changes,
      }))
      if (updated.length !== selected.size) {
        throw new Error('One or more tasks no longer exist. Reload and retry.')
      }
      if (backendEnabled) {
        const client = requireApi(api)
        const saved = await Promise.all(
          updated.map((task) => client.update(task.id, toApiTask(task)))
        )
        return saved.map(fromApiTask)
      }
      const byId = new Map(updated.map((task) => [task.id, taskSchema.parse(task)]))
      writeLocal(tasks.map((task) => byId.get(task.id) ?? task))
      return updated
    },
  }
}

export type { ApiTask, TaskApi }
