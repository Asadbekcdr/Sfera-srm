import { beforeEach, describe, expect, it, vi } from 'vitest'
import { createTaskRepository } from './task-repository'
import type { Task } from './schema'

const draft: Omit<Task, 'id'> = {
  title: 'Review student onboarding',
  status: 'todo',
  label: 'feature',
  priority: 'high',
  assignee: 'Manager One',
  description: 'Check the onboarding flow',
  dueDate: '2026-10-30',
}

function makeStorage() {
  const values = new Map<string, string>()
  return {
    getItem: vi.fn((key: string) => values.get(key) ?? null),
    setItem: vi.fn((key: string, value: string) => values.set(key, value)),
  }
}

describe('task repository', () => {
  let storage: ReturnType<typeof makeStorage>

  beforeEach(() => {
    storage = makeStorage()
  })

  it('persists demo-mode task creation before returning the created task', async () => {
    const repository = createTaskRepository({
      backendEnabled: false,
      storage,
      seedTasks: [],
      createId: () => 'task-stable-id',
    })

    const created = await repository.create(draft)

    expect(created.id).toBe('task-stable-id')
    expect(JSON.parse(storage.getItem('sfera-crm-tasks') ?? '[]')).toEqual([
      created,
    ])
    expect(await repository.load()).toEqual([created])
  })

  it('does not report create success or persist locally when the API rejects', async () => {
    const apiError = new Error('API unavailable')
    const repository = createTaskRepository({
      backendEnabled: true,
      storage,
      seedTasks: [],
      createId: () => 'temporary-id',
      api: {
        list: vi.fn().mockResolvedValue([]),
        create: vi.fn().mockRejectedValue(apiError),
        update: vi.fn(),
        delete: vi.fn(),
      },
    })

    await expect(repository.create(draft)).rejects.toBe(apiError)
    expect(storage.setItem).not.toHaveBeenCalled()
  })

  it('keeps local task data unchanged when an API update fails', async () => {
    const existing: Task = { ...draft, id: 'existing-id', title: 'Old title' }
    const repository = createTaskRepository({
      backendEnabled: true,
      storage,
      seedTasks: [],
      api: {
        list: vi.fn().mockResolvedValue([]),
        create: vi.fn(),
        update: vi.fn().mockRejectedValue(new Error('API unavailable')),
        delete: vi.fn(),
      },
    })

    await expect(
      repository.update(existing, { ...existing, title: 'New title' })
    ).rejects.toThrow('API unavailable')
    expect(storage.setItem).not.toHaveBeenCalled()
  })

  it('persists local edits by stable task ID', async () => {
    const existing: Task = { ...draft, id: 'stable-task-id', title: 'Old title' }
    storage.setItem('sfera-crm-tasks', JSON.stringify([existing]))
    const repository = createTaskRepository({
      backendEnabled: false,
      storage,
      seedTasks: [],
    })

    await repository.update(existing, { ...existing, title: 'Saved title' })

    expect(JSON.parse(storage.getItem('sfera-crm-tasks') ?? '[]')).toEqual([
      { ...existing, title: 'Saved title' },
    ])
  })

  it('persists local deletion by stable task ID', async () => {
    const existing: Task = { ...draft, id: 'stable-task-id' }
    storage.setItem('sfera-crm-tasks', JSON.stringify([existing]))
    const repository = createTaskRepository({
      backendEnabled: false,
      storage,
      seedTasks: [],
    })

    await repository.delete(existing.id)

    expect(JSON.parse(storage.getItem('sfera-crm-tasks') ?? '[]')).toEqual([])
  })

  it('maps server fields into the task view model after a successful update', async () => {
    const existing: Task = { ...draft, id: 'server-task-id' }
    const api = {
      list: vi.fn().mockResolvedValue([]),
      create: vi.fn(),
      update: vi.fn().mockResolvedValue({
        id: 'server-task-id',
        title: 'Saved on server',
        status: 'completed',
        category: 'academic',
        priority: 'urgent',
        assignees: ['manager-account-1'],
        description: 'Server-saved description',
        dueDate: '2026-11-04T00:00:00.000Z',
      }),
      delete: vi.fn(),
    }
    const repository = createTaskRepository({
      backendEnabled: true,
      storage,
      seedTasks: [],
      api,
    })

    const updated = await repository.update(existing, {
      ...existing,
      title: 'Saved on server',
    })

    expect(updated).toEqual({
      id: 'server-task-id',
      title: 'Saved on server',
      status: 'done',
      label: 'feature',
      priority: 'critical',
      assignee: 'manager-account-1',
      description: 'Server-saved description',
      dueDate: '2026-11-04',
    })
    expect(api.update).toHaveBeenCalledWith('server-task-id', {
      title: 'Saved on server',
      description: 'Check the onboarding flow',
      status: 'todo',
      category: 'academic',
      priority: 'high',
      dueDate: '2026-10-30T00:00:00.000Z',
      assignees: ['Manager One'],
    })
  })
})
