import { useLanguage } from '@/context/language-provider'
import { Header } from '@/components/layout/header'
import { Main } from '@/components/layout/main'
import { ProfileDropdown } from '@/components/profile-dropdown'
import { Search } from '@/components/search'
import { ThemeSwitch } from '@/components/theme-switch'
import { TasksDialogs } from './components/tasks-dialogs'
import { TasksPrimaryButtons } from './components/tasks-primary-buttons'
import { TasksProvider, useTasks } from './components/tasks-provider'
import { TasksTable } from './components/tasks-table'
import { Button } from '@/components/ui/button'

export function Tasks() {
  const { language, t } = useLanguage()
  const english = language === 'en'
  return (
    <TasksProvider>
      <Header fixed>
        <Search className='me-auto' />
        <ThemeSwitch />
        <ProfileDropdown />
      </Header>

      <Main className='flex flex-1 flex-col gap-4 sm:gap-6'>
        <div className='flex flex-wrap items-end justify-between gap-2'>
          <div>
            <h2 className='text-2xl font-bold tracking-tight'>
              {t('tasks')}
            </h2>
            <p className='text-muted-foreground'>
              {english
                ? 'Assign, track and complete work across the academy team.'
                : 'Admin jamoaga vazifa beradi, muddat va bajarilishni shu yerda nazorat qiladi.'}
            </p>
          </div>
          <TasksPrimaryButtons />
        </div>
        <TasksContent />
      </Main>

      <TasksDialogs />
    </TasksProvider>
  )
}

function TasksContent() {
  const { tasks, isLoading, loadError, reloadTasks } = useTasks()
  const { language } = useLanguage()
  const english = language === 'en'
  if (isLoading)
    return <p role='status'>{english ? 'Loading tasks…' : 'Vazifalar yuklanmoqda…'}</p>
  if (loadError)
    return (
      <div role='alert' className='space-y-3 rounded-md border p-4'>
        <p>{loadError}</p>
        <Button variant='outline' onClick={() => void reloadTasks().catch(() => undefined)}>
          {english ? 'Retry' : 'Qayta urinish'}
        </Button>
      </div>
    )
  return <TasksTable data={tasks} />
}
