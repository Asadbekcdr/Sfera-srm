import { ContentSection } from '../components/content-section'
import { ProfileForm } from './profile-form'
import { useLanguage } from '@/context/language-provider'

export function SettingsProfile() {
  const { language } = useLanguage()
  const english = language === 'en'
  return (
    <ContentSection
      title={english ? 'My profile' : 'Profilim'}
      desc={
        english
          ? 'View and update the identity information stored for your signed-in account.'
          : 'Kirilgan hisobingizda saqlanadigan ism-sharif va elektron pochta ma’lumotlarini ko‘ring va yangilang.'
      }
    >
      <ProfileForm />
    </ContentSection>
  )
}
