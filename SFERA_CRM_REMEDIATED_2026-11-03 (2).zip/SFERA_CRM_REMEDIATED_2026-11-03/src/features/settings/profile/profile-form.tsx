import { useEffect, useMemo, useState } from 'react'
import { z } from 'zod'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Mail, Shield, User } from 'lucide-react'
import { toast } from 'sonner'
import { apiErrorMessage, putApiData } from '@/lib/api-client'
import { getPrimaryRole } from '@/lib/rbac'
import { useLanguage } from '@/context/language-provider'
import { useAuthStore } from '@/stores/auth-store'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

const getProfileSchema = (english: boolean) =>
  z.object({
    fullName: z
      .string()
      .trim()
      .min(2, english ? 'Enter at least 2 characters.' : 'Kamida 2 ta belgi kiriting.')
      .max(50, english ? 'Use at most 50 characters.' : 'Maksimal 50 ta belgi kiriting.'),
    email: z.string().trim(),
  })

type ProfileFormValues = z.infer<ReturnType<typeof getProfileSchema>>

export function ProfileForm() {
  const { language } = useLanguage()
  const english = language === 'en'
  const { auth } = useAuthStore()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const schema = useMemo(() => getProfileSchema(english), [english])
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      fullName: auth.user?.name ?? '',
      email: auth.user?.email ?? '',
    },
    mode: 'onChange',
  })

  useEffect(() => {
    form.reset({
      fullName: auth.user?.name ?? '',
      email: auth.user?.email ?? '',
    })
  }, [auth.user?.name, auth.user?.email, form])

  async function onSubmit(data: ProfileFormValues) {
    if (!auth.user) {
      toast.error(english ? 'No signed-in account is available.' : 'Tizimga kirgan foydalanuvchi topilmadi.')
      return
    }
    setIsSubmitting(true)
    const previousUser = auth.user
    try {
      const updatedUser = {
        ...previousUser,
        name: data.fullName,
        email: data.email || previousUser.email,
      }
      const role = getPrimaryRole(previousUser.role)
      if (role === 'Student') {
        await putApiData('/student', { fullName: data.fullName })
      } else {
        await putApiData('/user', { fullName: data.fullName })
      }
      auth.setUser(updatedUser)
      toast.success(
        english
          ? 'Profile saved to the backend.'
          : 'Profil ma’lumotlari backendga saqlandi.'
      )
    } catch (error) {
      toast.error(
        error
          ? apiErrorMessage(error)
          : english
            ? 'The profile could not be saved.'
            : 'Profilni saqlab bo‘lmadi.'
      )
    } finally {
      setIsSubmitting(false)
    }
  }

  const roleLabel = auth.user?.role?.filter(Boolean).join(', ') || '—'
  const initials = (auth.user?.name || '—')
    .split(' ')
    .map((part) => part[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)

  return (
    <div className='space-y-6'>
      <Card>
        <CardHeader>
          <div className='flex items-center gap-4'>
            <Avatar className='size-14 border-2 border-primary/20'>
              <AvatarFallback className='bg-primary/10 font-bold text-primary'>
                {initials}
              </AvatarFallback>
            </Avatar>
            <div className='min-w-0 space-y-1'>
              <CardTitle className='truncate text-lg'>
                {auth.user?.name || (english ? 'Account name not set' : 'Hisob nomi kiritilmagan')}
              </CardTitle>
              <CardDescription className='truncate'>
                {auth.user?.email || (english ? 'Email not set' : 'Elektron pochta kiritilmagan')}
              </CardDescription>
              <div className='flex flex-wrap items-center gap-2 pt-1'>
                <Badge variant='outline' className='gap-1'>
                  <Shield className='size-3' aria-hidden='true' />
                  {roleLabel}
                </Badge>
                {auth.user?.accountNo && (
                  <Badge variant='secondary'>
                    {english ? 'Account' : 'Hisob'}: {auth.user.accountNo}
                  </Badge>
                )}
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>{english ? 'Profile information' : 'Profil ma’lumotlari'}</CardTitle>
          <CardDescription>
            {english
              ? 'Only identity fields stored by the current authentication layer are editable here.'
              : 'Bu yerda faqat joriy autentifikatsiya qatlami saqlaydigan shaxsiy maydonlar tahrirlanadi.'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className='space-y-5'>
              <div className='grid gap-5 md:grid-cols-2'>
                <FormField
                  control={form.control}
                  name='fullName'
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className='flex items-center gap-1.5'>
                        <User className='size-3.5 text-muted-foreground' aria-hidden='true' />
                        {english ? 'Full name' : 'To‘liq ism-sharif'}
                      </FormLabel>
                      <FormControl>
                        <Input
                          autoComplete='name'
                          placeholder={english ? 'Enter your name' : 'Ism-sharifingizni kiriting'}
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                          {english ? 'Saved to the signed-in account on the backend.' : 'Kirilgan hisob backendda saqlanadi.'}
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name='email'
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className='flex items-center gap-1.5'>
                        <Mail className='size-3.5 text-muted-foreground' aria-hidden='true' />
                        {english ? 'Email address' : 'Elektron pochta'}
                      </FormLabel>
                      <FormControl>
                        <Input
                          type='text'
                          autoComplete='email'
                          placeholder={english ? 'name@example.com' : 'ism@example.com'}
                          {...field}
                          readOnly
                          value={field.value || auth.user?.accountNo || ''}
                        />
                      </FormControl>
                      <FormDescription>
                        {english
                          ? 'Email is not part of the current backend identity model; the phone number is shown when available.'
                          : 'Joriy backend identifikatsiyasida email yo‘q; mavjud bo‘lsa telefon raqami ko‘rsatiladi.'}
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className='flex justify-end'>
                <Button
                  type='submit'
                  disabled={isSubmitting || !auth.user || !form.formState.isValid}
                  className='min-w-36'
                >
                  {isSubmitting
                    ? english
                      ? 'Saving…'
                      : 'Saqlanmoqda…'
                    : english
                      ? 'Save changes'
                      : 'O‘zgarishlarni saqlash'}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  )
}
