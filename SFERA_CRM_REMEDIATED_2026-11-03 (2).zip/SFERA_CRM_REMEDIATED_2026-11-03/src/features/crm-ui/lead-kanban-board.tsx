import { ArrowUpRight, CalendarDays, GripVertical, Phone, UserRound } from 'lucide-react'
import { cn } from '@/lib/utils'

type Lead = {
  id: string
  name: string
  phone: string
  course: string
  status: string
  date: string
  assignedTo?: string
  trialLessonAt?: string | null
}

type Stage = {
  key: string
  uz: string
  en: string
  dot: string
  surface: string
  border: string
  pill: string
}

const stages: Stage[] = [
  { key: 'NEW', uz: 'Yangi ariza', en: 'New application', dot: 'bg-sky-500', surface: 'bg-sky-50/70 dark:bg-sky-500/[0.045]', border: 'border-sky-200/80 dark:border-sky-500/20', pill: 'bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300' },
  { key: 'CONTACT_REQUIRED', uz: 'Bog‘lanish kerak', en: 'Contact needed', dot: 'bg-violet-500', surface: 'bg-violet-50/60 dark:bg-violet-500/[0.04]', border: 'border-violet-200/80 dark:border-violet-500/20', pill: 'bg-violet-100 text-violet-700 dark:bg-violet-500/15 dark:text-violet-300' },
  { key: 'CONTACTED', uz: 'Bog‘lanildi', en: 'Contacted', dot: 'bg-indigo-500', surface: 'bg-indigo-50/60 dark:bg-indigo-500/[0.04]', border: 'border-indigo-200/80 dark:border-indigo-500/20', pill: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-500/15 dark:text-indigo-300' },
  { key: 'TRIAL_SCHEDULED', uz: 'Sinov darsi', en: 'Trial scheduled', dot: 'bg-orange-500', surface: 'bg-orange-50/60 dark:bg-orange-500/[0.04]', border: 'border-orange-200/80 dark:border-orange-500/20', pill: 'bg-orange-100 text-orange-700 dark:bg-orange-500/15 dark:text-orange-300' },
  { key: 'TRIAL_ATTENDED', uz: 'Sinovda qatnashdi', en: 'Trial attended', dot: 'bg-amber-500', surface: 'bg-amber-50/60 dark:bg-amber-500/[0.04]', border: 'border-amber-200/80 dark:border-amber-500/20', pill: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300' },
  { key: 'DECISION_PENDING', uz: 'Qaror kutilmoqda', en: 'Decision pending', dot: 'bg-cyan-500', surface: 'bg-cyan-50/60 dark:bg-cyan-500/[0.04]', border: 'border-cyan-200/80 dark:border-cyan-500/20', pill: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-500/15 dark:text-cyan-300' },
  { key: 'CONVERTED', uz: 'Kursga yozildi', en: 'Enrolled', dot: 'bg-emerald-500', surface: 'bg-emerald-50/60 dark:bg-emerald-500/[0.04]', border: 'border-emerald-200/80 dark:border-emerald-500/20', pill: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300' },
  { key: 'LOST', uz: 'Kursga yozilmadi', en: 'Not enrolled', dot: 'bg-slate-400', surface: 'bg-slate-50/70 dark:bg-slate-500/[0.035]', border: 'border-slate-200/80 dark:border-slate-500/20', pill: 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300' },
  { key: 'ARCHIVED', uz: 'Arxivlandi', en: 'Archived', dot: 'bg-zinc-400', surface: 'bg-zinc-50/70 dark:bg-zinc-500/[0.035]', border: 'border-zinc-200/80 dark:border-zinc-500/20', pill: 'bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300' },
]

const getNextAction = (status: string, english: boolean) => {
  const actions: Record<string, [string, string]> = {
    NEW: ['Bog‘lanish', 'Make first contact'],
    CONTACT_REQUIRED: ['Mijoz bilan bog‘lanish', 'Contact the prospect'],
    CONTACTED: ['Sinov darsini belgilash', 'Schedule a trial lesson'],
    TRIAL_SCHEDULED: ['Sinov darsini o‘tkazish', 'Conduct the trial lesson'],
    TRIAL_ATTENDED: ['Natijani qayd etish', 'Record the outcome'],
    DECISION_PENDING: ['Kursga yozish yoki kuzatish', 'Discuss enrollment'],
    CONVERTED: ['O‘quvchini kuzatish', 'Follow up with student'],
    LOST: ['Sababini qayd etish', 'Record the reason'],
    ARCHIVED: ['Arxivda saqlanadi', 'Kept in archive'],
  }
  const [uz, en] = actions[status] ?? ['Keyingi qadamni belgilang', 'Choose the next step']
  return english ? en : uz
}

function initials(name: string) {
  return name.split(' ').filter(Boolean).map((part) => part[0]).join('').slice(0, 2).toUpperCase()
}

export function LeadKanbanBoard({ leads, english, onMove, onOpen, draggingLead, onDragStart, onDragEnd }: {
  leads: Lead[]
  english: boolean
  onMove: (lead: Lead, stage: string) => void
  onOpen: (lead: Lead) => void
  draggingLead: string | null
  onDragStart: (id: string) => void
  onDragEnd: () => void
}) {
  return (
    <div className='rounded-2xl border border-border/70 bg-slate-50/70 p-3 shadow-sm dark:bg-slate-950/40 sm:p-4'>
      <div className='mb-3 flex flex-wrap items-center justify-between gap-2 px-1'>
        <div>
          <p className='text-sm font-semibold'>{english ? 'Application pipeline' : 'Arizalar oqimi'}</p>
          <p className='mt-0.5 text-xs text-muted-foreground'>{english ? 'Drag a card to update its stage.' : 'Bosqichni o‘zgartirish uchun kartani boshqa ustunga olib o‘ting.'}</p>
        </div>
        <span className='rounded-full border border-border/70 bg-background px-3 py-1 text-xs font-semibold text-muted-foreground'>
          {leads.length} {english ? 'leads' : 'ta lead'}
        </span>
      </div>
      <div className='-mx-1 overflow-x-auto px-1 pb-2'>
        <div className='grid min-w-[2070px] grid-cols-9 gap-3'>
          {stages.map((stage) => {
            const cards = leads.filter((lead) => lead.status === stage.key)
            return (
              <section
                key={stage.key}
                className={cn('min-h-[390px] rounded-2xl border p-2.5 transition-colors', stage.surface, stage.border)}
                onDragOver={(event) => event.preventDefault()}
                onDrop={() => {
                  const lead = leads.find((item) => item.id === draggingLead)
                  if (lead) onMove(lead, stage.key)
                }}
                aria-label={`${english ? stage.en : stage.uz}: ${cards.length}`}
              >
                <div className='mb-2.5 flex min-h-12 items-center justify-between gap-2 border-b border-border/50 px-1 pb-2.5'>
                  <div className='flex min-w-0 items-center gap-2'>
                    <span className={cn('size-2.5 shrink-0 rounded-full ring-4 ring-background/70', stage.dot)} />
                    <h3 className='truncate text-xs font-bold text-foreground'>{english ? stage.en : stage.uz}</h3>
                  </div>
                  <span className={cn('flex size-7 shrink-0 items-center justify-center rounded-lg text-xs font-bold', stage.pill)}>{cards.length}</span>
                </div>
                <div className='space-y-2.5'>
                  {cards.map((lead) => (
                    <button
                      key={lead.id}
                      type='button'
                      draggable={lead.status !== 'CONVERTED' && lead.status !== 'ARCHIVED'}
                      onDragStart={() => onDragStart(lead.id)}
                      onDragEnd={onDragEnd}
                      onClick={() => onOpen(lead)}
                      className={cn(
                        'group w-full rounded-xl border border-border/70 bg-card p-3 text-left shadow-sm transition-all hover:-translate-y-0.5 hover:border-primary/30 hover:shadow-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40',
                        draggingLead === lead.id && 'scale-[0.98] opacity-50 ring-2 ring-primary/30'
                      )}
                    >
                      <div className='flex items-start justify-between gap-2'>
                        <div className='flex min-w-0 items-center gap-2'>
                          <span className='flex size-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-slate-100 to-slate-200 text-[11px] font-bold text-slate-700 dark:from-slate-800 dark:to-slate-700 dark:text-slate-100'>{initials(lead.name)}</span>
                          <span className='min-w-0 truncate text-xs font-bold text-foreground'>{lead.name}</span>
                        </div>
                        <GripVertical className='mt-1 size-3.5 shrink-0 text-muted-foreground/40 transition-colors group-hover:text-primary' />
                      </div>
                      <div className='mt-3 flex items-center gap-1.5 text-[11px] text-muted-foreground'>
                        <Phone className='size-3 shrink-0' />
                        <span className='truncate'>{lead.phone}</span>
                      </div>
                      <div className='mt-2.5 flex items-center justify-between gap-2'>
                        <span className='max-w-[145px] truncate rounded-lg bg-muted/70 px-2 py-1 text-[10px] font-medium text-foreground/80'>{lead.course || (english ? 'Course not selected' : 'Kurs tanlanmagan')}</span>
                        <span className='shrink-0 text-[10px] text-muted-foreground'>{lead.date}</span>
                      </div>
                      <div className='mt-2 flex items-center gap-1.5 text-[10px] text-muted-foreground'>
                        <UserRound className='size-3 shrink-0' />
                        <span className='truncate'>{lead.assignedTo || (english ? 'Unassigned' : 'Mas’ul tayinlanmagan')}</span>
                      </div>
                      {lead.trialLessonAt && (
                        <div className='mt-1.5 flex items-center gap-1.5 text-[10px] text-violet-700 dark:text-violet-300'>
                          <CalendarDays className='size-3 shrink-0' />
                          <span className='truncate'>{new Date(lead.trialLessonAt).toLocaleString(english ? 'en-US' : 'uz-UZ', { dateStyle: 'short', timeStyle: 'short' })}</span>
                        </div>
                      )}
                      <div className='mt-3 flex items-center justify-between gap-1 border-t border-border/60 pt-2.5'>
                        <span className='line-clamp-2 text-[10px] leading-4 text-muted-foreground'>{getNextAction(lead.status, english)}</span>
                        <ArrowUpRight className='size-3.5 shrink-0 text-muted-foreground/50 transition-colors group-hover:text-primary' />
                      </div>
                    </button>
                  ))}
                  {cards.length === 0 && (
                    <div className='flex min-h-28 flex-col items-center justify-center rounded-xl border border-dashed border-border/80 bg-background/40 px-3 py-5 text-center'>
                      <span className={cn('mb-2 size-2 rounded-full opacity-60', stage.dot)} />
                      <p className='text-[10px] leading-4 text-muted-foreground'>{english ? 'Drop leads here' : 'Leadlarni shu yerga olib o‘ting'}</p>
                    </div>
                  )}
                </div>
              </section>
            )
          })}
        </div>
      </div>
    </div>
  )
}
