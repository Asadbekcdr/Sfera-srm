import { beforeEach, describe, expect, it, vi } from 'vitest'
import { renderEnglish as render } from '@/test-utils/render-english'
import { userEvent } from 'vitest/browser'
import { UserAuthForm } from './user-auth-form'

const mocks = vi.hoisted(() => ({
  navigate: vi.fn(),
  setUser: vi.fn(),
  setAccessToken: vi.fn(),
  postApiData: vi.fn(),
}))

vi.mock('sonner', () => ({ toast: { success: vi.fn(), error: vi.fn(), promise: vi.fn() } }))
vi.mock('@/stores/auth-store', () => ({
  useAuthStore: () => ({ auth: { setUser: mocks.setUser, setAccessToken: mocks.setAccessToken } }),
}))
vi.mock('@tanstack/react-router', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@tanstack/react-router')>()
  return {
    ...actual,
    useNavigate: () => mocks.navigate,
    Link: ({ children, to, className, ...rest }: { children?: React.ReactNode; to: string; className?: string }) => (
      <a href={to} className={className} {...rest}>{children}</a>
    ),
  }
})
vi.mock('@/lib/api-client', async (importOriginal) => {
  const actual = await importOriginal<typeof import('@/lib/api-client')>()
  return { ...actual, postApiData: mocks.postApiData }
})

describe('UserAuthForm', () => {
  beforeEach(() => {
    vi.clearAllMocks()
    mocks.postApiData.mockResolvedValue({
      accessToken: 'mock-access-token',
      user: { accountNo: 'acct-42', name: 'Test Student', email: '998901234567', role: ['Student'], exp: 123456 },
    })
  })

  it('renders accessible phone/password fields, submit button, and forgot password link', async () => {
    const screen = await render(<UserAuthForm />)
    await expect.element(screen.getByRole('textbox', { name: /^Phone number$/i })).toBeInTheDocument()
    await expect.element(screen.getByLabelText(/^Password$/i)).toBeInTheDocument()
    await expect.element(screen.getByRole('button', { name: /^Sign in$/i })).toBeInTheDocument()
    await expect.element(screen.getByText(/^Forgot password\?$/i)).toBeInTheDocument()
  })

  it('shows field-level validation messages for missing phone and password', async () => {
    const screen = await render(<UserAuthForm />)
    await userEvent.click(screen.getByRole('button', { name: /^Sign in$/i }))
    await expect.element(screen.getByText('Please enter a valid phone number.')).toBeInTheDocument()
    await expect.element(screen.getByText('Please enter your password.')).toBeInTheDocument()
  })

  it('authenticates with normalized phone and navigates to the default route', async () => {
    const screen = await render(<UserAuthForm />)
    await userEvent.fill(screen.getByRole('textbox', { name: /^Phone number$/i }), '+998 (90) 123-45-67')
    await userEvent.fill(screen.getByLabelText(/^Password$/i), '1234567')
    await userEvent.click(screen.getByRole('button', { name: /^Sign in$/i }))

    await vi.waitFor(() => expect(mocks.postApiData).toHaveBeenCalledOnce())
    expect(mocks.postApiData).toHaveBeenCalledWith('/auth/login', { phone: '998901234567', password: '1234567' })
    expect(mocks.setUser).toHaveBeenCalledWith(expect.objectContaining({ accountNo: 'acct-42', role: ['Student'] }))
    expect(mocks.setAccessToken).toHaveBeenCalledWith('mock-access-token')
    await vi.waitFor(() => expect(mocks.navigate).toHaveBeenCalledWith({ to: '/', replace: true }))
  })

  it('navigates to redirectTo when provided', async () => {
    const screen = await render(<UserAuthForm redirectTo='/settings' />)
    await userEvent.fill(screen.getByRole('textbox', { name: /^Phone number$/i }), '998901234567')
    await userEvent.fill(screen.getByLabelText(/^Password$/i), '1234567')
    await userEvent.click(screen.getByRole('button', { name: /^Sign in$/i }))
    await vi.waitFor(() => expect(mocks.navigate).toHaveBeenCalledWith({ to: '/settings', replace: true }))
  })
})
