import { z } from 'zod'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import axios from 'axios'
import { Link, useNavigate } from '@tanstack/react-router'
import { ArrowRight, Loader2, LockKeyhole, Phone } from 'lucide-react'
import { toast } from 'sonner'
import { useAuthStore } from '@/stores/auth-store'
import { apiErrorMessage, postApiData } from '@/lib/api-client'
import { cn } from '@/lib/utils'
import { useLanguage } from '@/context/language-provider'
import { Button } from '@/components/ui/button'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import { Input } from '@/components/ui/input'
import { PasswordInput } from '@/components/password-input'

interface UserAuthFormProps extends React.HTMLAttributes<HTMLFormElement> {
  redirectTo?: string
}

export function UserAuthForm({
  className,
  redirectTo,
  ...props
}: UserAuthFormProps) {
  const navigate = useNavigate()
  const { auth } = useAuthStore()
  const { t, language } = useLanguage()
  const english = language === 'en'
  const formSchema = z.object({
    phone: z.string().trim().min(5, english ? 'Please enter a valid phone number.' : 'Telefon raqamini kiriting (masalan: 998901234567).'),
    password: z.string().min(1, t('passwordRequired')),
  })
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: { phone: '', password: '' },
  })
  async function onSubmit(data: z.infer<typeof formSchema>) {
    const phone = data.phone.replace(/\D/g, '')
    try {
      const response = await postApiData<{
        accessToken: string
        user: { accountNo: string; name?: string; email: string; role: string[]; exp: number }
      }>('/auth/login', { phone, password: data.password })
      auth.setUser(response.user)
      auth.setAccessToken(response.accessToken)
      const role = response.user.role[0]
      toast.success(`${t('welcomeBack')}, ${role} ${t('dashboard').toLowerCase()}`)
      navigate({
        to: role === 'Teacher' ? '/teacher' : role === 'Finance' ? '/finance' : role === 'Director' ? '/director' : redirectTo || '/',
        replace: true,
      })
    } catch (error) {
      if (axios.isAxiosError(error) && (!error.response || (error.response.status ?? 0) >= 500)) toast.error(apiErrorMessage(error))
      else form.setError('root', { message: t('invalidCredentials') })
    }
  }
  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(onSubmit)}
        noValidate
        className={cn('grid gap-4', className)}
        {...props}
      >
        <FormField
          control={form.control}
          name='phone'
          render={({ field }) => (
            <FormItem className='space-y-1.5'>
              <FormLabel className='text-sm leading-5 font-semibold text-slate-800'>
                {t('phoneNumber')}
              </FormLabel>
              <div className='group relative'>
                <Phone aria-hidden='true' className='pointer-events-none absolute start-4 top-1/2 size-[17px] -translate-y-1/2 text-slate-400 transition-colors group-focus-within:text-emerald-600' />
                <FormControl>
                  <Input
                    type='tel'
                    inputMode='tel'
                    autoComplete='tel'
                    placeholder='998901234567'
                    className='h-11 rounded-lg border-slate-200 bg-slate-50/50 ps-11 shadow-none transition-all placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-500/10'
                    {...field}
                  />
                </FormControl>
              </div>
              <div className='min-h-1'>
                <FormMessage className='mt-2 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-medium text-rose-700' />
              </div>
            </FormItem>
          )}
        />
        <FormField
          control={form.control}
          name='password'
          render={({ field }) => (
            <FormItem className='relative space-y-1.5'>
              <div className='flex items-center justify-between gap-2 leading-5'>
                <FormLabel className='text-sm font-semibold text-slate-800'>
                  {t('password')}
                </FormLabel>
                <Link
                  to='/forgot-password'
                  className='text-xs font-semibold text-emerald-700 transition-colors hover:text-emerald-800'
                >
                  {t('forgotPasswordQuestion')}
                </Link>
              </div>
              <div className='group relative'>
                <LockKeyhole className='pointer-events-none absolute start-4 top-1/2 z-10 size-[17px] -translate-y-1/2 text-slate-400 transition-colors group-focus-within:text-emerald-600' />
                <FormControl>
                  <PasswordInput
                    autoComplete='current-password'
                    placeholder='********'
                    className='w-full'
                    inputClassName='h-11 rounded-lg border-slate-200 bg-slate-50/50 ps-11 shadow-none transition-all placeholder:text-slate-400 focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-500/10'
                    {...field}
                  />
                </FormControl>
              </div>
              <FormMessage className='mt-2 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-medium text-rose-700' />
            </FormItem>
          )}
        />
        <div className='-mt-2 min-h-0' aria-live='polite'>
          {form.formState.errors.root?.message && (
            <p className='flex items-center gap-2 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2.5 text-xs font-semibold text-rose-700 shadow-sm' role='alert'>
              <span aria-hidden='true'>!</span>
              {form.formState.errors.root.message}
            </p>
          )}
        </div>
        <Button
          type='submit'
          disabled={form.formState.isSubmitting}
          className='-mt-1 h-11 rounded-lg bg-[#29a956] text-[15px] font-bold shadow-[0_12px_24px_-10px_rgba(5,120,87,0.8)] transition-all hover:bg-[#218c48] hover:shadow-[0_16px_28px_-10px_rgba(5,120,87,0.9)]'
        >
          {form.formState.isSubmitting ? <Loader2 className='size-4 animate-spin' /> : <ArrowRight className='size-4' />}
          <span>{t('signIn')}</span>
        </Button>
        <div className='relative flex items-center py-0.5'>
          <div className='h-px flex-1 bg-slate-100' />
          <span className='px-3 text-[11px] font-medium text-slate-400'>
            {t('continueWith')}
          </span>
          <div className='h-px flex-1 bg-slate-100' />
        </div>
        <Link
          to='/sign-up'
          className='flex h-10 items-center justify-center rounded-lg border border-slate-200 bg-white text-sm font-semibold text-emerald-700 shadow-none transition-all hover:border-emerald-200 hover:bg-emerald-50/50'
        >
          {t('signUp')}
        </Link>
      </form>
    </Form>
  )
}
