import { useMemo, useState } from 'react'
import { z } from 'zod'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { useNavigate } from '@tanstack/react-router'
import { ArrowRight, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { sleep, cn } from '@/lib/utils'
import { useLanguage } from '@/context/language-provider'
import { Button } from '@/components/ui/button'
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form'
import { Input } from '@/components/ui/input'

export function ForgotPasswordForm({
  className,
  ...props
}: React.HTMLAttributes<HTMLFormElement>) {
  const navigate = useNavigate()
  const { language, t } = useLanguage()
  const [isLoading, setIsLoading] = useState(false)
  const formSchema = useMemo(
    () => z.object({
      email: z.string().trim().min(1, t('emailRequired')).email(t('emailInvalid')),
    }),
    [t]
  )

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: { email: '' },
  })

  function onSubmit(data: z.infer<typeof formSchema>) {
    setIsLoading(true)

    toast.promise(sleep(2000), {
      loading: language === 'en' ? 'Sending email...' : 'Xat yuborilmoqda...',
      success: () => {
        setIsLoading(false)
        form.reset()
        navigate({ to: '/otp' })
        return language === 'en'
          ? `An email was sent to ${data.email}.`
          : `${data.email} manziliga xat yuborildi`
      },
      error: language === 'en' ? 'Something went wrong.' : 'Xatolik yuz berdi',
    })
  }

  return (
    <Form {...form}>
      <form
        onSubmit={form.handleSubmit(onSubmit)}
        noValidate
        className={cn('grid gap-2', className)}
        {...props}
      >
        <FormField
          control={form.control}
          name='email'
          render={({ field }) => (
            <FormItem>
              <FormLabel className='text-sm font-semibold tracking-tight text-slate-800'>{t('email')}</FormLabel>
              <FormControl>
                <Input type='email' inputMode='email' placeholder='name@example.com' className='h-11 rounded-xl border-slate-200 bg-slate-50/70 shadow-sm transition-all focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-500/10' {...field} />
              </FormControl>
              <FormMessage className='mt-1.5 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-medium text-rose-700' />
            </FormItem>
          )}
        />
        <Button
          className='mt-2 h-11 rounded-lg bg-[#29a956] text-[15px] font-bold shadow-[0_12px_24px_-10px_rgba(5,150,105,0.8)] transition-all hover:bg-[#218c48] hover:shadow-[0_16px_28px_-10px_rgba(5,150,105,0.9)]'
          disabled={isLoading}
        >
          {language === 'en' ? 'Continue' : 'Davom etish'}
          {isLoading ? <Loader2 className='animate-spin' /> : <ArrowRight />}
        </Button>
      </form>
    </Form>
  )
}
