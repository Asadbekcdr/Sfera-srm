import { useState } from 'react'
import { z } from 'zod'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Loader2, LockKeyhole, Mail, UserPlus } from 'lucide-react'
import { toast } from 'sonner'
import { sleep, cn } from '@/lib/utils'
import { useLanguage } from '@/context/language-provider'
import { Button } from '@/components/ui/button'
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form'
import { Input } from '@/components/ui/input'
import { PasswordInput } from '@/components/password-input'

export function SignUpForm({ className, ...props }: React.HTMLAttributes<HTMLFormElement>) {
  const [isLoading, setIsLoading] = useState(false)
  const { t } = useLanguage()
  const formSchema = z.object({ email: z.string().trim().min(1, t('emailRequired')).email(t('emailInvalid')), password: z.string().min(1, t('passwordRequired')).min(7, t('passwordLength')), confirmPassword: z.string().min(1, t('confirmPasswordRequired')) }).refine((data) => data.password === data.confirmPassword, { message: t('passwordMismatch'), path: ['confirmPassword'] })
  const form = useForm<z.infer<typeof formSchema>>({ resolver: zodResolver(formSchema), defaultValues: { email: '', password: '', confirmPassword: '' } })
  function onSubmit(data: z.infer<typeof formSchema>) { setIsLoading(true); toast.promise(sleep(700), { loading: t('creatingAccount'), success: () => { setIsLoading(false); return t('accountCreated') }, error: t('accountCreateError') }); void data }
  return <Form {...form}><form noValidate onSubmit={form.handleSubmit(onSubmit)} className={cn('grid gap-3.5', className)} {...props}>
    <FormField control={form.control} name='email' render={({ field }) => <FormItem className='space-y-1.5'><FormLabel className='text-sm font-semibold tracking-tight text-slate-800'>{t('email')}</FormLabel><div className='group relative'><Mail className='pointer-events-none absolute start-4 top-1/2 size-[17px] -translate-y-1/2 text-slate-400 transition-colors group-focus-within:text-emerald-600' /><FormControl><Input type='email' placeholder='name@example.com' className='h-11 rounded-xl border-slate-200 bg-slate-50/70 ps-11 shadow-[0_5px_16px_-12px_rgba(15,23,42,0.35)] transition-all focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-500/10' {...field} /></FormControl></div><FormMessage className='mt-1.5 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-medium text-rose-700' /></FormItem>} />
    <FormField control={form.control} name='password' render={({ field }) => <FormItem className='space-y-1.5'><FormLabel className='text-sm font-semibold tracking-tight text-slate-800'>{t('password')}</FormLabel><div className='group relative'><LockKeyhole className='pointer-events-none absolute start-4 top-1/2 z-10 size-[17px] -translate-y-1/2 text-slate-400 transition-colors group-focus-within:text-emerald-600' /><FormControl><PasswordInput placeholder='********' className='w-full' inputClassName='h-11 rounded-xl border-slate-200 bg-slate-50/70 ps-11 shadow-[0_5px_16px_-12px_rgba(15,23,42,0.35)] transition-all focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-500/10' {...field} /></FormControl></div><FormMessage className='mt-1.5 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-medium text-rose-700' /></FormItem>} />
    <FormField control={form.control} name='confirmPassword' render={({ field }) => <FormItem className='space-y-1.5'><FormLabel className='text-sm font-semibold tracking-tight text-slate-800'>{t('confirmPassword')}</FormLabel><div className='group relative'><LockKeyhole className='pointer-events-none absolute start-4 top-1/2 z-10 size-[17px] -translate-y-1/2 text-slate-400 transition-colors group-focus-within:text-emerald-600' /><FormControl><PasswordInput placeholder='********' className='w-full' inputClassName='h-11 rounded-xl border-slate-200 bg-slate-50/70 ps-11 shadow-[0_5px_16px_-12px_rgba(15,23,42,0.35)] transition-all focus:border-emerald-500 focus:bg-white focus:ring-4 focus:ring-emerald-500/10' {...field} /></FormControl></div><FormMessage className='mt-1.5 rounded-md border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-medium text-rose-700' /></FormItem>} />
    <Button className='mt-1 h-11 rounded-lg bg-[#29a956] text-[15px] font-bold shadow-[0_12px_24px_-10px_rgba(5,150,105,0.8)] transition-all hover:bg-[#218c48]' disabled={isLoading}>{isLoading ? <Loader2 className='animate-spin' /> : <UserPlus />}<span>{t('createAccount')}</span></Button>
  </form></Form>
}
