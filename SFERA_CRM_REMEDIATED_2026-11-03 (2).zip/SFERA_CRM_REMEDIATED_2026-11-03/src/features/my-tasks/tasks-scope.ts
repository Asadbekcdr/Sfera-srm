import type { Task } from './data/schema'

export function filterTasksForAssignee(
  tasks: Task[],
  identifiers: Array<string | null | undefined>
): Task[] {
  const normalizedIdentifiers = new Set(
    identifiers
      .map((identifier) => identifier?.trim().toLowerCase())
      .filter((identifier): identifier is string => Boolean(identifier))
  )
  if (normalizedIdentifiers.size === 0) return []

  return tasks
    .filter((task) =>
      task.assignees.some((assignee) =>
        normalizedIdentifiers.has(assignee.trim().toLowerCase())
      )
    )
    .map((task) => ({
      ...task,
      assignees: task.assignees.filter((assignee) =>
        normalizedIdentifiers.has(assignee.trim().toLowerCase())
      ),
    }))
}
