import type { Task } from './data/schema'

export function parseStoredTasks(raw: string | null): Task[] {
  if (!raw) return []
  try {
    const parsed: unknown = JSON.parse(raw)
    return Array.isArray(parsed) ? (parsed as Task[]) : []
  } catch {
    return []
  }
}
