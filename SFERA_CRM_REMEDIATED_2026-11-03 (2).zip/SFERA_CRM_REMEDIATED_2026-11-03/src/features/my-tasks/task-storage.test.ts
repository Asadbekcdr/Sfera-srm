import { describe, expect, it } from 'vitest'
import { parseStoredTasks } from './task-storage'

const storedTask = {
  id: 'task-1',
  title: 'Real assigned task',
  description: '',
  priority: 'medium' as const,
  status: 'todo' as const,
  category: 'academic' as const,
  dueDate: '2026-10-20T12:00:00.000Z',
  assignees: ['student@example.com'],
  createdAt: '2026-10-01T12:00:00.000Z',
  updatedAt: '2026-10-01T12:00:00.000Z',
  createdBy: 'teacher-1',
}

describe('parseStoredTasks', () => {
  it('returns no demo assignments when storage is empty or invalid', () => {
    expect(parseStoredTasks(null)).toEqual([])
    expect(parseStoredTasks('{invalid')).toEqual([])
  })

  it('returns only valid stored task arrays', () => {
    expect(parseStoredTasks(JSON.stringify([storedTask]))).toEqual([storedTask])
    expect(parseStoredTasks(JSON.stringify({ tasks: [storedTask] }))).toEqual([])
  })
})
