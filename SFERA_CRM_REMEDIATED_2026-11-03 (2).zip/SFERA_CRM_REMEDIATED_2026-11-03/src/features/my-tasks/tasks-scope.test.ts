import { describe, expect, it } from 'vitest'
import type { Task } from './data/schema'
import { filterTasksForAssignee } from './tasks-scope'

const task = (id: string, assignees: string[]): Task => ({
  id,
  title: `Task ${id}`,
  description: 'Assigned task',
  priority: 'medium',
  status: 'todo',
  category: 'academic',
  dueDate: '2026-10-20T12:00:00.000Z',
  assignees,
  createdAt: '2026-10-01T12:00:00.000Z',
  updatedAt: '2026-10-01T12:00:00.000Z',
  createdBy: 'teacher-1',
})

describe('filterTasksForAssignee', () => {
  it('returns only exact assignee matches and redacts other assignees', () => {
    expect(
      filterTasksForAssignee(
        [task('own', ['Student One', 'Student Two']), task('other', ['Student Two'])],
        ['student one']
      )
    ).toEqual([task('own', ['Student One'])])
  })

  it('returns no tasks when no signed-in account identifier is available', () => {
    expect(filterTasksForAssignee([task('any', ['Student One'])], [])).toEqual([])
  })
})
