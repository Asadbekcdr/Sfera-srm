import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import axios from 'axios'
import { Archive, CalendarClock, Eye, Plus, RefreshCw, Search } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { LeadKanbanBoard } from '@/features/crm-ui/lead-kanban-board'
import { LocalLeadsPanel } from './local-leads-panel'
import { apiClient, apiErrorMessage, getApiData, isBackendEnabled, postApiData } from '@/lib/api-client'
import { useAuthStore } from '@/stores/auth-store'
import { can } from '@/lib/rbac'

type LeadStatus = 'NEW' | 'CONTACT_REQUIRED' | 'CONTACTED' | 'TRIAL_SCHEDULED' | 'TRIAL_ATTENDED' | 'DECISION_PENDING' | 'CONVERTED' | 'LOST' | 'ARCHIVED'
type Lead = {
  id: string; name: string; phone: string; courseId: string | null; courseName: string | null
  status: LeadStatus; source: string; assignedTo: string | null; trialLessonAt: string | null
  convertedStudentId: string | null; notes: string | null; createdAt: string; updatedAt: string
}
type Course = { id: string; name: string }
type Group = { id: string; name: string; courseId: string; courseName?: string; capacity: number; studentsCount?: number }
type LeadEvent = { id: string; type: string; fromStatus: string | null; toStatus: string | null; note: string | null; followUpAt: string | null; createdBy: string | null; createdAt: string }

const stageLabels: Record<LeadStatus, string> = {
  NEW: 'Yangi ariza', CONTACT_REQUIRED: 'Bog‘lanish kerak', CONTACTED: 'Bog‘lanildi',
  TRIAL_SCHEDULED: 'Sinov darsi belgilandi', TRIAL_ATTENDED: 'Sinov darsida qatnashdi',
  DECISION_PENDING: 'Qaror kutilmoqda', CONVERTED: 'Kursga yozildi', LOST: 'Kursga yozilmadi', ARCHIVED: 'Arxivlandi',
}
const stages = Object.keys(stageLabels) as LeadStatus[]
const sourceOptions = ['Telegram', 'Instagram', 'Sayt', 'Telefon', 'Tavsiya', 'Boshqa']
const inputClass = 'min-h-9 w-full rounded-md border bg-background px-3 py-2 text-sm'
const localDateTime = (value?: string | null) => value ? new Date(value).toLocaleString('uz-UZ') : '—'
const toLocalDateTimeInput = (value: string) => {
  const date = new Date(value)
  return new Date(date.getTime() - date.getTimezoneOffset() * 60_000).toISOString().slice(0, 16)
}
const errorText = (error: unknown) => {
  if (axios.isAxiosError(error)) {
    const payload = error.response?.data as { message?: string | { message?: string } } | undefined
    if (typeof payload?.message === 'string') return payload.message
    if (payload?.message && typeof payload.message === 'object' && payload.message.message) return payload.message.message
    return apiErrorMessage(error)
  }
  return error instanceof Error ? error.message : 'Amalni bajarib bo‘lmadi.'
}

export function LeadsPanel({ english }: { english: boolean }) {
  const queryClient = useQueryClient()
  const userRole = useAuthStore((state) => state.auth.user?.role)
  const canArchive = can(userRole, 'leads.archive')
  const [search, setSearch] = useState('')
  const [status, setStatus] = useState('all')
  const [courseFilter, setCourseFilter] = useState('')
  const [managerFilter, setManagerFilter] = useState('')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [view, setView] = useState<'table' | 'kanban'>('table')
  const [draggingLead, setDraggingLead] = useState<string | null>(null)
  const [createOpen, setCreateOpen] = useState(false)
  const [selected, setSelected] = useState<Lead | null>(null)
  const [convertLead, setConvertLead] = useState<Lead | null>(null)
  const [conversionCourseId, setConversionCourseId] = useState('')
  const [groupId, setGroupId] = useState('')
  const [trialAt, setTrialAt] = useState('')
  const [trialNote, setTrialNote] = useState('')
  const [editName, setEditName] = useState('')
  const [editPhone, setEditPhone] = useState('')
  const [editCourseId, setEditCourseId] = useState('')
  const [editSource, setEditSource] = useState('other')
  const [editNotes, setEditNotes] = useState('')
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [courseId, setCourseId] = useState('')
  const [source, setSource] = useState('Telegram')
  const [assignedTo, setAssignedTo] = useState('')
  const [initialTrialAt, setInitialTrialAt] = useState('')
  const [notes, setNotes] = useState('')

  const leadsQuery = useQuery({
    queryKey: ['backend', 'leads', search, courseFilter, managerFilter, dateFrom, dateTo],
    queryFn: () => getApiData<Lead[]>('/api/v1/leads', {
      q: search || undefined,
      courseId: courseFilter || undefined,
      assignedTo: managerFilter || undefined,
      from: dateFrom || undefined,
      to: dateTo || undefined,
    }),
    enabled: isBackendEnabled(),
  })
  const coursesQuery = useQuery({
    queryKey: ['backend', 'courses'], queryFn: () => getApiData<Course[]>('/api/v1/courses'),
    enabled: isBackendEnabled(),
  })
  const trialScheduleQuery = useQuery({
    queryKey: ['backend', 'leads', 'scheduled-trials'],
    queryFn: () => getApiData<Lead[]>('/api/v1/leads', { status: 'TRIAL_SCHEDULED' }),
    enabled: isBackendEnabled(),
  })
  const groupsQuery = useQuery({
    queryKey: ['backend', 'groups'], queryFn: () => getApiData<Group[]>('/api/v1/groups'),
    enabled: isBackendEnabled(),
  })
  const eventsQuery = useQuery({
    queryKey: ['backend', 'leads', selected?.id, 'history'],
    queryFn: () => getApiData<LeadEvent[]>(`/api/v1/leads/${selected!.id}/history`),
    enabled: !!selected && isBackendEnabled(),
  })
  const invalidateLeads = () => queryClient.invalidateQueries({ queryKey: ['backend', 'leads'] })

  const createMutation = useMutation({
    mutationFn: () => postApiData<Lead>('/api/v1/leads', {
      name: name.trim(), phone: phone.trim(), courseId: courseId || undefined,
      source, assignedTo: assignedTo.trim() || undefined,
      trialLessonAt: initialTrialAt ? new Date(initialTrialAt).toISOString() : undefined,
      notes: notes.trim() || undefined,
    }),
    onSuccess: () => {
      invalidateLeads(); setCreateOpen(false); setName(''); setPhone(''); setCourseId(''); setNotes(''); setAssignedTo(''); setInitialTrialAt('')
      toast.success('Yangi ariza saqlandi.')
    },
    onError: (error) => toast.error(errorText(error)),
  })
  const statusMutation = useMutation({
    mutationFn: ({ id, next }: { id: string; next: LeadStatus }) => apiClient.patch(`/api/v1/leads/${id}/status`, { status: next }),
    onSuccess: () => { invalidateLeads(); toast.success('Ariza holati yangilandi.') },
    onError: (error) => { invalidateLeads(); toast.error(errorText(error)) },
  })
  const trialMutation = useMutation({
    mutationFn: ({ lead, outcome }: { lead: Lead; outcome: 'scheduled' | 'attended' | 'absent' }) =>
      apiClient.patch(`/api/v1/leads/${lead.id}/trial`, {
        scheduledAt: trialAt ? new Date(trialAt).toISOString() : lead.trialLessonAt,
        outcome, note: trialNote.trim() || undefined,
      }),
    onSuccess: () => { invalidateLeads(); queryClient.invalidateQueries({ queryKey: ['backend', 'leads', selected?.id, 'history'] }); toast.success('Sinov darsi ma’lumoti saqlandi.') },
    onError: (error) => toast.error(errorText(error)),
  })
  const convertMutation = useMutation({
    mutationFn: () => postApiData(`/api/v1/leads/${convertLead!.id}/convert`, { groupId }),
    onSuccess: () => { invalidateLeads(); setConvertLead(null); setGroupId(''); toast.success('O‘quvchi, enrollment va hisob-faktura yaratildi.') },
    onError: (error) => toast.error(errorText(error)),
  })
  const editMutation = useMutation({
    mutationFn: () => apiClient.patch(`/api/v1/leads/${selected!.id}`, {
      name: editName.trim(), phone: editPhone.trim(), courseId: editCourseId || undefined,
      source: editSource, notes: editNotes.trim() || undefined,
    }),
    onSuccess: () => { invalidateLeads(); queryClient.invalidateQueries({ queryKey: ['backend', 'leads', selected?.id, 'history'] }); toast.success('Ariza ma’lumotlari yangilandi.') },
    onError: (error) => toast.error(errorText(error)),
  })
  const archiveMutation = useMutation({
    mutationFn: (lead: Lead) => apiClient.patch(`/api/v1/leads/${lead.id}/archive`),
    onSuccess: () => { invalidateLeads(); setSelected(null); toast.success('Ariza arxivlandi. Tarix saqlanib qoldi.') },
    onError: (error) => toast.error(errorText(error)),
  })

  const leads = leadsQuery.data ?? []
  const visibleLeads = leads.filter((lead) => status === 'all' || lead.status === status)
  const filteredGroups = (groupsQuery.data ?? []).filter((group) => group.courseId === conversionCourseId)
  const scheduleTrial = (lead: Lead, outcome: 'scheduled' | 'attended' | 'absent') => {
    if (!trialAt && !lead.trialLessonAt) { toast.error('Sinov darsi sanasi va vaqtini kiriting.'); return }
    trialMutation.mutate({ lead, outcome })
  }
  const moveLead = (lead: Lead, next: string) => {
    if (next !== 'ARCHIVED' && lead.status !== 'ARCHIVED' && stages.includes(next as LeadStatus) && lead.status !== next) statusMutation.mutate({ id: lead.id, next: next as LeadStatus })
  }
  const openDetails = (lead: Lead) => {
    setSelected(lead); setTrialAt(lead.trialLessonAt ? toLocalDateTimeInput(lead.trialLessonAt) : '')
    setEditName(lead.name); setEditPhone(lead.phone); setEditCourseId(lead.courseId ?? '')
    setEditSource(lead.source); setEditNotes(lead.notes ?? '')
  }

  if (!isBackendEnabled()) {
    return <LocalLeadsPanel english={english} />
  }

  return <div className='space-y-4'>
    <Card>
      <CardHeader className='space-y-3'>
        <div className='flex flex-wrap items-start justify-between gap-3'>
          <div><CardTitle>{english ? 'New applications' : 'Yangi arizalar'}</CardTitle><CardDescription>Lead jarayonini boshqaring, sinov darslarini belgilang va o‘quvchiga aylantiring.</CardDescription></div>
          <Button onClick={() => setCreateOpen(true)}><Plus className='mr-1 size-4' />Ariza qo‘shish</Button>
        </div>
        <div className='flex flex-wrap gap-2'>
          <div className='relative min-w-[220px] flex-1'><Search className='absolute left-2.5 top-2.5 size-4 text-muted-foreground' /><Input className='pl-8' value={search} onChange={(event) => setSearch(event.target.value)} placeholder='Ism yoki telefon bo‘yicha qidirish' /></div>
          <select className={inputClass + ' w-auto min-w-[200px]'} value={status} onChange={(event) => setStatus(event.target.value)}><option value='all'>Barcha holatlar</option>{stages.map((value) => <option key={value} value={value}>{stageLabels[value]}</option>)}</select><Button size='sm' variant={view === 'table' ? 'default' : 'outline'} onClick={() => setView('table')}>Jadval</Button><Button size='sm' variant={view === 'kanban' ? 'default' : 'outline'} onClick={() => setView('kanban')}>Kanban</Button>
          <Button variant='outline' size='icon' aria-label='Yangilash' onClick={() => leadsQuery.refetch()}><RefreshCw className='size-4' /></Button>
        </div>
        <div className='grid gap-2 sm:grid-cols-2 lg:grid-cols-4'>
          <select className={inputClass} value={courseFilter} onChange={(event) => setCourseFilter(event.target.value)}><option value=''>Barcha kurslar</option>{(coursesQuery.data ?? []).map((course) => <option key={course.id} value={course.id}>{course.name}</option>)}</select>
          <Input placeholder='Mas’ul xodim ID' value={managerFilter} onChange={(event) => setManagerFilter(event.target.value)} />
          <Input type='date' aria-label='Boshlanish sanasi' value={dateFrom} onChange={(event) => setDateFrom(event.target.value)} />
          <Input type='date' aria-label='Tugash sanasi' value={dateTo} onChange={(event) => setDateTo(event.target.value)} />
        </div>
        <div className='grid grid-cols-2 gap-2 sm:grid-cols-4 xl:grid-cols-8'>{stages.map((item) => <button type='button' key={item} onClick={() => setStatus(status === item ? 'all' : item)} className={`rounded-lg border px-2 py-2 text-left text-xs transition-colors ${status === item ? 'border-primary bg-primary/5' : 'hover:bg-muted/50'}`}><span className='block truncate text-muted-foreground'>{stageLabels[item]}</span><strong className='mt-1 block text-base'>{leads.filter((lead) => lead.status === item).length}</strong></button>)}</div>
      </CardHeader>
      <CardContent>
        {leadsQuery.isLoading ? <div className='py-10 text-center text-sm text-muted-foreground'>Arizalar yuklanmoqda…</div>
          : leadsQuery.isError ? <div className='rounded-lg border border-destructive/30 p-4 text-sm text-destructive'>{errorText(leadsQuery.error)} <Button variant='outline' size='sm' className='ml-2' onClick={() => leadsQuery.refetch()}>Qayta urinish</Button></div>
          : leads.length === 0 ? <div className='py-10 text-center text-sm text-muted-foreground'>Arizalar topilmadi. Yangi ariza qo‘shishingiz mumkin.</div>
          : view === 'kanban' ? <LeadKanbanBoard leads={visibleLeads.map((lead) => ({ id: lead.id, name: lead.name, phone: lead.phone, course: lead.courseName ?? '—', status: lead.status, date: new Date(lead.createdAt).toLocaleDateString(), assignedTo: lead.assignedTo ?? undefined, trialLessonAt: lead.trialLessonAt }))} english={english} draggingLead={draggingLead} onMove={(card, next) => { const row = leads.find((item) => item.id === card.id); if (row) moveLead(row, next) }} onOpen={(card) => { const row = leads.find((item) => item.id === card.id); if (row) openDetails(row) }} onDragStart={setDraggingLead} onDragEnd={() => setDraggingLead(null)} /> : <div className='overflow-x-auto rounded-lg border'><table className='w-full min-w-[950px] text-left text-sm'><thead className='bg-muted/50 text-xs text-muted-foreground'><tr><th className='p-3'>Ism / telefon</th><th className='p-3'>Kurs</th><th className='p-3'>Manba</th><th className='p-3'>Sinov darsi</th><th className='p-3'>Holati</th><th className='p-3'>Amallar</th></tr></thead><tbody className='divide-y'>{visibleLeads.map((lead) => <tr key={lead.id} className='hover:bg-muted/20'><td className='p-3'><strong>{lead.name}</strong><span className='block text-xs text-muted-foreground'>{lead.phone}</span></td><td className='p-3'>{lead.courseName ?? '—'}</td><td className='p-3'>{lead.source}</td><td className='p-3 text-xs'>{localDateTime(lead.trialLessonAt)}</td><td className='p-3'><select aria-label={`${lead.name} holati`} className='max-w-[210px] rounded-md border bg-background px-2 py-1.5 text-xs' value={lead.status} disabled={lead.status === 'CONVERTED' || lead.status === 'ARCHIVED' || statusMutation.isPending} onChange={(event) => moveLead(lead, event.target.value)}>{stages.filter((item) => item !== 'CONVERTED' && item !== 'ARCHIVED').map((item) => <option key={item} value={item}>{stageLabels[item]}</option>)}{(lead.status === 'CONVERTED' || lead.status === 'ARCHIVED') && <option value={lead.status}>{stageLabels[lead.status]}</option>}</select></td><td className='p-3'><div className='flex gap-1'><Button size='icon' variant='ghost' title='Tafsilot va tarix' onClick={() => openDetails(lead)}><Eye className='size-4' /></Button>{lead.status !== 'CONVERTED' && lead.status !== 'ARCHIVED' && <Button size='sm' variant='outline' onClick={() => { setConvertLead(lead); setConversionCourseId(lead.courseId ?? ''); setGroupId('') }}>O‘quvchiga yozish</Button>}{canArchive && lead.status !== 'CONVERTED' && lead.status !== 'ARCHIVED' && <Button size='icon' variant='ghost' title='Arxivlash' disabled={archiveMutation.isPending} onClick={() => { if (window.confirm(`${lead.name} arxivlansinmi? Tarix saqlanib qoladi.`)) archiveMutation.mutate(lead) }}><Archive className='size-4' /></Button>}</div></td></tr>)}</tbody></table></div>}
      </CardContent>
    </Card>

    <Card><CardHeader className='pb-3'><CardTitle className='text-base'>Rejalashtirilgan sinov darslari</CardTitle><CardDescription>Kelgusi darslarni alohida kuzating; yozuvlar bazadan olinadi.</CardDescription></CardHeader><CardContent>{trialScheduleQuery.isLoading ? <p className='py-4 text-sm text-muted-foreground'>Jadval yuklanmoqda…</p> : trialScheduleQuery.isError ? <p className='py-4 text-sm text-destructive'>Sinov darslari ro‘yxatini olishda xatolik yuz berdi.</p> : (trialScheduleQuery.data ?? []).length === 0 ? <p className='py-4 text-sm text-muted-foreground'>Rejalashtirilgan sinov darsi yo‘q.</p> : <div className='overflow-x-auto rounded-lg border'><table className='w-full min-w-[650px] text-left text-sm'><thead className='bg-muted/50 text-xs text-muted-foreground'><tr><th className='p-3'>Vaqt</th><th className='p-3'>Lead</th><th className='p-3'>Kurs</th><th className='p-3'>Mas’ul xodim</th><th className='p-3'></th></tr></thead><tbody className='divide-y'>{[...(trialScheduleQuery.data ?? [])].sort((a, b) => (a.trialLessonAt ?? '').localeCompare(b.trialLessonAt ?? '')).map((lead) => <tr key={lead.id}><td className='p-3 text-xs'>{localDateTime(lead.trialLessonAt)}</td><td className='p-3'><strong>{lead.name}</strong><span className='block text-xs text-muted-foreground'>{lead.phone}</span></td><td className='p-3'>{lead.courseName ?? '—'}</td><td className='p-3 text-xs'>{lead.assignedTo ?? 'Tayinlanmagan'}</td><td className='p-3'><Button variant='outline' size='sm' onClick={() => openDetails(lead)}>Tafsilot</Button></td></tr>)}</tbody></table></div>}</CardContent></Card>

    <Dialog open={createOpen} onOpenChange={setCreateOpen}><DialogContent className='sm:max-w-lg'><DialogHeader><DialogTitle>Yangi ariza kiritish</DialogTitle></DialogHeader><div className='grid gap-3'><Input autoFocus placeholder='Ism va familiya *' value={name} onChange={(event) => setName(event.target.value)} /><Input placeholder='Telefon raqami *' inputMode='tel' value={phone} onChange={(event) => setPhone(event.target.value)} /><select className={inputClass} value={courseId} onChange={(event) => setCourseId(event.target.value)}><option value=''>Kursni tanlang (ixtiyoriy)</option>{(coursesQuery.data ?? []).map((course) => <option key={course.id} value={course.id}>{course.name}</option>)}</select><select className={inputClass} value={source} onChange={(event) => setSource(event.target.value)}>{sourceOptions.map((item) => <option key={item} value={item}>{item}</option>)}</select><Input placeholder='Mas’ul xodim ID (ixtiyoriy)' value={assignedTo} onChange={(event) => setAssignedTo(event.target.value)} /><Input type='datetime-local' aria-label='Sinov darsi vaqti' value={initialTrialAt} onChange={(event) => setInitialTrialAt(event.target.value)} /><textarea className={inputClass + ' min-h-20'} placeholder='Izoh' value={notes} onChange={(event) => setNotes(event.target.value)} /></div><DialogFooter><Button variant='outline' onClick={() => setCreateOpen(false)}>Bekor qilish</Button><Button disabled={createMutation.isPending || !name.trim() || !phone.trim()} onClick={() => createMutation.mutate()}>{createMutation.isPending ? 'Saqlanmoqda…' : 'Saqlash'}</Button></DialogFooter></DialogContent></Dialog>

    <Dialog open={!!selected} onOpenChange={(open) => { if (!open) setSelected(null) }}><DialogContent className='max-h-[90vh] overflow-y-auto sm:max-w-xl'><DialogHeader><DialogTitle>{selected?.name}</DialogTitle><CardDescription>{selected?.phone} · {selected?.courseName ?? 'Kurs tanlanmagan'} · {selected ? stageLabels[selected.status] : ''}</CardDescription></DialogHeader><div className='space-y-4'><div className='grid gap-2 rounded-lg border p-3 sm:grid-cols-2'><Input placeholder='Ism va familiya' value={editName} onChange={(event) => setEditName(event.target.value)} /><Input placeholder='Telefon' value={editPhone} onChange={(event) => setEditPhone(event.target.value)} /><select className={inputClass} value={editCourseId} onChange={(event) => setEditCourseId(event.target.value)}><option value=''>Kurs tanlanmagan</option>{(coursesQuery.data ?? []).map((course) => <option key={course.id} value={course.id}>{course.name}</option>)}</select><select className={inputClass} value={editSource} onChange={(event) => setEditSource(event.target.value)}>{sourceOptions.map((item) => <option key={item} value={item}>{item}</option>)}</select><textarea className={inputClass + ' min-h-20 sm:col-span-2'} placeholder='Izoh' value={editNotes} onChange={(event) => setEditNotes(event.target.value)} /><p className='text-xs text-muted-foreground sm:col-span-2'>Mas’ul xodim ID: {selected?.assignedTo ?? 'Tayinlanmagan'} · {localDateTime(selected?.createdAt)}</p><Button className='sm:col-span-2' size='sm' disabled={editMutation.isPending || selected?.status === 'CONVERTED' || selected?.status === 'ARCHIVED'} onClick={() => editMutation.mutate()}>{editMutation.isPending ? 'Saqlanmoqda…' : 'Tafsilotlarni saqlash'}</Button></div><section className='space-y-2 rounded-lg border p-3'><h3 className='flex items-center gap-2 text-sm font-semibold'><CalendarClock className='size-4' />Sinov darsi</h3><Input type='datetime-local' value={trialAt} onChange={(event) => setTrialAt(event.target.value)} /><Input placeholder='Natija yoki izoh' value={trialNote} onChange={(event) => setTrialNote(event.target.value)} /><div className='flex flex-wrap gap-2'><Button size='sm' disabled={trialMutation.isPending || !trialAt || selected?.status === 'CONVERTED' || selected?.status === 'ARCHIVED'} onClick={() => selected && scheduleTrial(selected, 'scheduled')}>Jadvalga kiritish</Button><Button size='sm' variant='outline' disabled={trialMutation.isPending || !trialAt || selected?.status === 'CONVERTED' || selected?.status === 'ARCHIVED'} onClick={() => selected && scheduleTrial(selected, 'attended')}>Qatnashdi</Button><Button size='sm' variant='outline' disabled={trialMutation.isPending || !trialAt || selected?.status === 'CONVERTED' || selected?.status === 'ARCHIVED'} onClick={() => selected && scheduleTrial(selected, 'absent')}>Kelmagan</Button></div></section><section className='space-y-2'><h3 className='text-sm font-semibold'>Aloqa va o‘zgarishlar tarixi</h3>{eventsQuery.isLoading ? <p className='text-xs text-muted-foreground'>Tarix yuklanmoqda…</p> : eventsQuery.isError ? <p className='text-xs text-destructive'>Tarixni olishda xatolik yuz berdi.</p> : (eventsQuery.data ?? []).length === 0 ? <p className='text-xs text-muted-foreground'>Hali tarix yozuvi yo‘q.</p> : <ol className='max-h-48 space-y-2 overflow-y-auto'>{eventsQuery.data!.map((event) => <li key={event.id} className='rounded-md border p-2 text-xs'><span className='text-muted-foreground'>{localDateTime(event.createdAt)}</span><span className='ml-2 font-medium'>{event.type}</span>{event.fromStatus && <span> · {stageLabels[event.fromStatus as LeadStatus] ?? event.fromStatus} → {stageLabels[event.toStatus as LeadStatus] ?? event.toStatus}</span>}{event.createdBy && <span className='ml-2 text-muted-foreground'>· {event.createdBy}</span>}{event.note && <p className='mt-1'>{event.note}</p>}</li>)}</ol>}</section></div><DialogFooter><Button variant='outline' onClick={() => setSelected(null)}>Yopish</Button></DialogFooter></DialogContent></Dialog>

    <Dialog open={!!convertLead} onOpenChange={(open) => { if (!open) setConvertLead(null) }}><DialogContent><DialogHeader><DialogTitle>{convertLead?.name}ni kursga yozish</DialogTitle><CardDescription>Guruh tanlang. Tizim guruh sig‘imi, academy scope va takroriy enrollment’ni tekshiradi.</CardDescription></DialogHeader><select className={inputClass} value={conversionCourseId} onChange={(event) => { setConversionCourseId(event.target.value); setGroupId('') }}><option value=''>Kursni tanlang</option>{(coursesQuery.data ?? []).map((course) => <option key={course.id} value={course.id}>{course.name}</option>)}</select><select className={inputClass} value={groupId} onChange={(event) => setGroupId(event.target.value)} disabled={!conversionCourseId}><option value=''>Guruhni tanlang</option>{filteredGroups.map((group) => <option key={group.id} value={group.id}>{group.name}{group.courseName ? ` · ${group.courseName}` : ''}</option>)}</select>{filteredGroups.length === 0 && <p className='text-xs text-muted-foreground'>Mos guruh topilmadi. Kurs yoki guruhlarni tekshiring.</p>}<DialogFooter><Button variant='outline' onClick={() => setConvertLead(null)}>Bekor qilish</Button><Button disabled={!groupId || convertMutation.isPending} onClick={() => { if (convertLead && window.confirm(`${convertLead.name}ni tanlangan guruhga yozishni tasdiqlaysizmi?`)) convertMutation.mutate() }}>{convertMutation.isPending ? 'Yozilmoqda…' : 'Tasdiqlash'}</Button></DialogFooter></DialogContent></Dialog>
  </div>
}
