import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { cn } from '@/lib/utils'

export type LeadSelectOption = {
  value: string
  label: string
}

type LeadFormSelectProps = {
  value: string
  onValueChange: (value: string) => void
  options: LeadSelectOption[]
  placeholder?: string
  allowClear?: boolean
  disabled?: boolean
  ariaLabel?: string
  className?: string
}

const EMPTY_VALUE = '__lead_select_empty__'

export function LeadFormSelect({
  value,
  onValueChange,
  options,
  placeholder,
  allowClear = false,
  disabled = false,
  ariaLabel,
  className,
}: LeadFormSelectProps) {
  const selectedValue = value || (allowClear ? EMPTY_VALUE : options[0]?.value)

  return (
    <Select
      value={selectedValue}
      disabled={disabled}
      onValueChange={(nextValue) =>
        onValueChange(nextValue === EMPTY_VALUE ? '' : nextValue)
      }
    >
      <SelectTrigger
        aria-label={ariaLabel ?? placeholder}
        className={cn(
          'h-11 w-full rounded-xl border-border/80 bg-background/80 px-3 text-sm shadow-xs transition-colors hover:border-primary/40 focus-visible:ring-4 focus-visible:ring-primary/10',
          className
        )}
      >
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent
        align='start'
        className='z-[80] max-h-72 rounded-xl border-border/80 bg-popover p-1.5 shadow-2xl shadow-slate-950/15 backdrop-blur-none'
      >
        {allowClear && placeholder && (
          <SelectItem value={EMPTY_VALUE} className='rounded-lg py-2.5'>
            {placeholder}
          </SelectItem>
        )}
        {options.map((option) => (
          <SelectItem
            key={option.value}
            value={option.value}
            className='rounded-lg py-2.5 focus:bg-primary/10 focus:text-primary data-[state=checked]:bg-primary/10 data-[state=checked]:font-semibold data-[state=checked]:text-primary'
          >
            {option.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}
