import { useEffect, useMemo, useState } from 'react'
import {
  Archive,
  ArrowRight,
  CalendarClock,
  CalendarDays,
  CheckCircle2,
  Eye,
  Filter,
  GraduationCap,
  Plus,
  Search,
  UserRound,
  UsersRound,
  type LucideIcon,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { LeadKanbanBoard } from '@/features/crm-ui/lead-kanban-board'
import { LeadFormSelect, type LeadSelectOption } from './components/lead-form-select'

type Status = 'NEW' | 'CONTACT_REQUIRED' | 'CONTACTED' | 'TRIAL_SCHEDULED' | 'TRIAL_ATTENDED' | 'DECISION_PENDING' | 'CONVERTED' | 'LOST' | 'ARCHIVED'
type LocalLead = {
  id: string
  name: string
  phone: string
  courseName: string
  status: Status
  source: string
  assignedTo: string
  trialLessonAt: string
  notes: string
  createdAt: string
  updatedAt: string
  convertedStudentId: string | null
}

type SummaryItem = {
  label: string
  value: number
  hint: string
  icon: LucideIcon
  tone: string
}

const STORAGE_KEY = 'sfera-crm-leads-demo-v1'
const courses = ['Ingliz tili A1', 'Ingliz tili A2', 'Matematika', 'IT va dasturlash']
const sources = ['Telegram', 'Instagram', 'Sayt', 'Telefon', 'Tavsiya', 'Boshqa']
const statusLabels: Record<Status, string> = {
  NEW: 'Yangi ariza',
  CONTACT_REQUIRED: 'Bog‘lanish kerak',
  CONTACTED: 'Bog‘lanildi',
  TRIAL_SCHEDULED: 'Sinov darsi belgilandi',
  TRIAL_ATTENDED: 'Sinov darsida qatnashdi',
  DECISION_PENDING: 'Qaror kutilmoqda',
  CONVERTED: 'Kursga yozildi',
  LOST: 'Kursga yozilmadi',
  ARCHIVED: 'Arxivlandi',
}
const englishStatusLabels: Record<Status, string> = {
  NEW: 'New application',
  CONTACT_REQUIRED: 'Contact required',
  CONTACTED: 'Contacted',
  TRIAL_SCHEDULED: 'Trial scheduled',
  TRIAL_ATTENDED: 'Trial attended',
  DECISION_PENDING: 'Decision pending',
  CONVERTED: 'Enrolled',
  LOST: 'Not enrolled',
  ARCHIVED: 'Archived',
}
const statusOptions = Object.keys(statusLabels) as Status[]
const statusTone: Record<Status, string> = {
  NEW: 'border-sky-200 bg-sky-50 text-sky-700 dark:border-sky-500/20 dark:bg-sky-500/10 dark:text-sky-300',
  CONTACT_REQUIRED: 'border-violet-200 bg-violet-50 text-violet-700 dark:border-violet-500/20 dark:bg-violet-500/10 dark:text-violet-300',
  CONTACTED: 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-300',
  TRIAL_SCHEDULED: 'border-violet-200 bg-violet-50 text-violet-700 dark:border-violet-500/20 dark:bg-violet-500/10 dark:text-violet-300',
  TRIAL_ATTENDED: 'border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-300',
  DECISION_PENDING: 'border-cyan-200 bg-cyan-50 text-cyan-700 dark:border-cyan-500/20 dark:bg-cyan-500/10 dark:text-cyan-300',
  CONVERTED: 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-300',
  LOST: 'border-slate-200 bg-slate-100 text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300',
  ARCHIVED: 'border-zinc-200 bg-zinc-100 text-zinc-600 dark:border-zinc-700 dark:bg-zinc-800 dark:text-zinc-300',
}
const inputClass = 'h-11 rounded-xl border-border/80 bg-background/80 shadow-xs focus-visible:ring-4 focus-visible:ring-primary/10'

function seedLeads(): LocalLead[] {
  const now = new Date().toISOString()
  return [
    { id: 'demo-lead-1', name: 'Madina Karimova', phone: '+998 90 123 45 67', courseName: 'Ingliz tili A1', status: 'NEW', source: 'Telegram', assignedTo: 'Manager', trialLessonAt: '', notes: '', createdAt: now, updatedAt: now, convertedStudentId: null },
    { id: 'demo-lead-2', name: 'Javohir Aliyev', phone: '+998 91 234 56 78', courseName: 'IT va dasturlash', status: 'CONTACTED', source: 'Sayt', assignedTo: 'Manager', trialLessonAt: '', notes: 'Kechki guruhga qiziqmoqda.', createdAt: now, updatedAt: now, convertedStudentId: null },
    { id: 'demo-lead-3', name: 'Sevara Usmonova', phone: '+998 93 345 67 89', courseName: 'Matematika', status: 'TRIAL_SCHEDULED', source: 'Tavsiya', assignedTo: 'Manager', trialLessonAt: new Date(Date.now() + 86_400_000).toISOString(), notes: '', createdAt: now, updatedAt: now, convertedStudentId: null },
  ]
}

function loadLeads(): LocalLead[] {
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY)
    if (saved) {
      const parsed: unknown = JSON.parse(saved)
      if (Array.isArray(parsed)) return parsed as LocalLead[]
    }
  } catch {
    // Fall back to sample leads when storage is unavailable or malformed.
  }
  return seedLeads()
}

const toInputDate = (value: string) => {
  if (!value) return ''
  const date = new Date(value)
  return new Date(date.getTime() - date.getTimezoneOffset() * 60_000).toISOString().slice(0, 16)
}
const displayDate = (value: string, english = false) =>
  value ? new Date(value).toLocaleString(english ? 'en-US' : 'uz-UZ', { dateStyle: 'medium', timeStyle: 'short' }) : '—'
const displayShortDate = (value: string, english = false) =>
  value ? new Date(value).toLocaleDateString(english ? 'en-US' : 'uz-UZ', { day: '2-digit', month: 'short' }) : '—'
const createId = () => globalThis.crypto?.randomUUID?.() ?? `lead-${Date.now()}`
const getStatusLabel = (status: Status, english: boolean) =>
  english ? englishStatusLabels[status] : statusLabels[status]

function getNextStep(lead: LocalLead, english: boolean) {
  if (lead.status === 'NEW' || lead.status === 'CONTACT_REQUIRED') return english ? 'Make first contact' : 'Bog‘lanish'
  if (lead.status === 'CONTACTED') return english ? 'Schedule a trial lesson' : 'Sinov darsini belgilash'
  if (lead.status === 'TRIAL_SCHEDULED') return english ? 'Conduct trial lesson' : 'Sinov darsini o‘tkazish'
  if (lead.status === 'TRIAL_ATTENDED' || lead.status === 'DECISION_PENDING') return english ? 'Discuss enrollment' : 'Kursga yozishni muhokama qilish'
  if (lead.status === 'CONVERTED') return english ? 'Follow up with student' : 'O‘quvchini kuzatish'
  if (lead.status === 'LOST') return english ? 'Record the reason' : 'Sababini qayd etish'
  return english ? 'Keep in archive' : 'Arxivda saqlash'
}

export function LocalLeadsPanel({ english }: { english: boolean }) {
  const [leads, setLeads] = useState<LocalLead[]>(loadLeads)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [courseFilter, setCourseFilter] = useState('all')
  const [sourceFilter, setSourceFilter] = useState('all')
  const [view, setView] = useState<'table' | 'kanban'>('table')
  const [draggingLead, setDraggingLead] = useState<string | null>(null)
  const [createOpen, setCreateOpen] = useState(false)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [courseName, setCourseName] = useState('')
  const [source, setSource] = useState(sources[0])
  const [assignedTo, setAssignedTo] = useState('')
  const [notes, setNotes] = useState('')
  const [editName, setEditName] = useState('')
  const [editPhone, setEditPhone] = useState('')
  const [editCourseName, setEditCourseName] = useState('')
  const [editSource, setEditSource] = useState(sources[0])
  const [editNotes, setEditNotes] = useState('')
  const [trialAt, setTrialAt] = useState('')

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(leads))
    } catch {
      // Local demo still works for this session if browser storage is unavailable.
    }
  }, [leads])

  const selected = leads.find((lead) => lead.id === selectedId) ?? null
  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase()
    return leads.filter((lead) => {
      const matchesSearch = !query || `${lead.name} ${lead.phone} ${lead.courseName} ${lead.source}`.toLowerCase().includes(query)
      return matchesSearch
        && (statusFilter === 'all' || lead.status === statusFilter)
        && (courseFilter === 'all' || lead.courseName === courseFilter)
        && (sourceFilter === 'all' || lead.source === sourceFilter)
    })
  }, [leads, search, statusFilter, courseFilter, sourceFilter])

  const updateLead = (id: string, updates: Partial<LocalLead>) => {
    setLeads((current) => current.map((lead) => lead.id === id
      ? { ...lead, ...updates, updatedAt: new Date().toISOString() }
      : lead))
  }

  const openDetails = (lead: LocalLead) => {
    setSelectedId(lead.id)
    setEditName(lead.name)
    setEditPhone(lead.phone)
    setEditCourseName(lead.courseName)
    setEditSource(lead.source)
    setEditNotes(lead.notes)
    setTrialAt(toInputDate(lead.trialLessonAt))
  }

  const createLead = () => {
    if (!name.trim() || !phone.trim()) return
    const now = new Date().toISOString()
    setLeads((current) => [{
      id: createId(),
      name: name.trim(),
      phone: phone.trim(),
      courseName,
      status: 'NEW',
      source,
      assignedTo: assignedTo.trim(),
      trialLessonAt: '',
      notes: notes.trim(),
      createdAt: now,
      updatedAt: now,
      convertedStudentId: null,
    }, ...current])
    setName('')
    setPhone('')
    setCourseName('')
    setSource(sources[0])
    setAssignedTo('')
    setNotes('')
    setCreateOpen(false)
  }

  const saveDetails = () => {
    if (!selected || !editName.trim() || !editPhone.trim()) return
    updateLead(selected.id, {
      name: editName.trim(),
      phone: editPhone.trim(),
      courseName: editCourseName,
      source: editSource,
      notes: editNotes.trim(),
    })
  }

  const openCreate = () => {
    setName('')
    setPhone('')
    setCourseName('')
    setSource(sources[0])
    setAssignedTo('')
    setNotes('')
    setCreateOpen(true)
  }

  const moveLead = (lead: LocalLead, next: string) => {
    if (statusOptions.includes(next as Status)) updateLead(lead.id, { status: next as Status })
  }

  const resetFilters = () => {
    setSearch('')
    setStatusFilter('all')
    setCourseFilter('all')
    setSourceFilter('all')
  }

  const summary: SummaryItem[] = [
    {
      label: english ? 'Total applications' : 'Jami arizalar',
      value: leads.length,
      hint: english ? 'All incoming leads' : 'Barcha kelib tushgan arizalar',
      icon: UsersRound,
      tone: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300',
    },
    {
      label: english ? 'New applications' : 'Yangi arizalar',
      value: leads.filter((lead) => lead.status === 'NEW').length,
      hint: english ? 'Waiting for first contact' : 'Birinchi aloqani kutmoqda',
      icon: Plus,
      tone: 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300',
    },
    {
      label: english ? 'Trial lessons' : 'Sinov darsi',
      value: leads.filter((lead) => lead.status === 'TRIAL_SCHEDULED').length,
      hint: english ? 'Scheduled with prospects' : 'Rejalashtirilgan darslar',
      icon: CalendarDays,
      tone: 'bg-violet-50 text-violet-700 dark:bg-violet-500/10 dark:text-violet-300',
    },
    {
      label: english ? 'Enrolled' : 'Kursga yozildi',
      value: leads.filter((lead) => lead.status === 'CONVERTED').length,
      hint: english ? 'Converted into students' : 'O‘quvchiga aylantirilganlar',
      icon: GraduationCap,
      tone: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300',
    },
  ]

  const statusSelectOptions: LeadSelectOption[] = statusOptions.map((status) => ({
    value: status,
    label: getStatusLabel(status, english),
  }))
  const courseSelectOptions: LeadSelectOption[] = courses.map((course) => ({ value: course, label: course }))
  const sourceSelectOptions: LeadSelectOption[] = sources.map((item) => ({ value: item, label: item }))

  const mappedForBoard = filtered.map((lead) => ({
    id: lead.id,
    name: lead.name,
    phone: lead.phone,
    course: lead.courseName,
    status: lead.status,
    date: displayShortDate(lead.createdAt, english),
    assignedTo: lead.assignedTo || undefined,
    trialLessonAt: lead.trialLessonAt || null,
  }))

  return (
    <div className='mx-auto w-full max-w-[1600px] space-y-7 pb-8'>
      <section className='flex flex-col justify-between gap-4 border-b border-border/60 pb-5 sm:flex-row sm:items-center'>
        <div className='min-w-0'>
          <p className='mb-1 text-xs font-semibold tracking-[0.16em] text-emerald-700 uppercase dark:text-emerald-400'>SFERA CRM · {english ? 'LEAD MANAGEMENT' : 'ARIZALAR MARKAZI'}</p>
          <h1 className='text-3xl font-bold tracking-tight text-slate-950 dark:text-white'>
            {english ? 'New applications' : 'Yangi arizalar'}
          </h1>
          <p className='mt-1.5 text-sm text-muted-foreground'>
            {english ? 'Track applications and manage the enrollment journey.' : 'Arizalarni kuzatish va qabul jarayonini boshqarish'}
          </p>
        </div>
        <Button onClick={openCreate} className='h-11 shrink-0 rounded-xl bg-emerald-600 px-5 font-semibold text-white shadow-sm shadow-emerald-700/15 hover:bg-emerald-700'>
          <Plus className='mr-2 size-4' />
          {english ? 'New lead' : 'Yangi lead'}
        </Button>
      </section>

      <section aria-label={english ? 'Lead filters' : 'Ariza filtrlari'} className='grid gap-2.5 xl:grid-cols-[minmax(260px,1fr)_220px_220px_220px_44px]'>
        <div className='relative min-w-0'>
          <Search className='absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground' />
          <Input
            className='h-11 rounded-xl border-border/80 bg-background/80 pl-10 shadow-xs placeholder:text-muted-foreground/80 focus-visible:ring-4 focus-visible:ring-emerald-500/10'
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder={english ? 'Search name, phone or course' : 'Ism, telefon yoki kurs bo‘yicha qidirish'}
          />
        </div>
        <LeadFormSelect
          value={statusFilter === 'all' ? '' : statusFilter}
          onValueChange={(value) => setStatusFilter(value || 'all')}
          placeholder={english ? 'All stages' : 'Barcha bosqichlar'}
          allowClear
          options={statusSelectOptions}
        />
        <LeadFormSelect
          value={courseFilter === 'all' ? '' : courseFilter}
          onValueChange={(value) => setCourseFilter(value || 'all')}
          placeholder={english ? 'All courses' : 'Barcha kurslar'}
          allowClear
          options={courseSelectOptions}
        />
        <LeadFormSelect
          value={sourceFilter === 'all' ? '' : sourceFilter}
          onValueChange={(value) => setSourceFilter(value || 'all')}
          placeholder={english ? 'All sources' : 'Barcha manbalar'}
          allowClear
          options={sourceSelectOptions}
        />
        <Button
          type='button'
          variant='outline'
          size='icon'
          aria-label={english ? 'Reset filters' : 'Filtrlarni tozalash'}
          title={english ? 'Reset filters' : 'Filtrlarni tozalash'}
          onClick={resetFilters}
          className='size-11 rounded-xl border-border/80 bg-background/80 text-muted-foreground hover:border-emerald-500/50 hover:bg-emerald-50 hover:text-emerald-700 dark:hover:bg-emerald-500/10 dark:hover:text-emerald-300'
        >
          <Filter className='size-4' />
        </Button>
      </section>

      <section className='grid gap-3 sm:grid-cols-2 xl:grid-cols-4' aria-label={english ? 'Lead summary' : 'Arizalar statistikasi'}>
        {summary.map(({ label, value, hint, icon: Icon, tone }) => (
          <div key={label} className='flex min-h-[112px] items-center gap-4 rounded-2xl border border-border/70 bg-card px-5 py-4 shadow-sm transition-shadow hover:shadow-md'>
            <span className={`flex size-12 shrink-0 items-center justify-center rounded-xl ${tone}`}>
              <Icon className='size-5' />
            </span>
            <span className='min-w-0'>
              <span className='block truncate text-sm font-medium text-muted-foreground'>{label}</span>
              <strong className='mt-0.5 block text-3xl font-bold leading-none tracking-tight text-foreground'>{value}</strong>
              <span className='mt-1 block truncate text-xs text-muted-foreground'>{hint}</span>
            </span>
          </div>
        ))}
      </section>

      <section className='space-y-3'>
        <div className='flex flex-wrap items-center justify-between gap-3'>
          <div className='inline-flex rounded-xl border border-border/70 bg-muted/40 p-1'>
            <Button
              size='sm'
              variant={view === 'table' ? 'default' : 'ghost'}
              onClick={() => setView('table')}
              className={`h-9 rounded-lg px-4 ${view === 'table' ? 'bg-emerald-600 text-white shadow-sm hover:bg-emerald-700' : ''}`}
            >
              {english ? 'Table' : 'Jadval'}
            </Button>
            <Button
              size='sm'
              variant={view === 'kanban' ? 'default' : 'ghost'}
              onClick={() => setView('kanban')}
              className={`h-9 rounded-lg px-4 ${view === 'kanban' ? 'bg-emerald-600 text-white shadow-sm hover:bg-emerald-700' : ''}`}
            >
              Kanban
            </Button>
          </div>
          <p className='text-sm font-medium text-muted-foreground'>
            <span className='font-semibold text-foreground'>{filtered.length}</span>{' '}
            {english ? 'applications' : 'ta ariza'}
          </p>
        </div>

        {filtered.length === 0 ? (
          <div className='rounded-2xl border border-dashed border-border/80 bg-card px-6 py-16 text-center'>
            <span className='mx-auto flex size-12 items-center justify-center rounded-2xl bg-muted text-muted-foreground'><Search className='size-5' /></span>
            <p className='mt-3 font-semibold'>{english ? 'No applications found' : 'Arizalar topilmadi'}</p>
            <p className='mt-1 text-sm text-muted-foreground'>{english ? 'Try changing the search or filters.' : 'Qidiruv yoki filtrlarni o‘zgartirib ko‘ring.'}</p>
          </div>
        ) : view === 'kanban' ? (
          <LeadKanbanBoard
            leads={mappedForBoard}
            english={english}
            draggingLead={draggingLead}
            onMove={(card, next) => {
              const lead = leads.find((item) => item.id === card.id)
              if (lead) moveLead(lead, next)
            }}
            onOpen={(card) => {
              const lead = leads.find((item) => item.id === card.id)
              if (lead) openDetails(lead)
            }}
            onDragStart={setDraggingLead}
            onDragEnd={() => setDraggingLead(null)}
          />
        ) : (
          <div className='overflow-hidden rounded-2xl border border-border/70 bg-card shadow-sm'>
            <div className='overflow-x-auto'>
              <table className='w-full min-w-[950px] text-left text-sm'>
                <thead className='bg-slate-50/90 text-xs font-semibold text-slate-600 dark:bg-slate-900/70 dark:text-slate-300'>
                  <tr>
                    <th className='px-5 py-4'>{english ? 'Lead' : 'Lead'}</th>
                    <th className='px-4 py-4'>{english ? 'Course' : 'Kurs'}</th>
                    <th className='px-4 py-4'>{english ? 'Source' : 'Manba'}</th>
                    <th className='px-4 py-4'>{english ? 'Next step' : 'Keyingi qadam'}</th>
                    <th className='px-4 py-4'>{english ? 'Stage' : 'Bosqich'}</th>
                    <th className='px-4 py-4 text-right'>{english ? 'Actions' : 'Amallar'}</th>
                  </tr>
                </thead>
                <tbody className='divide-y divide-border/60'>
                  {filtered.map((lead) => (
                    <tr key={lead.id} className='group transition-colors hover:bg-emerald-50/30 dark:hover:bg-emerald-500/[0.035]'>
                      <td className='px-5 py-4'>
                        <div className='flex min-w-0 items-center gap-3'>
                          <span className='flex size-10 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-xs font-bold text-slate-700 dark:bg-slate-800 dark:text-slate-200'>
                            {lead.name.split(' ').map((part) => part[0]).join('').slice(0, 2).toUpperCase()}
                          </span>
                          <span className='min-w-0'>
                            <strong className='block truncate font-semibold text-foreground'>{lead.name}</strong>
                            <span className='mt-0.5 block text-xs text-muted-foreground'>{lead.phone}</span>
                          </span>
                        </div>
                      </td>
                      <td className='px-4 py-4 font-medium text-foreground'>{lead.courseName || '—'}</td>
                      <td className='px-4 py-4 text-muted-foreground'>{lead.source}</td>
                      <td className='px-4 py-4'>
                        <span className='inline-flex items-center gap-2 text-sm text-foreground'>
                          <ArrowRight className='size-3.5 shrink-0 text-emerald-600 dark:text-emerald-400' />
                          {getNextStep(lead, english)}
                        </span>
                        {lead.trialLessonAt && <span className='mt-1 block pl-5 text-xs text-muted-foreground'>{displayDate(lead.trialLessonAt, english)}</span>}
                      </td>
                      <td className='px-4 py-4'>
                        <span className={`inline-flex max-w-[210px] items-center gap-1.5 whitespace-nowrap rounded-full border px-3 py-1.5 text-xs font-semibold ${statusTone[lead.status]}`}>
                          <span className='size-1.5 rounded-full bg-current opacity-70' />
                          {getStatusLabel(lead.status, english)}
                        </span>
                      </td>
                      <td className='px-4 py-4'>
                        <div className='flex justify-end gap-1'>
                          <Button size='icon' variant='ghost' title={english ? 'View details' : 'Tafsilot'} aria-label={english ? 'View details' : 'Tafsilot'} onClick={() => openDetails(lead)} className='size-9 rounded-lg text-muted-foreground hover:bg-emerald-50 hover:text-emerald-700 dark:hover:bg-emerald-500/10 dark:hover:text-emerald-300'>
                            <Eye className='size-4' />
                          </Button>
                          {lead.status !== 'ARCHIVED' && lead.status !== 'CONVERTED' && <Button size='icon' variant='ghost' title={english ? 'Archive lead' : 'Arxivlash'} aria-label={english ? 'Archive lead' : 'Arxivlash'} onClick={() => updateLead(lead.id, { status: 'ARCHIVED' })} className='size-9 rounded-lg text-muted-foreground hover:bg-amber-50 hover:text-amber-700 dark:hover:bg-amber-500/10 dark:hover:text-amber-300'><Archive className='size-4' /></Button>}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </section>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className='max-h-[92vh] gap-0 overflow-y-auto border-border/70 bg-card p-0 shadow-2xl sm:max-w-xl'>
          <DialogHeader className='border-b border-border/60 bg-gradient-to-br from-emerald-50/90 via-background to-background px-6 pt-6 pb-5 text-left dark:from-emerald-500/[0.08]'>
            <div className='flex items-start gap-3'>
              <span className='flex size-11 shrink-0 items-center justify-center rounded-xl bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300'><UserRound className='size-5' /></span>
              <div className='space-y-1'>
                <DialogTitle className='text-xl'>{english ? 'Create a new lead' : 'Yangi ariza kiritish'}</DialogTitle>
                <DialogDescription>{english ? 'Add contact details and start following the application.' : 'Aloqa ma’lumotlarini kiriting va arizani kuzatishni boshlang.'}</DialogDescription>
              </div>
            </div>
          </DialogHeader>
          <div className='grid gap-4 p-6 sm:grid-cols-2'>
            <label className='grid gap-1.5 text-xs font-semibold text-muted-foreground sm:col-span-2'>
              <span>{english ? 'Full name *' : 'Ism va familiya *'}</span>
              <Input autoFocus className={inputClass} placeholder={english ? 'Enter full name' : 'To‘liq ismni kiriting'} value={name} onChange={(event) => setName(event.target.value)} />
            </label>
            <label className='grid gap-1.5 text-xs font-semibold text-muted-foreground'>
              <span>{english ? 'Phone number *' : 'Telefon raqami *'}</span>
              <Input className={inputClass} placeholder='+998 90 123 45 67' inputMode='tel' value={phone} onChange={(event) => setPhone(event.target.value)} />
            </label>
            <label className='grid gap-1.5 text-xs font-semibold text-muted-foreground'>
              <span>{english ? 'Course (optional)' : 'Kurs (ixtiyoriy)'}</span>
              <LeadFormSelect value={courseName} onValueChange={setCourseName} placeholder={english ? 'Select a course' : 'Kursni tanlang'} allowClear options={courseSelectOptions} />
            </label>
            <label className='grid gap-1.5 text-xs font-semibold text-muted-foreground'>
              <span>{english ? 'Application source' : 'Ariza manbasi'}</span>
              <LeadFormSelect value={source} onValueChange={setSource} options={sourceSelectOptions} />
            </label>
            <label className='grid gap-1.5 text-xs font-semibold text-muted-foreground'>
              <span>{english ? 'Assigned staff (optional)' : 'Mas’ul xodim (ixtiyoriy)'}</span>
              <Input className={inputClass} placeholder={english ? 'Staff name' : 'Xodim ismi'} value={assignedTo} onChange={(event) => setAssignedTo(event.target.value)} />
            </label>
            <label className='grid gap-1.5 text-xs font-semibold text-muted-foreground sm:col-span-2'>
              <span>{english ? 'Notes' : 'Izoh'}</span>
              <textarea className='min-h-24 w-full resize-y rounded-xl border border-border/80 bg-background/80 px-3 py-2.5 text-sm font-normal text-foreground shadow-xs outline-none transition focus-visible:ring-4 focus-visible:ring-primary/10' placeholder={english ? 'Add any useful details…' : 'Qo‘shimcha ma’lumot kiriting…'} value={notes} onChange={(event) => setNotes(event.target.value)} />
            </label>
          </div>
          <DialogFooter className='border-t border-border/60 bg-muted/20 px-6 py-4 sm:justify-between'>
            <span className='mr-auto hidden items-center gap-1.5 text-xs text-muted-foreground sm:flex'><CheckCircle2 className='size-3.5 text-emerald-600' />{english ? 'Required fields are marked with *' : '* bilan belgilangan maydonlar majburiy'}</span>
            <Button variant='outline' onClick={() => setCreateOpen(false)} className='rounded-xl'>{english ? 'Cancel' : 'Bekor qilish'}</Button>
            <Button disabled={!name.trim() || !phone.trim()} onClick={createLead} className='rounded-xl bg-emerald-600 text-white hover:bg-emerald-700'>{english ? 'Save lead' : 'Arizani saqlash'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!selected} onOpenChange={(open) => { if (!open) setSelectedId(null) }}>
        <DialogContent className='max-h-[92vh] gap-0 overflow-y-auto border-border/70 bg-card p-0 shadow-2xl sm:max-w-2xl'>
          <DialogHeader className='border-b border-border/60 bg-gradient-to-br from-slate-50 via-background to-background px-6 pt-6 pb-5 text-left dark:from-slate-900/80'>
            <div className='flex items-start gap-3'>
              <span className='flex size-11 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200'><UserRound className='size-5' /></span>
              <div className='min-w-0 space-y-1'>
                <DialogTitle className='truncate text-xl'>{selected?.name}</DialogTitle>
                <DialogDescription>{selected?.phone} · {selected?.courseName || (english ? 'No course selected' : 'Kurs tanlanmagan')} · {selected ? getStatusLabel(selected.status, english) : ''}</DialogDescription>
              </div>
            </div>
          </DialogHeader>
          {selected && (
            <div className='space-y-5 p-6'>
              <section className='grid gap-4 rounded-2xl border border-border/70 bg-muted/20 p-4 sm:grid-cols-2'>
                <label className='grid gap-1.5 text-xs font-semibold text-muted-foreground'><span>{english ? 'Full name' : 'Ism va familiya'}</span><Input className={inputClass} value={editName} onChange={(event) => setEditName(event.target.value)} /></label>
                <label className='grid gap-1.5 text-xs font-semibold text-muted-foreground'><span>{english ? 'Phone number' : 'Telefon raqami'}</span><Input className={inputClass} value={editPhone} onChange={(event) => setEditPhone(event.target.value)} /></label>
                <label className='grid gap-1.5 text-xs font-semibold text-muted-foreground'><span>{english ? 'Course' : 'Kurs'}</span><LeadFormSelect value={editCourseName} onValueChange={setEditCourseName} placeholder={english ? 'No course selected' : 'Kurs tanlanmagan'} allowClear options={courseSelectOptions} /></label>
                <label className='grid gap-1.5 text-xs font-semibold text-muted-foreground'><span>{english ? 'Source' : 'Manba'}</span><LeadFormSelect value={editSource} onValueChange={setEditSource} options={sourceSelectOptions} /></label>
                <label className='grid gap-1.5 text-xs font-semibold text-muted-foreground sm:col-span-2'><span>{english ? 'Notes' : 'Izoh'}</span><textarea className='min-h-20 w-full resize-y rounded-xl border border-border/80 bg-background/80 px-3 py-2.5 text-sm font-normal text-foreground shadow-xs outline-none focus-visible:ring-4 focus-visible:ring-primary/10' value={editNotes} onChange={(event) => setEditNotes(event.target.value)} placeholder={english ? 'Notes' : 'Izoh'} /></label>
                <Button className='rounded-xl sm:col-span-2' size='sm' onClick={saveDetails}>{english ? 'Save details' : 'Tafsilotlarni saqlash'}</Button>
              </section>

              <section className='space-y-3 rounded-2xl border border-violet-200/70 bg-violet-50/40 p-4 dark:border-violet-500/20 dark:bg-violet-500/[0.04]'>
                <div className='flex items-center gap-2 text-sm font-semibold'><CalendarClock className='size-4 text-violet-600 dark:text-violet-300' />{english ? 'Trial lesson' : 'Sinov darsi'}</div>
                <label className='grid gap-1.5 text-xs font-semibold text-muted-foreground'><span>{english ? 'Date and time' : 'Sana va vaqt'}</span><Input className={inputClass} type='datetime-local' aria-label={english ? 'Trial lesson date and time' : 'Sinov darsi vaqti'} value={trialAt} onChange={(event) => setTrialAt(event.target.value)} /></label>
                <div className='flex flex-wrap gap-2'>
                  <Button size='sm' disabled={!trialAt || selected.status === 'CONVERTED' || selected.status === 'ARCHIVED'} onClick={() => updateLead(selected.id, { trialLessonAt: new Date(trialAt).toISOString(), status: 'TRIAL_SCHEDULED' })} className='rounded-lg bg-violet-600 text-white hover:bg-violet-700'>{english ? 'Schedule lesson' : 'Darsni belgilash'}</Button>
                  <Button size='sm' variant='outline' disabled={!trialAt || selected.status === 'CONVERTED' || selected.status === 'ARCHIVED'} onClick={() => updateLead(selected.id, { trialLessonAt: new Date(trialAt).toISOString(), status: 'TRIAL_ATTENDED' })} className='rounded-lg'>{english ? 'Mark attended' : 'Qatnashdi deb belgilash'}</Button>
                </div>
              </section>

              <div className='flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-border/70 px-4 py-3'>
                <p className='text-xs text-muted-foreground'>{english ? 'Created' : 'Yaratilgan'}: {displayDate(selected.createdAt, english)}</p>
                {selected.status !== 'CONVERTED' && selected.status !== 'ARCHIVED' && <Button size='sm' onClick={() => updateLead(selected.id, { status: 'CONVERTED', convertedStudentId: `demo-student-${selected.id}` })} className='rounded-xl bg-emerald-600 text-white hover:bg-emerald-700'><GraduationCap className='mr-1.5 size-4' />{english ? 'Enroll in course' : 'Kursga yozish'}</Button>}
                {selected.status === 'CONVERTED' && <span className='inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300'><CheckCircle2 className='size-3.5' />{english ? 'Enrolled' : 'Kursga yozilgan'}</span>}
              </div>
            </div>
          )}
          <DialogFooter className='border-t border-border/60 bg-muted/20 px-6 py-4'>
            <Button variant='outline' onClick={() => setSelectedId(null)} className='rounded-xl'>{english ? 'Close' : 'Yopish'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
