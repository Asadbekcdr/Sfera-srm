export type TeacherRosterApiRecord = {
  studentId: string
  firstName: string
  lastName: string
}

export type TeacherRosterEntry = {
  id: string
  name: string
}

export function mapTeacherRoster(
  records: TeacherRosterApiRecord[] | undefined
): TeacherRosterEntry[] {
  if (!Array.isArray(records)) return []
  return records
    .filter((record) => record.studentId && (record.firstName || record.lastName))
    .map((record) => ({
      id: record.studentId,
      name: [record.firstName, record.lastName].filter(Boolean).join(' '),
    }))
}
