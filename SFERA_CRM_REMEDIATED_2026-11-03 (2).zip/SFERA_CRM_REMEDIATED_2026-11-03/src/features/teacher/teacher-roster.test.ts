import { describe, expect, it } from 'vitest'
import { mapTeacherRoster } from './teacher-roster'

describe('mapTeacherRoster', () => {
  it('does not invent a roster when no backend roster is available', () => {
    expect(mapTeacherRoster(undefined)).toEqual([])
    expect(mapTeacherRoster([])).toEqual([])
  })

  it('maps only records returned by the backend', () => {
    expect(
      mapTeacherRoster([
        { studentId: 'stu-1', firstName: 'Student', lastName: 'One' },
      ])
    ).toEqual([{ id: 'stu-1', name: 'Student One' }])
  })
})
