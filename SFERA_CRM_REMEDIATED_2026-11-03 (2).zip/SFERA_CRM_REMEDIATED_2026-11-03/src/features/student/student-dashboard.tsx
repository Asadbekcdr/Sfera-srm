import { BookOpen, CalendarDays, ClipboardCheck, GraduationCap } from 'lucide-react'
import { Link } from '@tanstack/react-router'
import { useAuthStore } from '@/stores/auth-store'
import { Header } from '@/components/layout/header'
import { Main } from '@/components/layout/main'
import { ProfileDropdown } from '@/components/profile-dropdown'
import { ThemeSwitch } from '@/components/theme-switch'
import { Search as GlobalSearch } from '@/components/search'
import { useLanguage } from '@/context/language-provider'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export function StudentDashboard() {
  const user = useAuthStore((state) => state.auth.user)
  const { language } = useLanguage()
  const english = language === 'en'
  const label = (uz: string, en: string) => (english ? en : uz)
  const userName = user?.name?.trim() || label('Talaba', 'Student')
  const modules = [
    {
      title: label('Kurslarim', 'My courses'),
      href: '/student/my-course' as const,
      icon: BookOpen,
    },
    {
      title: label('Jadvalim', 'My schedule'),
      href: '/student/my-schedule' as const,
      icon: CalendarDays,
    },
    {
      title: label('Davomatim', 'My attendance'),
      href: '/student/my-attendance' as const,
      icon: ClipboardCheck,
    },
    {
      title: label('Baholarim', 'My grades'),
      href: '/student/my-grades' as const,
      icon: GraduationCap,
    },
  ]

  return (
    <>
      <Header fixed>
        <div className='flex items-center gap-2'>
          <h1 className='text-lg font-semibold tracking-tight'>
            {label('Boshqaruv paneli', 'Dashboard')}
          </h1>
          <Badge variant='outline' className='hidden border-primary/30 text-primary sm:inline-flex'>
            {label('Talaba portali', 'Student portal')}
          </Badge>
        </div>
        <div className='ms-auto flex items-center gap-2'>
          <GlobalSearch className='me-auto sm:me-0' />
          <ThemeSwitch />
          <ProfileDropdown />
        </div>
      </Header>
      <Main className='space-y-6'>
        <section className='space-y-2 border-b pb-5'>
          <h2 className='text-2xl font-bold tracking-tight'>
            {label(`Xush kelibsiz, ${userName}`, `Welcome, ${userName}`)}
          </h2>
          <p className='max-w-3xl text-sm text-muted-foreground'>
            {label(
              'Bu sahifada faqat hisobingizga tegishli, tizimda tasdiqlangan o‘quv ma’lumotlari ko‘rsatiladi.',
              'This page shows only verified learning information linked to your account.'
            )}
          </p>
        </section>

        <Card>
          <CardHeader>
            <CardTitle>{label('O‘quv ma’lumotlari', 'Learning information')}</CardTitle>
            <CardDescription>
              {label(
                'Hozircha hisobingiz uchun tasdiqlangan kurs, jadval yoki natija ma’lumoti mavjud emas.',
                'There is no verified course, schedule, or progress data for this account yet.'
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className='text-sm text-muted-foreground'>
              {label(
                'Demo ma’lumotlar haqiqiy natija sifatida ko‘rsatilmaydi. Akademiya backend’i hisobingiz ma’lumotlariga ulanganidan keyin tegishli ko‘rsatkichlar shu yerda chiqadi.',
                'Demo records are not presented as real results. Verified information will appear here once the academy backend is connected to your account.'
              )}
            </p>
          </CardContent>
        </Card>

        <section aria-labelledby='student-modules-title' className='space-y-3'>
          <h3 id='student-modules-title' className='text-base font-semibold'>
            {label('Talaba bo‘limlari', 'Student modules')}
          </h3>
          <div className='grid gap-3 sm:grid-cols-2 lg:grid-cols-4'>
            {modules.map(({ title, href, icon: Icon }) => (
              <Card key={href}>
                <CardContent className='flex items-center justify-between gap-3 p-4'>
                  <div className='flex items-center gap-3'>
                    <Icon className='size-5 text-primary' aria-hidden='true' />
                    <span className='text-sm font-medium'>{title}</span>
                  </div>
                  <Button asChild variant='outline' size='sm'>
                    <Link to={href}>{label('Ochish', 'Open')}</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </Main>
    </>
  )
}
