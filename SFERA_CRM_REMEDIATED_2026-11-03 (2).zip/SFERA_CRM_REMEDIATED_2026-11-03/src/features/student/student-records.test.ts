import { describe, expect, it } from 'vitest'
import type { CrmStudent } from '@/lib/crm-store'
import { findStudentRecordForEmail } from './student-record-lookup'

const records: CrmStudent[] = [
  {
    id: 'stu-001',
    name: 'Azizbek Karimov',
    phone: '+998901234567',
    email: 'azizbek@example.com',
    course: 'Frontend Development',
    groupId: 'grp-fr02',
    teacher: 'Temurbek',
    status: 'active',
    progress: 68,
    attendance: 92,
    averageGrade: 86,
    totalPaid: 2550000,
    debt: 450000,
  },
]

describe('findStudentRecordForEmail', () => {
  it('returns only the record matching the signed-in account email', () => {
    expect(findStudentRecordForEmail(records, 'AZIZBEK@example.com')?.id).toBe(
      'stu-001'
    )
  })

  it('does not fall back to another student when the email has no match', () => {
    expect(findStudentRecordForEmail(records, 'unknown@example.com')).toBeNull()
    expect(findStudentRecordForEmail(records, null)).toBeNull()
  })
})
