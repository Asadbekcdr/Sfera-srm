import type { ReactNode } from 'react'
import { AlertCircle } from 'lucide-react'
import { Header } from '@/components/layout/header'
import { Main } from '@/components/layout/main'
import { ProfileDropdown } from '@/components/profile-dropdown'
import { Search as GlobalSearch } from '@/components/search'
import { ThemeSwitch } from '@/components/theme-switch'
import { Card, CardContent } from '@/components/ui/card'

type StudentPageShellProps = {
  title: string
  children: ReactNode
}

export function StudentPageShell({ title, children }: StudentPageShellProps) {
  return (
    <>
      <Header fixed>
        <h1 className='text-lg font-semibold tracking-tight'>{title}</h1>
        <div className='ms-auto flex items-center gap-2'>
          <GlobalSearch className='me-auto sm:me-0' />
          <ThemeSwitch />
          <ProfileDropdown />
        </div>
      </Header>
      <Main className='space-y-6'>{children}</Main>
    </>
  )
}

type StudentEmptyStateProps = {
  title: string
  description: string
}

export function StudentEmptyState({ title, description }: StudentEmptyStateProps) {
  return (
    <Card>
      <CardContent className='flex gap-3 p-5'>
        <AlertCircle
          className='mt-0.5 size-5 shrink-0 text-muted-foreground'
          aria-hidden='true'
        />
        <div role='status'>
          <h2 className='font-semibold'>{title}</h2>
          <p className='mt-2 max-w-2xl text-sm text-muted-foreground'>
            {description}
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
