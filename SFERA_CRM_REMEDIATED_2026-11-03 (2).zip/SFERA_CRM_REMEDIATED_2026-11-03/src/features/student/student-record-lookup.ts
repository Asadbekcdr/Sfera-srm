import type { CrmStudent } from '@/lib/crm-store'

export function findStudentRecordForEmail(
  students: CrmStudent[],
  email: string | null | undefined
): CrmStudent | null {
  const normalizedEmail = email?.trim().toLowerCase()
  if (!normalizedEmail) return null
  return (
    students.find((student) => student.email.trim().toLowerCase() === normalizedEmail) ??
    null
  )
}
