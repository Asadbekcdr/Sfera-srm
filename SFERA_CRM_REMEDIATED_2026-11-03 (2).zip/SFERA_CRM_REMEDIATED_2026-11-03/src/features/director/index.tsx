import { useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import {
  BarChart3,
  CreditCard,
  GraduationCap,
  UsersRound,
  TrendingUp,
  AlertTriangle,
  CalendarDays,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Header } from '@/components/layout/header'
import { Main } from '@/components/layout/main'
import { Search } from '@/components/search'
import { ThemeSwitch } from '@/components/theme-switch'
import { ProfileDropdown } from '@/components/profile-dropdown'
import {
  apiErrorMessage,
  formatApiCurrency,
  getApiData,
  isBackendEnabled,
  type FinanceSummaryApi,
  type ManagerDashboardApi,
} from '@/lib/api-client'

type Period = 'week' | 'month' | 'custom'

function useDirectorData(from?: string, to?: string) {
  const params = { from, to }
  const summaryQuery = useQuery({
    queryKey: ['backend', 'director', 'summary', params],
    queryFn: () => getApiData<FinanceSummaryApi>('/api/v1/finance/summary', params),
    enabled: isBackendEnabled(),
  })
  const academyQuery = useQuery({
    queryKey: ['backend', 'director', 'academy', params],
    queryFn: () => getApiData<ManagerDashboardApi>('/api/v1/dashboard/summary', params),
    enabled: isBackendEnabled(),
  })
  return { summaryQuery, academyQuery }
}

function DateFilter({ onChange }: { onChange: (from?: string, to?: string) => void }) {
  const [period, setPeriod] = useState<Period>('month')
  const [from, setFrom] = useState('')
  const [to, setTo] = useState('')
  const applyPeriod = (next: Period) => {
    setPeriod(next)
    if (next === 'custom') return
    const end = new Date()
    const start = new Date(end)
    if (next === 'week') start.setDate(end.getDate() - 7)
    else start.setMonth(end.getMonth() - 1)
    const startValue = start.toISOString().slice(0, 10)
    const endValue = end.toISOString().slice(0, 10)
    setFrom(startValue)
    setTo(endValue)
    onChange(startValue, endValue)
  }
  return (
    <div className='flex flex-wrap items-center gap-2'>
      <CalendarDays className='size-4 text-muted-foreground' />
      {(['week', 'month', 'custom'] as const).map((value) => (
        <Button key={value} size='sm' variant={period === value ? 'default' : 'outline'} onClick={() => applyPeriod(value)}>
          {value === 'week' ? 'Bu hafta' : value === 'month' ? 'Bu oy' : 'Maxsus sana'}
        </Button>
      ))}
      {period === 'custom' && (
        <>
          <Input aria-label='Boshlanish sanasi' type='date' value={from} onChange={(event) => setFrom(event.target.value)} className='h-8 w-[145px]' />
          <Input aria-label='Tugash sanasi' type='date' value={to} onChange={(event) => setTo(event.target.value)} className='h-8 w-[145px]' />
          <Button size='sm' onClick={() => onChange(from || undefined, to || undefined)}>Qo‘llash</Button>
        </>
      )}
    </div>
  )
}

function Metric({ label, value, icon: Icon, description }: { label: string; value: string | number; icon: typeof CreditCard; description?: string }) {
  return (
    <Card className='border-border/70 shadow-xs'>
      <CardContent className='flex items-center justify-between gap-3 p-5'>
        <div><p className='text-sm text-muted-foreground'>{label}</p><p className='mt-2 text-2xl font-bold tabular-nums'>{value}</p>{description && <p className='mt-1 text-xs text-muted-foreground'>{description}</p>}</div>
        <div className='rounded-xl bg-primary/10 p-3 text-primary'><Icon className='size-5' /></div>
      </CardContent>
    </Card>
  )
}

function DirectorShell({ children }: { children: React.ReactNode }) {
  return <><Header><Search /><ThemeSwitch /><ProfileDropdown /></Header><Main>{children}</Main></>
}

export function DirectorDashboard() {
  const [range, setRange] = useState<{ from?: string; to?: string }>({})
  const { summaryQuery, academyQuery } = useDirectorData(range.from, range.to)
  const summary = summaryQuery.data
  const academy = academyQuery.data
  const currency = (value: number | null) => formatApiCurrency(value, 'uz-UZ')
  const hasError = summaryQuery.isError || academyQuery.isError
  const metrics = [
    { label: 'Faol o‘quvchilar', value: academy?.totalStudents ?? '—', icon: GraduationCap },
    { label: 'Yangi arizalar', value: academy?.pendingApplications ?? '—', icon: UsersRound },
    { label: 'Yig‘ilgan tushum', value: summary ? currency(summary.collectedRevenue) : '—', icon: CreditCard },
    { label: 'Ochiq qarzdorlik', value: summary ? currency(summary.outstandingBalance) : '—', icon: AlertTriangle },
    { label: 'Faol guruhlar', value: academy?.totalGroups ?? '—', icon: UsersRound },
    { label: 'Davomat darajasi', value: academy?.averageAttendance != null ? `${academy.averageAttendance}%` : '—', icon: TrendingUp },
  ]
  return <DirectorShell>
    <div className='mb-6 flex flex-col justify-between gap-4 border-b border-border/40 pb-5 lg:flex-row lg:items-end'>
      <div><p className='text-xs font-semibold uppercase tracking-wider text-primary'>Director workspace</p><h1 className='mt-1.5 text-2xl font-bold tracking-tight sm:text-3xl'>Strategik boshqaruv paneli</h1><p className='mt-1 text-sm text-muted-foreground'>Akademiya bo‘yicha qaror qabul qilish uchun yagona ko‘rinish.</p></div>
      <div className='flex flex-wrap items-center gap-2'><Badge variant={isBackendEnabled() ? 'default' : 'outline'}>{isBackendEnabled() ? 'Live API' : 'Backend ulanmagan'}</Badge><DateFilter onChange={(from, to) => setRange({ from, to })} /></div>
    </div>
    {hasError && <div role='alert' className='mb-6 rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-muted-foreground'>{apiErrorMessage(summaryQuery.error || academyQuery.error)} Ko‘rsatkichlar yashirildi.</div>}
    {!isBackendEnabled() && <div className='mb-6 rounded-lg border border-amber-500/30 bg-amber-500/5 px-4 py-3 text-sm text-muted-foreground'>Backend ulanmagan. Moliyaviy va operatsion ko‘rsatkichlar mavjud emas — demo raqamlar ko‘rsatilmaydi.</div>}
    <div className='grid gap-4 sm:grid-cols-2 xl:grid-cols-3'>{metrics.map((metric) => <Metric key={metric.label} {...metric} />)}</div>
    <div className='mt-6 grid gap-6 lg:grid-cols-2'>
      <Card><CardHeader><CardTitle>Ijrochi xulosasi</CardTitle><CardDescription>Faqat backend qaytargan ma’lumotlardan hisoblangan.</CardDescription></CardHeader><CardContent className='space-y-3 text-sm'>{summary ? <><div className='flex justify-between'><span className='text-muted-foreground'>Yig‘im koeffitsiyenti</span><strong>{summary.collectionRate == null ? 'Mavjud emas' : `${summary.collectionRate}%`}</strong></div><div className='flex justify-between'><span className='text-muted-foreground'>Muddati o‘tgan qarz</span><strong>{currency(summary.overdueBalance)}</strong></div><div className='flex justify-between'><span className='text-muted-foreground'>Sof tushum</span><strong>{currency(summary.netRevenue)}</strong></div></> : <p className='text-muted-foreground'>Ma’lumot mavjud emas.</p>}</CardContent></Card>
      <Card><CardHeader><CardTitle>O‘sish signallari</CardTitle><CardDescription>Dashboard endpointi taqdim etgan akademiya ko‘rsatkichlari.</CardDescription></CardHeader><CardContent className='space-y-3 text-sm'>{academy?.revenueTrend?.length ? academy.revenueTrend.slice(-4).map((item) => <div key={item.label} className='flex justify-between'><span className='text-muted-foreground'>{item.label}</span><strong>{currency(item.revenue)}</strong></div>) : <p className='text-muted-foreground'>Trend ma’lumoti backend tomonidan taqdim etilmagan.</p>}</CardContent></Card>
    </div>
  </DirectorShell>
}

export function DirectorReports() {
  const [range, setRange] = useState<{ from?: string; to?: string }>({})
  const { summaryQuery, academyQuery } = useDirectorData(range.from, range.to)
  const summary = summaryQuery.data
  const academy = academyQuery.data
  const currency = (value: number | null) => formatApiCurrency(value, 'uz-UZ')
  const reportRows = useMemo(() => [
    ['Moliyaviy holat', summary ? currency(summary.collectedRevenue) : 'Mavjud emas', summary?.collectionRate == null ? 'Invoice yig‘im koeffitsiyenti mavjud emas' : `${summary.collectionRate}% yig‘im`],
    ['Qarzdorlik', summary ? currency(summary.outstandingBalance) : 'Mavjud emas', summary?.counts.overdueInvoices == null ? 'Muddati o‘tgan hisob-faktura ma’lumoti mavjud emas' : `${summary.counts.overdueInvoices} ta muddati o‘tgan hisob`],
    ['Akademiya qamrovi', academy ? `${academy.totalStudents} o‘quvchi` : 'Mavjud emas', academy ? `${academy.totalGroups} ta guruh` : 'Backend ma’lumoti kerak'],
    ['Davomat', academy?.averageAttendance != null ? `${academy.averageAttendance}%` : 'Mavjud emas', 'Dashboard endpointi'],
  ], [academy, summary])
  return <DirectorShell>
    <div className='mb-6 flex flex-col justify-between gap-4 border-b border-border/40 pb-5 lg:flex-row lg:items-end'><div><p className='text-xs font-semibold uppercase tracking-wider text-primary'>Director reports</p><h1 className='mt-1.5 text-2xl font-bold tracking-tight sm:text-3xl'>Akademiya hisobotlari</h1><p className='mt-1 text-sm text-muted-foreground'>Moliyaviy, enrollment va operatsion ko‘rsatkichlarning o‘qiladigan xulosasi.</p></div><DateFilter onChange={(from, to) => setRange({ from, to })} /></div>
    {!isBackendEnabled() && <div className='mb-6 rounded-lg border border-amber-500/30 bg-amber-500/5 px-4 py-3 text-sm text-muted-foreground'>Hisobotlar real backend ma’lumotlari mavjud bo‘lganda to‘ldiriladi.</div>}
    {(summaryQuery.isError || academyQuery.isError) && <div role='alert' className='mb-6 rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-muted-foreground'>{apiErrorMessage(summaryQuery.error || academyQuery.error)}</div>}
    <div className='grid gap-4 sm:grid-cols-2 xl:grid-cols-4'><Metric label='Hisob-fakturalar' value={summary?.counts.invoices ?? '—'} icon={BarChart3} /><Metric label='Kutilayotgan to‘lovlar' value={summary?.counts.pendingPayments ?? '—'} icon={CreditCard} /><Metric label='O‘qituvchilar' value={academy?.totalTeachers ?? '—'} icon={GraduationCap} /><Metric label='Muddati o‘tgan qarz' value={summary ? currency(summary.overdueBalance) : '—'} icon={AlertTriangle} /></div>
    <Card className='mt-6'><CardHeader><CardTitle>Ko‘rsatkichlar jadvali</CardTitle><CardDescription>Sana filtri qo‘llangan backend natijalari. Dekorativ yoki o‘ylab topilgan qiymatlar ishlatilmaydi.</CardDescription></CardHeader><CardContent><div className='overflow-x-auto'><table className='w-full text-sm'><thead><tr className='border-b text-left text-muted-foreground'><th className='px-3 py-3 font-medium'>Hisobot</th><th className='px-3 py-3 font-medium'>Qiymat</th><th className='px-3 py-3 font-medium'>Izoh</th></tr></thead><tbody>{reportRows.map(([name, value, detail]) => <tr key={name} className='border-b last:border-0'><td className='px-3 py-3 font-medium'>{name}</td><td className='px-3 py-3 tabular-nums'>{value}</td><td className='px-3 py-3 text-muted-foreground'>{detail}</td></tr>)}</tbody></table></div></CardContent></Card>
  </DirectorShell>
}
