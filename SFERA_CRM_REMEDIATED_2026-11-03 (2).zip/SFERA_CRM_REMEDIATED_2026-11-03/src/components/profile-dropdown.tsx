import { Link, useNavigate } from '@tanstack/react-router'
import { ChevronsUpDown, LogOut, Settings, ShieldCheck, UserRound } from 'lucide-react'
import { toast } from 'sonner'
import { getPrimaryRole } from '@/lib/rbac'
import { useAuthStore } from '@/stores/auth-store'
import { useLanguage } from '@/context/language-provider'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

function initials(name: string) {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join('') || 'S'
}

export function ProfileDropdown() {
  const navigate = useNavigate()
  const { auth } = useAuthStore()
  const { language } = useLanguage()
  const role = getPrimaryRole(auth.user?.role)
  const name = auth.user?.name || role
  const email = auth.user?.email || 'name@example.com'
  const english = language === 'en'

  function signOut() {
    auth.reset()
    toast.success(english ? 'You have been signed out successfully.' : 'Tizimdan muvaffaqiyatli chiqdingiz.')
    navigate({ to: '/sign-in' })
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type='button'
          className='flex items-center gap-2 rounded-xl border border-border/70 bg-background/80 px-2 py-1.5 text-start shadow-sm transition-all hover:border-primary/30 hover:bg-primary/5 focus-visible:ring-2 focus-visible:ring-primary/30'
          aria-label={english ? 'Open profile menu' : 'Profil menyusini ochish'}
        >
          <Avatar className='size-8 border border-primary/20'>
            <AvatarFallback className='bg-primary/10 text-xs font-bold text-primary'>
              {initials(name)}
            </AvatarFallback>
          </Avatar>
          <span className='hidden max-w-32 sm:block'>
            <span className='block truncate text-xs font-semibold'>{name}</span>
            <span className='block truncate text-[10px] text-muted-foreground'>{role}</span>
          </span>
          <ChevronsUpDown className='size-3.5 text-muted-foreground' />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align='end' sideOffset={8} className='w-64 rounded-xl p-1.5'>
        <DropdownMenuLabel className='rounded-lg bg-muted/50 p-3 font-normal'>
          <div className='flex items-center gap-3'>
            <Avatar className='size-10 border border-primary/20'>
              <AvatarFallback className='bg-primary/10 font-bold text-primary'>{initials(name)}</AvatarFallback>
            </Avatar>
            <div className='min-w-0'>
              <p className='truncate text-sm font-semibold'>{name}</p>
              <p className='truncate text-xs text-muted-foreground'>{email}</p>
              <span className='mt-1 inline-flex items-center gap-1 rounded-md bg-emerald-500/10 px-1.5 py-0.5 text-[10px] font-semibold text-emerald-700 dark:text-emerald-400'>
                <ShieldCheck className='size-3' /> {role}
              </span>
            </div>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild className='rounded-lg'>
          <Link to='/settings'>
            <UserRound className='size-4 text-primary' />
            {english ? 'My profile' : 'Profilim'}
          </Link>
        </DropdownMenuItem>
        <DropdownMenuItem asChild className='rounded-lg'>
          <Link to='/settings/account'>
            <Settings className='size-4 text-muted-foreground' />
            {english ? 'Account settings' : 'Hisob sozlamalari'}
          </Link>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem variant='destructive' className='rounded-lg' onClick={signOut}>
          <LogOut className='size-4' />
          {english ? 'Sign out' : 'Chiqish'}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
