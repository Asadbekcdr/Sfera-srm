import { describe, expect, it } from 'vitest'
import { sidebarData } from './sidebar-data'

describe('Super Admin sidebar navigation', () => {
  it('shows the task center exactly once across its visible navigation groups', () => {
    const visibleGroups = new Set(['Academy', 'Management', 'System'])
    const taskLinks = sidebarData.navGroups
      .filter((group) => visibleGroups.has(group.title))
      .flatMap((group) => group.items)
      .filter((item) => item.url === '/tasks')

    expect(taskLinks).toHaveLength(1)
  })
})
