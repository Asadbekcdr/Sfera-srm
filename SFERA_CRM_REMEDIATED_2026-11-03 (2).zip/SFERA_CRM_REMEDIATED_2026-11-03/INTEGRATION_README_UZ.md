# Sfera CRM integratsiyasi

Frontend va yuborilgan `Sfera-Education` Spring Boot backendi bitta loyiha ichiga yig‘ildi. Frontenddagi barcha real API so‘rovlari Axios orqali `src/lib/api-client.ts` dan o‘tadi; server holati TanStack Query bilan boshqariladi.

## Ishga tushirish

1. PostgreSQL’da `academy` bazasini yarating.
2. `backend/.env.example` asosida muhit o‘zgaruvchilarini belgilang.
3. Backend: `cd backend && ./mvnw spring-boot:run` — port `8082`.
4. Frontend: root papkada `pnpm install && pnpm dev` — port `5173`.
5. Login frontendda email emas, backend talab qilgan `998901234567` ko‘rinishidagi telefon raqami va parol bilan ishlaydi.

Vite development proxy `/auth`, `/dashboard`, `/group`, `/student`, `/teacher`, `/tasks` va boshqa Spring route’larni `localhost:8082` ga yuboradi. `ApiResponse.data` avtomatik ochiladi.

## Ulangan backend modullari

Auth/JWT, dashboard, teacher dashboard, guruhlar, o‘quvchilar, o‘qituvchilar, attendance, tasks, user, admin, category, room, mark, event va notification route’lari backend zipidagi controllerlar bilan ishlaydi. Eski frontend `/api/v1/...` aliaslari `api-client.ts` ichida Spring route’lariga moslashtirilgan.

Finance, lead va course CRM endpointlari yuborilgan backend zipida controller sifatida mavjud emas. Ular real backend ma’lumoti yo‘q holatda xatolik/status ko‘rsatadi; demo yozuvlar “live API” sifatida ishlatilmaydi.

## Xavfsizlik

Original zip ichidagi DB paroli, JWT secret, Telegram token va Supabase key’lari source’dan olib tashlanib, environment variable’lariga o‘tkazildi. Haqiqiy qiymatlarni faqat lokal `.env` yoki deployment secret manager’ida saqlang.
