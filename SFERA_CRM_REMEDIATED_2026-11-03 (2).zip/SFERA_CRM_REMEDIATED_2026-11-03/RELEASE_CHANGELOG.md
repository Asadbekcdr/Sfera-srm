# Changelog — 2026-10-30 SFERA CRM continuation

## Backend

- Kept bundled `backend/` as canonical Spring Boot source; standalone reference was not merged.
- Added/verified Flyway initial schema and payment/audit migrations V1–V3.
- Preserved task user/group links on partial update; scoped teacher task access/mutations/assignments and blocked foreign-group reassignment.
- Rejected disabled principals in JWT filtering and limited student phone lookup to active accounts.
- Added principal-aware attendance/mark record reads, teacher-only-own-group mark writes, and prevented mark reassignment to another teacher's student.
- Isolated attendance SSE emitters/broadcast by group.
- Added explicit CORS origin validation; wildcard, malformed, path-bearing and empty allowlists fail closed.
- Added `POST /attendance/bulk`, adapting group/date/records to the existing secured attendance service.
- Rejected payment idempotency-key reuse with a different payload and rendered unsupported invoice/debt metrics as unavailable rather than fabricated.

## Frontend

- Corrected sign-in input label association/password feedback and phone-login behavior; localized recovery/OTP copy.
- Fixed settings theme reset behavior; updated task mutation/bulk-delete/import and command-palette regression assertions to actual behavior.
- Made teacher dashboard API mode display backend metrics only; made attendance load real numeric backend groups/rosters and submit through the tested bulk route.
- Hid demo-only assignment, grade and finance-student data/actions in API mode when no persistence endpoint is wired. SMS actions no longer claim delivery without a provider.
- Removed false success behavior from unconnected student and invitation dialogs; they state that no save/invitation occurred.

## Documentation, testing and package

- Preserved both original handoff audit and the independent `SFERA_CRM_FULL_AUDIT.md` under `TASKS/`.
- Added finding-by-finding `SUPPLEMENTAL_AUDIT_REVIEW.md`, updated API/security/release/test reports and retained test logs.
- Final verification: frontend 32 files/158 browser tests passed, TypeScript and build passed, lint 0 errors/29 warnings; backend 29 tests passed against both fresh and schema-only legacy PostgreSQL fixtures.

## Important limitation

This is not a complete product or a production approval. Browser-readable token/session handling, password recovery/session revocation/rate limiting, Clerk/JWT duplication, full tenant/role isolation, invoice billing, student lifecycle, assignment/grade persistence and broad E2E/operational testing remain blockers. See `RELEASE_AUDIT.md` and `SUPPLEMENTAL_AUDIT_REVIEW.md`.
