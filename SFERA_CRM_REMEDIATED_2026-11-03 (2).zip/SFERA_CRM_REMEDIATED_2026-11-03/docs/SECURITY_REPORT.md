# Security report — remaining-work phase

Date: 2026-10-30

## Implemented and compile-verified

- JWT now requires configured issuer, audience and `typ=access` claims.
- JWT secret is rejected at runtime when shorter than 32 characters.
- Invalid/expired/wrong issuer/wrong audience tokens remain anonymous and do not expose token contents in logs.
- Parent collection/list/detail/delete endpoints are restricted to Admin/Super Admin; child routes remain authenticated and service-scoped.
- Task reads now require an authenticated principal.
- CORS remains allowlist-based and environment-configurable.
- Production Hibernate schema default remains `validate`.
- Demo seed remains limited to the `dev` profile.

## Not yet complete / blocked

- Refresh token rotation and reuse detection.
- Persistent token/session revocation on logout.
- One-time hashed password reset tokens.
- Login/reset rate limiting and brute-force protection.
- Full academy/tenant ownership checks for every endpoint.
- Full teacher/student/parent/manager negative integration tests.
- Upload signature/MIME/storage authorization review.
- Production PostgreSQL security integration tests.

Status: **BLOCKED — not production ready** until the missing controls have tests and evidence.
