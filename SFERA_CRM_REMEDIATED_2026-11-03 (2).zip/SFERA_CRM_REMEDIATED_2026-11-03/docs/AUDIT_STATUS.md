# Sfera CRM audit status

## Baseline
- Frontend TypeScript: **CONFIRMED** passing.
- Frontend lint: **CONFIRMED** passing with warnings.
- Frontend build: **CONFIRMED** passing.
- Frontend browser tests: **BLOCKED** initially because Playwright Chromium was not installed; browser dependencies were installed for the remediation run.
- Backend compile: **BLOCKED** initially because the environment had a JRE without `javac`; JDK 21 was installed.
- PostgreSQL integration/migration tests: **BLOCKED** until a PostgreSQL instance and real database snapshot are supplied.

## Remediated in this working copy
- `ARCH-001`: canonical backend decision documented.
- `DB-001`: default Hibernate mode changed from `update` to migration-managed `validate`.
- `SEC-001`: demo `DataLoader` restricted to the `dev` profile; production does not seed a known admin password.
- `SEC-002`: CORS origins externalized through `APP_CORS_ALLOWED_ORIGINS`; credentials are not combined with wildcard origins.
- `FE-001`: teacher groups no longer silently fall back to demo groups when API mode is enabled.

## Still blocked / not yet verified
- JWT issuer/audience, revocation, refresh rotation, password-reset lifecycle.
- Full academy/ownership isolation negative tests.
- Lead conversion transaction and idempotency against a real database.
- Invoice/debt/refund/reconciliation completeness.
- File upload/download authorization and malware scanning.
- Fresh and upgrade PostgreSQL migration tests.
- Full E2E role matrix.

This is not a production-ready declaration until the blocked items have reproducible evidence.


## Remaining-work phase update
- `SEC-JWT-001`: **FIXED — COMPILE VERIFIED** — JWT now requires configured issuer, audience and `typ=access`; secret length is validated; invalid tokens are not logged. Full integration 401 tests remain pending PostgreSQL.
- `SEC-OWNER-001`: **FIXED — COMPILE VERIFIED** — parent collection/list/detail/delete endpoints are restricted to Admin/Super Admin; task reads require authentication. Full child ownership and tenant negative tests remain pending.
- `FIN-PLACEHOLDER-001`: **NOT FIXED** — Finance summary still needs invoice/debt domain completion; no fake PASS was recorded.
