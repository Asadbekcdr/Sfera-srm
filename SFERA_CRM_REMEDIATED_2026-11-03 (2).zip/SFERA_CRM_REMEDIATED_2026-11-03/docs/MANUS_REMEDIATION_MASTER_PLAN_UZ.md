# SFERA CRM — MANUS UCHUN YAKUNIY MASTER REMEDIATION PLANI

**Boshlang‘ich arxiv:** `SFERA_CRM_RELEASE_2026-10-30_FINAL(3).zip`  
**Canonical backend:** faqat ZIP root ichidagi `backend/` Spring Boot loyihasi.  
**Boshlang‘ich release qarori:** `BLOCKED — NOT PRODUCTION READY`.

> **Ishonchlilik qoidasi:** Ushbu reja arxivdagi `RELEASE_AUDIT.md`, `SUPPLEMENTAL_AUDIT_REVIEW.md`, `RELEASE_TEST_REPORT.md`, `RELEASE_API_CONTRACT.md`, `API_ENDPOINT_MATRIX.md`, `TASKS/` hujjatlari va ularda ko‘rsatilgan source/evidence asosida tuzildi. Har bir band joriy kodda qayta tekshirilsin. Eski auditdagi “fixed” yozuvi hozir ham tuzatilganini anglatmaydi. Hujjatda ko‘rsatilmagan narsani tasdiqlangan xato deb yozmang; yangi topilgan muammolarni qo‘shing. Bu barcha source fayllari qatorma-qator mustaqil audit qilingan degani emas.

## 0. Asosiy topshiriq

Bu faqat audit yozish vazifasi emas. Mavjud SFERA CRM'ni amalda tuzating, frontend va backendni real PostgreSQL bilan to‘liq integratsiya qiling, barcha asosiy rollar va biznes workflowlarni ishlating, keyin test dalillari bilan yangi ZIP topshiring.

### O‘zgarmas qoidalar

1. Loyihani noldan yozmang; mavjud React frontend, Spring Boot backend, PostgreSQL, Flyway va biznes mantiqini saqlang.
2. Canonical backend — root ichidagi `backend/`. Boshqa/legacy backendni ko‘r-ko‘rona merge qilmang.
3. Barcha frontend API chaqiruvlari aynan shu backend contractiga mos bo‘lsin.
4. UI “saqlandi/muvaffaqiyatli” desa, ma’lumot haqiqatan server/database’da saqlangan bo‘lsin.
5. API mode’da backend xatosi bo‘lsa demo/mock/localStorage data bilan jim fallback qilmang.
6. Testlarni o‘chirmang, skip qilmang, assertionlarni kuchsizlantirmang.
7. PostgreSQL yoki tashqi servis yo‘q bo‘lsa tekshiruv `BLOCKED`; uni `PASS` demang.
8. Production secret/token/parol/real data ZIPga kiritmang.
9. Har bir o‘zgarish uchun root cause, fayllar, migration, test buyrug‘i, haqiqiy natija va qolgan riskni yozing.
10. P0/P1 muammo qolsa release `BLOCKED` bo‘lsin.

## 1. Boshlang‘ich test dalillari

`RELEASE_TEST_REPORT.md` (2026-10-30) quyidagilarni qayd etadi:

| Tekshiruv | Arxivdagi natija | Talab |
|---|---:|---|
| Frontend TypeScript | PASS | Qayta ishga tushirish |
| Frontend lint | PASS, 29 warning | Warninglarni tahlil qilish |
| Frontend browser suite | 32 fayl, 158 PASS, 0 FAIL/SKIP | Saqlash va kengaytirish |
| Frontend production build | PASS | Qayta ishga tushirish |
| Backend fresh PostgreSQL | 29 PASS | Qayta ishga tushirish |
| Backend schema-only legacy PostgreSQL | 29 PASS | Productionga yaqin upgrade bilan kengaytirish |
| Flyway V1–V3 | PASS | Checksum/order va upgrade tekshiruvi |
| To‘liq role/tenant E2E | To‘liq bajarilmagan | Majburiy yaratish |
| Finance/student/assignment/grade E2E | To‘liq bajarilmagan | Majburiy yaratish |
| Deployment, backup/restore, load | Tekshirilmagan | Bajaring yoki BLOCKED deb yozing |

`docs/VERIFICATION_REPORT.md` va `docs/TEST_REPORT.md` ichidagi 79/156 hamda PostgreSQL BLOCKED natijalari eski. Ularni tarixiy baseline sifatida saqlang, joriy natija deb ko‘rsatmang. Yangi muhitda testlarni qayta ishga tushiring.

## 2. P0 — Authentication va xavfsizlik

### SEC-001 — yagona auth arxitekturasi

**Qayd etilgan holat:** `src/routes/clerk/`, `@clerk/react` va custom Spring JWT (`/auth/login`, `auth-store`) parallel mavjud; yagona canonical flow tanlanmagan.

**Vazifa:** Frontend/backend auth oqimini xaritalang; bitta model tanlang (tavsiya: Spring Boot canonical auth + HttpOnly Secure cookie yoki asoslangan BFF/session). Clerk to‘liq integratsiya qilinmasa provider, routes, dependency va o‘lik importlarni route registration/dynamic importni tekshirgandan keyin olib tashlang. Demo auth faqat dev/testda ishlasin. Login user identity/role frontendda JWT decode qilib qo‘lda tuzilmasin.

**Qabul mezoni:** bitta auth flow; barcha role login; refresh/logout/expired session; direct URL/page refresh; multi-tab logout; productionda demo login yo‘q.

### SEC-002 — token storage, XSS va CSRF

**Qayd etilgan holat:** `src/lib/cookies.ts` `document.cookie` ishlatadi; token JavaScript tomonidan o‘qilishi mumkin, HttpOnly emas.

**Vazifa:** Tokenni HttpOnly cookie yoki BFF session orqali boshqaring. Cookie `HttpOnly`, HTTPS’da `Secure`, to‘g‘ri `SameSite`, cheklangan `Path` va expiry bilan. Cookie auth bo‘lsa CSRF token/Origin/Referer himoyasi. Token localStorage/sessionStorage/JS cookie/Zustand persist’da qolmasin. Raw HTML va user-generated content uchun XSS sanitizationni tekshiring. Frontend auth store faqat minimal user/session state saqlasin.

**Qabul mezoni:** JS tokenni o‘qiy olmaydi; CSRF/XSS regression testlari; unauthorized/expired 401; logout sessionni bekor qiladi.

### SEC-003 — refresh, revocation, logout, session

**Qayd etilgan holat:** refresh rotation/reuse detection va persistent session revocation to‘liq yo‘q yoki isbotlanmagan.

**Vazifa:** qisqa muddatli access token; hash holida saqlanadigan refresh token; rotation/reuse detection; server-side logout revoke; disabled user session invalidation; kerak bo‘lsa active sessions/device management. Issuer, audience, expiry, `typ=access`, signature va secret-length tekshiruvlarini saqlang. Tokenlarni loglamang.

**Qabul mezoni:** invalid/expired/wrong issuer/audience/type/revoked token 401; refresh replay rad etiladi; logoutdan keyin eski session ishlamaydi.

### SEC-004 — password reset, OTP, rate limit

**Qayd etilgan holat:** password recovery server lifecycle’i, hashed one-time reset token va brute-force rate limit yo‘q yoki to‘liq test qilinmagan.

**Vazifa:** kriptografik random reset token, DB’da hash, bir martalik va expiry; account enumeration qilmaydigan umumiy javob; login/OTP/reset/invitation va qimmat endpointlar uchun IP/account rate limit; OTP attempt limit, replay prevention va delivery failure. UI faqat provider qabul qilganida yuborildi deb ko‘rsatsin.

**Qabul mezoni:** ko‘p noto‘g‘ri urinish 429/lockout; expired/reused token ishlamaydi; password reset E2E.

### SEC-005 — Parent va Student rollari

**Qayd etilgan holat:** backend `ROLE_PARENT` va frontend role mapping nomuvofiq; `PARENT` Student sifatida talqin qilingan.

**Vazifa:** canonical role enum/permission contract. `PARENT` va `STUDENT` alohida bo‘lsin. Backend enum, JWT claims, login DTO, frontend `rbac.ts`, route guard, sidebar va permission gate bir xil nomlardan foydalansin. Unknown/missing role deny-by-default. Parent-child relation aniq bo‘lsin.

**Qabul mezoni:** har bir role uchun login/menu/API test; parent faqat o‘z farzandlarini, student faqat o‘z profilini ko‘radi.

### SEC-006 — RBAC, tenant va ownership

**Qayd etilgan holat:** Task/Mark/Attendance uchun targeted ownership fix/testlar bor; barcha controller, role va academy scope isbotlanmagan.

**Vazifa:** har endpoint uchun method/path/role/academy/resource owner/expected status inventarizatsiyasi. Academy scope authenticated principal’dan olinsin; client yuborgan academyId/studentId/teacherId/parentId/ownerIdga ko‘r-ko‘rona ishonmang. Super Admin global va Academy Admin local scope ajratilsin. List/detail/create/update/delete/export/bulk/download hammasida scope tekshirilsin. IDOR, mass assignment, privilege escalation, cross-academy access sinovlari.

**Qabul mezoni:** role × resource × action × academy negative test matrix. Ruxsatsiz so‘rov 403 yoki ma’lumot borligini oshkor qilmaydigan 404. Frontend menu hide server authorization o‘rnini bosmaydi.

### SEC-007 — CORS/CSRF/secrets/production config

**Qayd etilgan holat:** wildcard guard va explicit HTTP(S) origin validation bor; production allowlist/preflight, secret manager va rotation tekshirilmagan.

**Vazifa:** `APP_CORS_ALLOWED_ORIGINS` aniq domainlar; credentialed CORS’da wildcard yo‘q; required production secret bo‘lmasa fail-fast; JWT/DB/Telegram/storage/email secret source/loglarda yo‘q; `.env.example` placeholder; old secretlar rotatsiyasi; HTTPS/security headers/CSRF.

**Qabul mezoni:** production-profile config; invalid/wildcard origin startupni to‘xtatadi; real preflight; secret scan clean.

### SEC-008 — file upload/download

**Qayd etilgan holat:** real storage authorization, MIME/content signature, malware va retention to‘liq tekshirilmagan.

**Vazifa:** faylni user/academy/resource ownerga bog‘lash; extension/MIME/magic bytes/size/path traversal tekshiruvi; user filename storage path bo‘lmasin; private storage va server authorization yoki qisqa muddatli signed URL; malware scanning bo‘lmasa xavfsiz cheklov; retention/delete policy.

**Qabul mezoni:** boshqa user/academy fayli 403/404; noto‘g‘ri MIME, katta fayl, path traversal rad; upload/download E2E.

### SEC-009 — audit trail va PII

Role/permission, user lifecycle, payment/refund, attendance correction, grade publish, lead conversion va muhim settings uchun actor, academy, timestamp, entity/action va zarur before/after audit log. Password/token/secret va ortiqcha PII loglanmasin. Audit log faqat ruxsatli role uchun.

## 3. P0 — Frontend ↔ Backend API contract

### API-001 — endpoint inventarizatsiyasi

**Qayd etilgan holat:** `API_ENDPOINT_MATRIX.md` faqat verified subset; barcha route/DTO/error/pagination/role contract tekshirilmagan.

**Vazifa:** `src/` bo‘ylab fetch/axios/API client/query chaqiruvlarini toping; backenddagi barcha mapping annotation endpointlarini inventarizatsiya qiling. Har FE call’ni BE method/path/request DTO/response DTO/enum/validation/status/error/pagination/permission bilan bog‘lang. Bitta canonical `/api/v1/...` contract. Legacy aliaslar vaqtinchalik bo‘lsa deprecation + test. OpenAPI/Swagger va imkon bo‘lsa typed client. API client timeout, cancellation, consistent error mapping, 401/403/404/422/429/5xx va retry siyosatiga ega bo‘lsin.

**Qabul mezoni:** barcha frontend endpointlari matrix’da backendga mos; contract test; 400/401/403/404/422/429/500 UI holatlari.

### API-002 — login DTO

**Qayd etilgan holat:** backend `ApiResponse<String>` token qaytaradi; frontend JWT decode qilib user modelni qo‘lda yasaydi.

**Vazifa:** barqaror UserDTO qaytaring; token HttpOnly cookie’da bo‘lsa body’da token bermang. `userId`, canonical role, academy scope va minimal profile. Frontend role/identity’ni JWT decode’dan yasamasin.

**Qabul mezoni:** barcha role login response to‘g‘ri; PARENT/STUDENT aralashmaydi.

### API-003 — response/error/pagination

Yagona success/error envelope, field-level validation errors, yagona pagination va sort/filter whitelist. Frontend mapperlar aynan shu contractdan foydalansin.

## 4. P1 — Finance ledger

**Qayd etilgan holat:** Payment entity/workflow bor; idempotency payload mismatch tekshiriladi. Invoice/debt metriclar ledger yo‘qligi sabab null/unavailable. `FinanceService`dagi `"INV-" + payment.getId()` kabi payment ID asosida yasalgan qiymatni haqiqiy invoice ID sifatida qaytarmang.

**Vazifa:**
1. Canonical Invoice: invoice number, student/customer, academy, issue/due date, line items, subtotal, discount, total, currency, status.
2. InvoiceLine va zarur enrollment/service relation.
3. PaymentAllocation: paymentni invoice’ga bog‘lash; partial payment va overpayment qoidasi.
4. Payment state transition, submit/approve/reject, actor va timestamp.
5. Refund/reversal: full/partial refund, original payment relation, audit trail.
6. Receipt: haqiqiy allocation’dan; unique number va protected download.
7. Debt/outstanding/overdue invoice due date va allocation’dan hisoblansin.
8. Reconciliation: invoice total = allocation + remaining balance; journal totals tekshirilsin.
9. Concurrent payment double allocation’ni transaction/locking/constraint bilan to‘xtatsin.
10. Idempotency: bir xil key + payload qayta yuborilsa oldingi natija; boshqa payload bo‘lsa 409/validation error.
11. Finance permissions; Student/Parent faqat o‘z invoice/payment/receiptini ko‘rsin.
12. Frontend invoice list/detail/create, payment submit/approve/reject, partial payment, refund, receipt, overdue, export.
13. Dashboard faqat real DB aggregation; nullni noto‘g‘ri ravishda 0 deb ko‘rsatmang.

**Qabul mezoni:** invoice create → partial payment → remaining debt → full payment → receipt; overdue; refund/reversal; duplicate idempotency va concurrency; ledger bilan summary matematik mos; cross-student/academy access 403/404; fake Paid/Invoice/Receipt yo‘q.

## 5. P1 — Student va Parent lifecycle

**Qayd etilgan holat:** `ReqStudent` backend contractida `groupId`, `parentPhone`, `parentName` talab qilinadi; `AuthService.saveStudent()` mavjud parentni phone + `ROLE_PARENT` bo‘yicha qidiradi va group ID tekshiradi. Frontend create flow contractga to‘liq mos emas; UI saqlanmaganini ochiq ko‘rsatadi.

**Vazifa:** Student create/edit formaga parent/group ma’lumotlarini qo‘shing. Parent mavjud bo‘lsa tanlash, bo‘lmasa account/invite yaratish. Phone normalization/unique policy. Group faqat shu academy’dan. Student, parent relation, user account, group membership va audit event transaction ichida yaratilishi. Active/inactive/transferred/withdrawn lifecycle; transfer history; multi-child parent relation; invitation create/expire/accept/resend/revoke. Student/Parent faqat o‘z ma’lumotini ko‘rsin; peer phone/Telegram/grade/attendance yashirilsin. Schedule, attendance, grades, tasks, payments, materials bitta canonical backenddan.

**Qabul mezoni:** Admin/Manager student create → parent invite → group assignment → login → parent child view; edit/transfer/deactivate; cross-parent/student negative tests.

## 6. P1 — Manager, Leads, enrollment, courses, groups

**Qayd etilgan holat:** leads/conversion/enrollment va manager workflowlar to‘liq backend E2E bilan tasdiqlanmagan; ayrim sahifalarda demo/local data qolishi mumkin.

**Vazifa:** Lead CRUD backendda persist; immutable `leadId`; server-side search/filter/sort/pagination; Kanban drag/drop serverga yozilsin va xatoda rollback. Lead → Student conversion bitta transaction: student, parent relation, enrollment, group membership, zarur invoice, audit. Conversion idempotent; duplicate student/invoice yo‘q; xatoda rollback. Trial date/time/timezone/teacher/room/note va conflict validation. Enrollment status/start/end/course/group/pricing/discount/invoice. Course/group create/edit/archive/capacity/teacher/schedule/room. Transfer/withdrawal. Manager academy scope. KPI server aggregationdan.

**Qabul mezoni:** lead CRUD → trial → conversion → student/enrollment/group/invoice; duplicate conversion; rollback; cross-academy negative test.

## 7. P1 — Teacher, attendance, tasks, assignments, grades

### Attendance

**Qayd etilgan holat:** bulk endpoint alias/controller adapter mavjud; teacher groups/rosters backenddan; targeted ownership tests bor. Full correction/approval workflow yo‘q yoki isbotlanmagan.

**Vazifa:** Attendance studentId/groupId/lesson-date bilan bog‘lansin. Canonical status PRESENT/ABSENT/LATE/EXCUSED (yoki backend tasdiqlagan enum). Default hammani ABSENT qilmang; explicit action bo‘lsin. Duplicate DB unique constraint. Future date va boshqa group student serverda rad etilsin. Correction/approval reason + audit. Bulk update transaction; partial errors aniq.

**Qabul mezoni:** teacher own groups; barcha statuslar; duplicate/future date rejection; correction/audit; parent/student view.

### Tasks / assignments / submissions

**Qayd etilgan holat:** Task partial update’dagi omitted user/group relation saqlanishi va cross-group reassignment denial testlangan. Assignment/grade UI API mode’da fake persistence qilmaydi, lekin workflow tugallanmagan.

**Vazifa:** partial update fixni saqlang; teacher faqat own group/student scope. Assignment lifecycle draft → published → closed; due date, late policy, attachment, submission version, feedback. Student faqat o‘z assignmentini topshirsin; boshqa student submissioniga kira olmasin. File authorization SEC-008 bilan. API mode’da local-only saved yoki demo assignment yo‘q.

**Qabul mezoni:** create/publish → student submission → teacher feedback/grade → close; ownership/tenant tests.

### Grades

Grade immutable studentId/groupId/assignmentId/lessonId bilan bog‘lansin, ism bilan emas. Grading scale, decimal precision, edit permission, history, publish/visibility. Teacher faqat own group; Parent/Student faqat o‘z bahosini ko‘rsin. Published grade edit auditga tushsin.

**Qabul mezoni:** grade create/edit/history/publish; cross-group/student denial.

## 8. P1 — qolgan modullar va integratsiyalar

- **Dashboard/Reports:** KPI/chart server aggregation; random/hard-coded yo‘q; academy/date/timezone filter; CSV formula injection va export encoding.
- **Courses/Groups/Rooms/Schedule:** CRUD, capacity, teacher/room assignment, conflict detection va transaction safety.
- **Notifications/Chats/SSE:** recipient ownership, read/unread, pagination, SSE auth/academy/group scope, cleanup/reconnect, cross-tenant broadcast yo‘q, multi-client test.
- **Telegram/NazoratBot:** token secret’da; bounded retry/backoff, idempotency/deduplication, timeout/error handling, delivery status/monitoring. Provider sozlanmagan bo‘lsa “yuborildi” demasin. Bot xatosi CRM transactionni noto‘g‘ri state’da qoldirmasin.
- **Settings/User management:** create/edit/invite/deactivate/reactivate; Admin/Super Admin farqi; role change session/cache invalidation; server-side pagination/search/filter; takroriy navigationni UX audit bilan tozalash. Save/Invite/Export/Delete haqiqiy action yoki aniq disabled/unavailable state.

## 9. P1 — Database integrity va performance

**Qayd etilgan holat:** Flyway V1–V3 fresh DB va schema-only legacy fixture’da testdan o‘tgan. Bu production snapshot upgrade kafolati emas; constraints/index/concurrency review to‘liq emas.

**Vazifa:** FK/NOT NULL/UNIQUE/CHECK/cascade; tenant-aware constraints/indexes; duplicate payment/invoice/attendance/submission DB darajasida bloklansin. Money uchun DECIMAL/NUMERIC, currency/rounding policy. UTC storage va academy timezone display. Phone normalization. N+1/query profiling/pagination/index. Transaction isolation/locking. Flyway eski migrationni tahrirlamasdan yangi version. Sanitized production-shaped upgrade rehearsal. Backup/restore runbook va test.

**Qabul mezoni:** fresh DB, legacy upgrade, production-shaped upgrade, constraints, concurrency, schema validation, backup restore.

## 10. P2/P3 — frontend quality

- Har sahifada loading/empty/error/forbidden/offline/retry/success.
- Server validation field-level; double submit/race/stale cache/optimistic rollback.
- Direct URL, refresh, back/forward, expired session, multi-tab logout.
- Desktop/tablet/mobile; table/dialog/sidebar/chart overflow.
- Keyboard/focus/labels/semantic headings/contrast/screen reader.
- Uzbek/English localization; date/number/currency format.
- Lighthouse performance/accessibility; lazy routes, bundle/image optimization, rerender/query cache.
- Lint’dagi 29 warningni tahlil qiling; rule o‘chirib yashirmang.
- `knip`/dead-code analyzer; dynamic routes/importlarni hisobga oling.
- console.log/debug/dead routes/Clerk qoldiqlari; random KPI yo‘q. Test fixture random bo‘lsa deterministic qiling.

**Qabul mezoni:** barcha role responsive/a11y smoke; Lighthouse natijalari; console error yo‘q; lint warnings izohlangan yoki tuzatilgan.

## 11. Majburiy testlar

### Frontend

```bash
pnpm install --frozen-lockfile
pnpm exec tsc -b --pretty false
pnpm lint
pnpm test
pnpm build
```

Mavjud testlarni o‘chirmang/skip qilmang. Component testdan tashqari har role uchun Playwright yoki ekvivalent E2E; real backend test environment’da integration; Network/server log bilan real persistence tasdiqlansin.

### Backend

```bash
cd backend
./mvnw -DskipTests compile
./mvnw test
./mvnw verify
```

Fresh PostgreSQL, schema-only legacy fixture, production-shaped sanitized upgrade, JWT/security negative tests, tenant/role/ownership matrix, finance concurrency/idempotency, student/parent, leads/conversion, attendance, assignments, grades integration/E2E. DB yo‘q bo‘lsa BLOCKED.

### Role × action matrix

Barcha rollar: `SUPER_ADMIN`, `ADMIN`, `MANAGER`, `TEACHER`, `FINANCE`, `STUDENT`, `PARENT`. Har birida own/foreign academy, own/foreign resource, list/detail/create/update/delete/export/download, missing/expired/revoked token, unknown role, disabled user test qilinsin. Ruxsatli holat 2xx; ruxsatsiz 401/403 yoki ma’lumot borligini oshkor qilmaydigan 404.

### Business acceptance

1. Admin user yaratadi, role beradi, deactivate/reactivate.
2. Manager lead yaratadi, trial belgilaydi, studentga conversion qiladi.
3. Student yaratiladi, parent bog‘lanadi, groupga biriktiriladi.
4. Teacher own groupda attendance va correction.
5. Teacher assignment publish; student submit; teacher grade; grade publish.
6. Student/Parent faqat o‘z ma’lumotini ko‘radi.
7. Finance invoice, partial payment, debt, receipt, refund/reversal.
8. Dashboard/report DB bilan mos.
9. Notification/Telegram/SSE ownership/retry.

## 12. Bajarish tartibi

### Phase 0 — Audit/baseline
Source inventarizatsiyasi; oldingi findinglarni CONFIRMED OPEN/FIXED/PARTIAL/NOT REPRODUCED/NOT TESTED deb evidence bilan tasniflash; FE API ↔ BE mapping; testlarni qayta ishga tushirish.

### Phase 1 — P0 security/auth/API
Yagona auth; HttpOnly/BFF; refresh/revoke/logout; password reset/rate limit; Parent/Student role; tenant/ownership; CORS/CSRF/secrets/file; OpenAPI/login DTO; integration/negative tests.

### Phase 2 — Core backend/data
Invoice ledger; Student/Parent lifecycle; Lead/enrollment/group/course; attendance/tasks/assignments/grades; audit/notifications.

### Phase 3 — Frontend integration
Har modul real API; API mode’da demo/local fallback yo‘q; loading/error/empty/forbidden/success; DTO mapper/cache invalidation.

### Phase 4 — E2E/quality
Role E2E; responsive/a11y/performance; Telegram/file/SSE; lint; deployment/backup/restore.

### Phase 5 — Release candidate
Barcha report/changelog yangilansin; P0/P1 evidence bilan yopilsin; qolgan P2/P3 risklar ochiq ko‘rsatilsin.

## 13. Finding tracker

`MANUS_REMEDIATION_TRACKER.md` yarating. Har finding uchun: ID, severity, status (OPEN/IN_PROGRESS/FIXED/BLOCKED/NOT_APPLICABLE), evidence (path/class/method/line/test), root cause, code fix, migration, test command/result, remaining risk.

Eski IDlar: `ARCH-001..003`, `SEC-001..008`, `DB-001..003`, `BE-001..005`, `FE-001..005`, `API-001..003`, `DEAD-001..003`, `TEST-001..002`, `PERF-001..002`, `A11Y-001`, `RESP-001`. Yangi topilmalar uchun yangi ID. `FIXED` faqat code + passing test/evidence bilan.

## 14. Definition of Done

Modul DONE bo‘lishi uchun: backend endpoint/DTO/service/repository; DB schema/migration/constraints; server auth/role/tenant/ownership; real API frontend; loading/empty/error/forbidden/success; server/client validation; unit + integration + negative security test; real PostgreSQL E2E; kerakli audit log; docs; fake/demo success yo‘q; regression tests.

## 15. Final release gate

`PRODUCTION READY` faqat: P0 auth/security/tenant yopilgan; P1 biznes workflowlar real DB bilan ishlaydi; barcha FE API backend contractga mos; frontend typecheck/lint/test/build PASS; backend compile/unit/integration/verify PASS; fresh + upgrade migration PASS; barcha role E2E PASS; finance reconciliation PASS; file/CORS/secrets/rate-limit PASS; critical/high security finding yo‘q; secret scan clean; backup/restore va deployment runbook tekshirilgan.

Majburiy test BLOCKED bo‘lsa release BLOCKED. Taxminiy foizni test natijasi sifatida ko‘rsatmang.

**Yakuniy topshiriq:** bitta yangi ZIP: frontend, canonical backend, migrations, xavfsiz `.env.example`, README, tracker, to‘liq API contract/matrix, security va DB migration report, test loglari va qolgan blockerlar. Yakuniy javobda fixed/open/blocked, o‘zgargan fayllar, test natijalari, API mosligi, role E2E, finance/student workflow va release qarorini ko‘rsating.
