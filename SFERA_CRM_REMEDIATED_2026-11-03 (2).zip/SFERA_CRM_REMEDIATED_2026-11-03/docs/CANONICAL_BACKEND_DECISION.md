# Canonical backend decision

The canonical backend is the Spring Boot project bundled at `backend/` in the frontend source archive. It is the only variant containing the finance domain, payment migration, and finance tests required by the frontend contract. The standalone backend archive is retained as a reference/legacy variant and must not be merged wholesale.

## Rules
- Changes are made to the bundled backend first.
- The standalone reference receives only security/configuration hardening that is safe and independently compilable.
- No duplicate controller, entity, repository, or migration is copied between variants.
