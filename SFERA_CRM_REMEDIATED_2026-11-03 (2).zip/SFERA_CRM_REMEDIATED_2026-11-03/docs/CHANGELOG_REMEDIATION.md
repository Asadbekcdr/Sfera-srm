# Remediation changelog

## 2026-10-30

| ID | Severity | Change | Files | Verification | Remaining risk |
|---|---|---|---|---|---|
| ARCH-001 | P0 | Selected bundled Spring backend as canonical because it contains finance and migration artifacts. | `docs/CANONICAL_BACKEND_DECISION.md` | Source inventory comparison | Legacy standalone backend still exists and must not be deployed accidentally. |
| DB-001 | P0 | Changed default `ddl-auto` from `update` to `validate`. | `backend/src/main/resources/application.properties`, `.env.example` | Static config inspection; runtime DB validation pending | Requires a fresh/upgrade PostgreSQL test. |
| SEC-001 | P0 | Restricted demo seed loader to `dev` profile. | `backend/src/main/java/sfera/crmsfera/component/DataLoader.java` | Compile/test pending | Existing databases may contain previously seeded credentials; rotate/reset them. |
| SEC-002 | P0 | Externalized CORS allowlist. | `backend/src/main/java/sfera/crmsfera/security/SecurityConfig.java`, `application.properties` | Compile/static inspection | Production origin must be set in deployment secrets. |
| FE-001 | P1 | Removed silent demo-group fallback in API mode. | `src/features/teacher/index.tsx` | Typecheck/build pending | Other modules still contain legacy/demo paths and need individual migration. |


## Remaining-work phase — 2026-10-30

| ID | Severity | Change | Verification | Remaining risk |
|---|---|---|---|---|
| SEC-JWT-001 | P0 | Added issuer, audience, access-token type and minimum secret-length validation; stopped token-content logging. | Bundled backend compile required; integration 401 tests pending DB. | Refresh/revoke/password reset/rate-limit are not yet implemented. |
| SEC-OWNER-001 | P0 | Restricted parent collection operations to admin roles and authenticated task reads. | Bundled backend compile required. | Full resource ownership and academy tenant checks remain. |
