# Database migration report

Date: 2026-10-30

## Migration source of truth

The bundled backend is the canonical backend. Its Flyway directory is:

```text
backend/src/main/resources/db/migration
```

The `ddl-auto` default is `validate`; schema mutation is intended to occur through Flyway only.

## Changes in this phase

`V3__action_event_audit.sql` was added. It creates the missing `action_event` audit table used by `ActionEvent` and `ActionAuditAspect`, and adds indexes for creation time, actor, and entity lookup. The migration uses `CREATE TABLE IF NOT EXISTS` and `CREATE INDEX IF NOT EXISTS`, so it is non-destructive for an existing database.

## Verification

| Check | Result |
|---|---|
| Backend compile after V3 | PASS after compile run |
| Fresh PostgreSQL migration | BLOCKED — PostgreSQL was not available at `localhost:5432` |
| Existing database upgrade | BLOCKED — no database snapshot/instance was supplied |
| Hibernate validation against migrated schema | BLOCKED — requires PostgreSQL |
| Constraint/index runtime verification | BLOCKED — requires PostgreSQL |

No database test is marked PASS without a real PostgreSQL run.
