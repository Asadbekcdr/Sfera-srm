# API contract status — verified subset

This is a verification note for the supplied source snapshot, not a complete generated OpenAPI contract. The client normalizer is `src/lib/api-client.ts`; canonical Spring mappings are under `backend/src/main/java/sfera/crmsfera/controller/`.

## Verified route relationships

| Frontend request | Rewrite / backend mapping | Status |
|---|---|---|
| `POST /api/v1/auth/login` | `/auth/login` → `POST /auth/login` | Route matched; backend returns a token envelope; frontend manually decodes claims into a user object. Full role/claim lifecycle contract remains open. |
| `/api/v1/auth/{path}` | `/auth/{path}` | AuthController exposes login/verify/register; password recovery, refresh and revocation are not complete. |
| `GET /teacher/groups` | `/group/all` | GroupController filters teacher groups using the authenticated principal. The attendance UI uses actual numeric IDs from this response; DTO validation beyond its current consumer is partial. |
| `/api/v1/groups` | `/group/all` | Alias exists; pagination, DTO and role scope are not verified for every consumer. |
| `/api/v1/groups/{id}` and `/api/v1/groups/{id}/students` | `/group/{id}` | Group detail contains student data; client maps the `students` array for attendance. Response contract is covered only for the attendance consumer, not globally. |
| `/api/v1/students` and `/api/v1/students/{path}` | `/student` and `/student/{path}` | Partial. Creation is `POST /student/saveStudent`, update `PUT /student`; create needs parent/group details absent from the current dialog. |
| `/api/v1/teachers/{path}` | `/teacher/{path}` | Alias exists; full CRUD contract is not covered. |
| `/api/v1/dashboard/summary` | `/dashboard` | Alias exists; role aggregation is not fully E2E verified. |
| `/api/v1/dashboard/teacher` and `/teacher/dashboard` | `/dashboard/teacher` | Alias exists; teacher dashboard shows only fields returned by the backend in API mode. |
| `POST /api/v1/attendance/bulk` | `POST /attendance/bulk` → attendance service | New envelope `{groupId, sessionDate, records}` is adapted to canonical `AttendanceDto` records and tested. Supported backend status enum is `KELDI`, `KELMADI`, `SABABLI`; UI late/excused both map to `SABABLI`, so this loses detail and is a product-domain limitation. |
| `POST /api/v1/attendance` | `POST /attendance?groupId=…` | Existing service route remains; caller/DTO lifecycle is not fully unified. |
| `GET /api/v1/attendance/{id}` | `GET /attendance/{id}` | Principal-aware per-record ownership check was added and tested. |
| `/api/v1/tasks` and `/api/v1/tasks/{id}` | `/tasks`; controller accepts `PUT /tasks/{id}` and legacy `/tasks/update` | Partial updates preserve associations; service scopes teacher task access/assignment. Full API/role/tenant contract still needs integration coverage. |
| `/api/v1/finance/*` | `/api/v1/finance/*` | Payment summary/create/approve/reject endpoints exist. This is not an invoice/refund/receipt/reconciliation ledger. |

The frontend route alias regression verifies `POST /api/v1/attendance/bulk` rewrites to `/attendance/bulk`; controller tests verify the request date/group adapter. These checks do not cover every route, status code, DTO, pagination envelope, enum, role or error response.

## Contract gaps blocking release

Complete method/path/DTO/status/pagination coverage is not generated or verified. Login relies on manual JWT claim mapping; frontend `PARENT`/`Student` role representation differs from backend roles. Student registration requires parent/group; invitations, recovery, refresh/revoke endpoints are incomplete. Assignment and grade pages are intentionally unavailable in API mode rather than claiming local changes were persisted. Finance has payment operations but no canonical invoice/debt/refund/receipt ledger. Mixed legacy and `/api/v1` routes remain. Complete role/academy isolation and all frontend calls need API contract and end-to-end tests before deployment.
