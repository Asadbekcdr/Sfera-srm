# SFERA CRM — master audit holati (2026-10-30)

## Qaror

**BLOCKED — productionga chiqarish mumkin emas.** Tanlangan frontend va backend xatolari amalda tuzatildi, full browser suite va ikki PostgreSQL migration ssenariysi qayta bajarildi. Lekin handoff acceptance matrixdagi barcha P0/P1 business flow, tenant/role chegaralari, API contract va production-operatsion talablar yopilmagan.

## Yakunlangan, test bilan tasdiqlangan ishlar

Task partial update yuborilmagan user/group aloqalarini saqlaydi; teacher o‘z taskini boshqa teacher guruhiga ko‘chira olmaydi. Disabled account JWT principal olmaydi. Attendance/mark single-record access principal-aware; teacher markni faqat o‘z guruhida o‘zgartiradi va boshqa guruh studentiga biriktira olmaydi. Attendance SSE group bo‘yicha ajratildi. CORS wildcard/malformed origin konfiguratsiyasi startupda rad etiladi.

Attendance UI uchun backend group/roster va bulk request contract qo‘shildi. Teacher dashboard API rejimida backend qaytargan metrikalardan boshqani ko‘rsatmaydi; assignment/grade va finance-student sahifalari API rejimida demo ma’lumotni yashirib, persist qilinmaydigan amalni saqlangandek ko‘rsatmaydi. Unconfigured SMS ham yuborilgan deb bildirmaydi. Payment idempotency conflict va invoice ledger yo‘qligi sababli finance KPI honesty saqlanadi. Flyway V1–V3 clean/legacy PostgreSQL’da sinovdan o‘tdi.

## Yakuniy test holati

Frontend: 32 fayl/158 browser test PASS; typecheck PASS; build PASS; lint 0 error va 29 warning. Backend: 29 test PASS (0 failure/error/skip) fresh PostgreSQL’da va 29 test PASS schema-only legacy baseline’da; Flyway va Hibernate validate o‘tdi. Batafsil command/loglar `RELEASE_TEST_REPORT.md` hamda `release-evidence/` ichida.

## Ochiq P0/P1 to‘siqlar

HttpOnly token/session, password reset/OTP server flow, refresh/revocation/logout, login rate-limit va parallel Clerk/JWT arxitekturasi; tenant isolation va barcha role matritsasi; Parent/Student role mapping; complete invoice/debt/refund/receipt ledger; student lifecycle va invitation; assignment/grade/leads/enrollment va boshqa biznes E2E; barcha API uchun contract testing; file storage security; production CORS/secret/deployment, performance/load, backup/restore hamon yopilmagan. Teacher assignment/grade va finance student sahifalari backend contract tugamaguncha API rejimida ataylab unavailable.

Topilmalarning id-by-id disposition’i `SUPPLEMENTAL_AUDIT_REVIEW.md`da, release gate esa `RELEASE_AUDIT.md`da. Test PASS production approval emas.
