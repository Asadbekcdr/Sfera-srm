package sfera.crmsfera.controller;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors;
import org.springframework.test.web.servlet.MockMvc;
import sfera.crmsfera.dto.ApiResponse;
import sfera.crmsfera.entity.enums.Role;
import sfera.crmsfera.service.AuthService;
import sfera.crmsfera.service.UserService;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class AdminControllerAuthorizationTest {
    @Autowired MockMvc mockMvc;
    @MockitoBean AuthService authService;
    @MockitoBean UserService userService;

    @ParameterizedTest
    @ValueSource(strings = {"MANAGER", "TEACHER", "FINANCE", "STUDENT", "PARENT", "DIRECTOR"})
    void nonAdminRolesCannotEnumerateAdminAccountsOrDeactivateUsers(String role) throws Exception {
        var principal = user("non-admin").roles(role);
        mockMvc.perform(get("/admin/list").with(principal)).andExpect(status().isForbidden());
        mockMvc.perform(get("/admin/1").with(principal)).andExpect(status().isForbidden());
        mockMvc.perform(get("/admin").with(principal)).andExpect(status().isForbidden());
        mockMvc.perform(delete("/admin/1").with(principal)).andExpect(status().isForbidden());

        verifyNoInteractions(userService);
        verifyNoInteractions(authService);
    }

    @Test
    void adminRoleCanUseAdminDirectory() throws Exception {
        when(userService.getAllList(Role.ROLE_ADMIN)).thenReturn(ApiResponse.success(List.of(), "Success"));

        mockMvc.perform(get("/admin/list").with(user("admin").roles("ADMIN")))
                .andExpect(status().isOk());

        verify(userService).getAllList(Role.ROLE_ADMIN);
    }
}
