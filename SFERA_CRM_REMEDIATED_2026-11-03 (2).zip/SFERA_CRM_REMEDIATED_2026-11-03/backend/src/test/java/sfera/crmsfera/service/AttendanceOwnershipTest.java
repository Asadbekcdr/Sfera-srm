package sfera.crmsfera.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import sfera.crmsfera.entity.Attendance;
import sfera.crmsfera.entity.Student;
import sfera.crmsfera.exception.ForbiddenException;
import sfera.crmsfera.mapper.AttendanceMapper;
import sfera.crmsfera.repository.AttendanceRepository;
import sfera.crmsfera.repository.GroupRepository;
import sfera.crmsfera.repository.StudentRepository;
import sfera.crmsfera.security.CustomUserDetails;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AttendanceOwnershipTest {
    @Mock AttendanceRepository attendanceRepository;
    @Mock GroupRepository groupRepository;
    @Mock StudentRepository studentRepository;
    @Mock AttendanceMapper attendanceMapper;

    private AttendanceService service() {
        return new AttendanceService(attendanceRepository, groupRepository, studentRepository, attendanceMapper);
    }

    @Test
    void studentCannotReadAnotherStudentsAttendanceById() {
        CustomUserDetails current = mock(CustomUserDetails.class);
        Student currentStudent = mock(Student.class);
        Student recordOwner = mock(Student.class);
        Attendance attendance = mock(Attendance.class);
        when(current.getRole()).thenReturn("ROLE_STUDENT");
        when(current.getStudent()).thenReturn(currentStudent);
        when(currentStudent.getId()).thenReturn(10L);
        when(recordOwner.getId()).thenReturn(11L);
        when(attendance.getStudent()).thenReturn(recordOwner);
        when(attendanceRepository.findById(5L)).thenReturn(Optional.of(attendance));

        assertThrows(ForbiddenException.class, () -> service().getAttendance(current, 5L));
        verifyNoInteractions(attendanceMapper);
    }

    @Test
    void studentCanReadTheirOwnAttendance() {
        CustomUserDetails current = mock(CustomUserDetails.class);
        Student currentStudent = mock(Student.class);
        Attendance attendance = mock(Attendance.class);
        when(current.getRole()).thenReturn("ROLE_STUDENT");
        when(current.getStudent()).thenReturn(currentStudent);
        when(currentStudent.getId()).thenReturn(10L);
        when(attendance.getStudent()).thenReturn(currentStudent);
        when(attendanceRepository.findById(5L)).thenReturn(Optional.of(attendance));

        service().getAttendance(current, 5L);

        verify(attendanceMapper).toDto(attendance);
    }
}
