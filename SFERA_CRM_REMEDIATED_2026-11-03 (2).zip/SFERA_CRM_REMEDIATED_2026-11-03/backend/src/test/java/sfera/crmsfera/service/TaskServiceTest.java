package sfera.crmsfera.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import sfera.crmsfera.exception.ForbiddenException;
import sfera.crmsfera.dto.request.ReqTask;
import sfera.crmsfera.entity.Group;
import sfera.crmsfera.entity.Task;
import sfera.crmsfera.entity.User;
import sfera.crmsfera.entity.enums.Role;
import sfera.crmsfera.mapper.TaskMapper;
import sfera.crmsfera.repository.GroupRepository;
import sfera.crmsfera.repository.TaskRepository;
import sfera.crmsfera.repository.UserRepository;
import sfera.crmsfera.security.CustomUserDetails;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TaskServiceTest {
    @Mock TaskRepository taskRepository;
    @Mock UserRepository userRepository;
    @Mock GroupRepository groupRepository;
    @Mock TaskMapper taskMapper;
    @Mock NotificationService notificationService;

    private TaskService service() {
        return new TaskService(taskRepository, userRepository, groupRepository, taskMapper, notificationService);
    }

    @Test
    void partialUpdateWithoutAssignmentIdsRetainsExistingUserAndGroup() {
        User assignedUser = User.builder().fullName("Assigned user").build();
        Group assignedGroup = Group.builder().name("Assigned group").build();
        Task task = Task.builder().id(1L).title("Old title").user(assignedUser).group(assignedGroup).build();
        when(taskRepository.findById(1L)).thenReturn(Optional.of(task));

        service().updateTask(admin(), 1L, ReqTask.builder().taskId(1L).title("New title").build());

        assertSame(assignedUser, task.getUser());
        assertSame(assignedGroup, task.getGroup());
        assertEquals("New title", task.getTitle());
        verify(taskRepository).save(task);
    }

    @Test
    void changingGroupRetainsExistingUserWhenNoUserIdIsSubmitted() {
        User assignedUser = User.builder().fullName("Assigned user").build();
        Group newGroup = Group.builder().name("New group").build();
        Task task = Task.builder().id(2L).user(assignedUser).build();
        when(taskRepository.findById(2L)).thenReturn(Optional.of(task));
        when(groupRepository.findById(20L)).thenReturn(Optional.of(newGroup));

        service().updateTask(admin(), 2L, ReqTask.builder().taskId(2L).groupId(20L).build());

        assertSame(assignedUser, task.getUser());
        assertSame(newGroup, task.getGroup());
        verify(taskRepository).save(task);
    }

    @Test
    void teacherCannotFetchTaskFromAnotherTeachersGroup() {
        User anotherTeacher = User.builder().id(2L).role(Role.ROLE_TEACHER).phone("998900000002").build();
        Group anotherGroup = group(20L, anotherTeacher);
        Task task = Task.builder().id(5L).group(anotherGroup).build();
        when(taskRepository.findById(5L)).thenReturn(Optional.of(task));

        assertThrows(ForbiddenException.class, () -> service().getTask(teacher(), 5L));
        verifyNoInteractions(taskMapper);
    }

    @Test
    void teacherListContainsOnlyTasksFromTheirOwnGroup() {
        User assignedTeacher = User.builder().id(1L).role(Role.ROLE_TEACHER).phone("998900000001").build();
        User anotherTeacher = User.builder().id(2L).role(Role.ROLE_TEACHER).phone("998900000002").build();
        Task ownTask = Task.builder().id(1L).group(group(10L, assignedTeacher)).build();
        Task otherTask = Task.builder().id(2L).group(group(20L, anotherTeacher)).build();
        when(taskRepository.findAll()).thenReturn(List.of(ownTask, otherTask));
        when(taskMapper.toDto(ownTask)).thenReturn(null);

        var response = service().getAllTasks(teacher());

        assertEquals(1, response.getData().size());
        verify(taskMapper).toDto(ownTask);
        verify(taskMapper, never()).toDto(otherTask);
    }

    @Test
    void teacherCannotUpdateTaskOwnedByAnotherGroup() {
        User anotherTeacher = User.builder().id(2L).role(Role.ROLE_TEACHER).phone("998900000002").build();
        Task task = Task.builder().id(9L).group(group(20L, anotherTeacher)).build();
        when(taskRepository.findById(9L)).thenReturn(Optional.of(task));

        assertThrows(ForbiddenException.class,
                () -> service().updateTask(teacher(), 9L, ReqTask.builder().taskId(9L).title("change").build()));
        verify(taskRepository, never()).save(any());
    }

    @Test
    void teacherCannotMoveOwnTaskIntoAnotherTeachersGroup() {
        User assignedTeacher = User.builder().id(1L).role(Role.ROLE_TEACHER).phone("998900000001").build();
        User anotherTeacher = User.builder().id(2L).role(Role.ROLE_TEACHER).phone("998900000002").build();
        Task task = Task.builder().id(10L).group(group(10L, assignedTeacher)).build();
        when(taskRepository.findById(10L)).thenReturn(Optional.of(task));
        when(groupRepository.findById(20L)).thenReturn(Optional.of(group(20L, anotherTeacher)));

        assertThrows(ForbiddenException.class,
                () -> service().updateTask(teacher(), 10L, ReqTask.builder().taskId(10L).groupId(20L).build()));
        verify(taskRepository, never()).save(any());
    }

    private Group group(Long id, User teacher) {
        Group group = Group.builder().teacher(teacher).build();
        group.setId(id);
        return group;
    }

    private CustomUserDetails admin() {
        return CustomUserDetails.fromUser(User.builder().id(90L).phone("998900000090").role(Role.ROLE_ADMIN).build());
    }

    private CustomUserDetails teacher() {
        return CustomUserDetails.fromUser(User.builder().id(1L).phone("998900000001").role(Role.ROLE_TEACHER).build());
    }
}
