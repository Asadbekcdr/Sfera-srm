package sfera.crmsfera.security;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

class SecurityConfigCorsTest {
    @Test
    void acceptsOnlyExplicitHttpOrigins() {
        assertEquals(List.of("https://crm.example.com", "http://localhost:5173"),
                SecurityConfig.parseAllowedOrigins("https://crm.example.com, http://localhost:5173"));
    }

    @Test
    void rejectsWildcardOriginsWithCredentialedCors() {
        assertThrows(IllegalStateException.class,
                () -> SecurityConfig.parseAllowedOrigins("https://*.example.com"));
        assertThrows(IllegalStateException.class,
                () -> SecurityConfig.parseAllowedOrigins("*"));
    }

    @Test
    void rejectsPathsAndEmptyOriginLists() {
        assertThrows(IllegalStateException.class,
                () -> SecurityConfig.parseAllowedOrigins("https://crm.example.com/app"));
        assertThrows(IllegalStateException.class,
                () -> SecurityConfig.parseAllowedOrigins(" , "));
    }
}
