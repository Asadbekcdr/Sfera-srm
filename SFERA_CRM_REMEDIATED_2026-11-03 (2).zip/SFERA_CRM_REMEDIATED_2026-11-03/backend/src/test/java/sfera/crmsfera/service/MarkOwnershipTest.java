package sfera.crmsfera.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.access.AccessDeniedException;
import sfera.crmsfera.dto.request.ReqMark;
import sfera.crmsfera.dto.request.ReqMarkDTO;
import sfera.crmsfera.entity.Group;
import sfera.crmsfera.entity.Mark;
import sfera.crmsfera.entity.Student;
import sfera.crmsfera.entity.User;
import sfera.crmsfera.entity.enums.MarkStatus;
import sfera.crmsfera.entity.enums.Role;
import sfera.crmsfera.mapper.MarkMapper;
import sfera.crmsfera.repository.MarkRepository;
import sfera.crmsfera.repository.StudentRepository;
import sfera.crmsfera.repository.UserRepository;
import sfera.crmsfera.security.CustomUserDetails;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MarkOwnershipTest {
    @Mock MarkRepository markRepository;
    @Mock StudentRepository studentRepository;
    @Mock MarkMapper markMapper;
    @Mock UserRepository userRepository;

    private MarkService service() {
        return new MarkService(markRepository, studentRepository, markMapper, userRepository);
    }

    @Test
    void studentCannotReadAnotherStudentsMarkById() {
        CustomUserDetails current = mock(CustomUserDetails.class);
        Student currentStudent = mock(Student.class);
        Student recordOwner = mock(Student.class);
        Mark mark = mock(Mark.class);
        when(current.getRole()).thenReturn("ROLE_STUDENT");
        when(current.getStudent()).thenReturn(currentStudent);
        when(currentStudent.getId()).thenReturn(10L);
        when(recordOwner.getId()).thenReturn(11L);
        when(mark.getStudent()).thenReturn(recordOwner);
        when(markRepository.findById(7L)).thenReturn(Optional.of(mark));

        assertThrows(AccessDeniedException.class, () -> service().getOneMark(current, 7L));
        verifyNoInteractions(markMapper);
    }

    @Test
    void studentCanReadTheirOwnMark() {
        CustomUserDetails current = mock(CustomUserDetails.class);
        Student currentStudent = mock(Student.class);
        Mark mark = mock(Mark.class);
        when(current.getRole()).thenReturn("ROLE_STUDENT");
        when(current.getStudent()).thenReturn(currentStudent);
        when(currentStudent.getId()).thenReturn(10L);
        when(mark.getStudent()).thenReturn(currentStudent);
        when(markRepository.findById(7L)).thenReturn(Optional.of(mark));

        service().getOneMark(current, 7L);

        verify(markMapper).toFullDTO(mark);
    }

    @Test
    void teacherCannotCreateMarkForStudentOutsideAssignedGroup() {
        Student student = studentInGroupTaughtBy(2L);
        when(studentRepository.findById(11L)).thenReturn(Optional.of(student));

        assertThrows(AccessDeniedException.class, () -> service().saveMark(teacher(1L), ReqMark.builder()
                .studentId(11L).markStatus(MarkStatus.KUNLIK_BAHO).homeworkScore(3).activityScore(4).build()));
        verify(markRepository, never()).save(any());
    }

    @Test
    void teacherCannotUpdateMarkOwnedByAnotherTeachersGroup() {
        Mark mark = mock(Mark.class);
        when(mark.getStudent()).thenReturn(studentInGroupTaughtBy(2L));
        when(markRepository.findById(7L)).thenReturn(Optional.of(mark));

        assertThrows(AccessDeniedException.class, () -> service().updateMark(teacher(1L), ReqMarkDTO.builder()
                .id(7L).studentId(12L).markStatus(MarkStatus.KUNLIK_BAHO).build()));
        verify(studentRepository, never()).findById(anyLong());
        verify(markRepository, never()).save(any());
    }

    @Test
    void teacherCannotReassignOwnedMarkToStudentOutsideTheirGroup() {
        Mark mark = mock(Mark.class);
        when(mark.getStudent()).thenReturn(studentInGroupTaughtBy(1L));
        when(markRepository.findById(7L)).thenReturn(Optional.of(mark));
        when(studentRepository.findById(12L)).thenReturn(Optional.of(studentInGroupTaughtBy(2L)));

        assertThrows(AccessDeniedException.class, () -> service().updateMark(teacher(1L), ReqMarkDTO.builder()
                .id(7L).studentId(12L).markStatus(MarkStatus.KUNLIK_BAHO).build()));
        verify(markRepository, never()).save(any());
    }

    @Test
    void teacherCannotDeleteMarkOwnedByAnotherTeachersGroup() {
        Mark mark = mock(Mark.class);
        when(mark.getStudent()).thenReturn(studentInGroupTaughtBy(2L));
        when(markRepository.findById(8L)).thenReturn(Optional.of(mark));

        assertThrows(AccessDeniedException.class, () -> service().deleteMark(teacher(1L), 8L));
        verify(markRepository, never()).save(any());
    }

    @Test
    void teacherCannotUseAdminGroupMarkListing() {
        assertThrows(AccessDeniedException.class,
                () -> service().getAllMarkForAdmin(teacher(1L), null, 9L, 0, 10));
        verifyNoInteractions(markRepository);
    }

    private CustomUserDetails teacher(Long id) {
        return CustomUserDetails.fromUser(User.builder().id(id).role(Role.ROLE_TEACHER)
                .phone("99890000000" + id).build());
    }

    private Group group(User teacher) {
        Group group = Group.builder().teacher(teacher).build();
        group.setId(30L);
        return group;
    }

    private Student studentInGroupTaughtBy(Long teacherId) {
        User groupTeacher = User.builder().id(teacherId).role(Role.ROLE_TEACHER)
                .phone("99890000000" + teacherId).build();
        return Student.builder().id(11L).group(group(groupTeacher)).build();
    }
}
