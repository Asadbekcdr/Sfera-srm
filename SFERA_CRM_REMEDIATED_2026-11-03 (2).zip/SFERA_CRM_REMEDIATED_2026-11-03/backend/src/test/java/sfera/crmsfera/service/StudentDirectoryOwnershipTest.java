package sfera.crmsfera.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import sfera.crmsfera.dto.response.ResPageable;
import sfera.crmsfera.dto.response.ResStudent;
import sfera.crmsfera.entity.Group;
import sfera.crmsfera.entity.Student;
import sfera.crmsfera.entity.User;
import sfera.crmsfera.entity.enums.Role;
import sfera.crmsfera.mapper.StudentMapper;
import sfera.crmsfera.repository.GroupRepository;
import sfera.crmsfera.repository.MarkRepository;
import sfera.crmsfera.repository.StudentRepository;
import sfera.crmsfera.repository.UserRepository;
import sfera.crmsfera.security.CustomUserDetails;
import sfera.crmsfera.security.JwtService;

import java.util.List;

import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class StudentDirectoryOwnershipTest {
    @Mock StudentRepository studentRepository;
    @Mock JwtService jwtService;
    @Mock GroupRepository groupRepository;
    @Mock UserRepository userRepository;
    @Mock MarkRepository markRepository;

    private StudentService service;

    @BeforeEach
    void setUp() {
        service = new StudentService(studentRepository, new StudentMapper(), jwtService,
                groupRepository, userRepository, markRepository);
    }

    @Test
    void teacherPageSearchIsScopedToOwnGroupsAndOmitsContactPii() {
        Student student = studentWithContacts();
        when(studentRepository.searchStudentsForTeacher(eq("Ali"), eq(77L), any()))
                .thenReturn(new PageImpl<>(List.of(student), PageRequest.of(0, 10), 1));

        var response = service.getStudents(teacher(), "Ali", "998900000098", 0, 10);

        assertTrue(response.isSuccess());
        ResPageable page = response.getData();
        @SuppressWarnings("unchecked")
        List<ResStudent> students = (List<ResStudent>) page.getBody();
        assertEquals(1, students.size());
        ResStudent dto = students.get(0);
        assertEquals("Ali Student", dto.getFulName());
        assertEquals(15L, dto.getGroupId());
        assertNull(dto.getPhoneNumber());
        assertNull(dto.getParentId());
        assertNull(dto.getParentName());
        assertNull(dto.getParentPhone());
        verify(studentRepository).searchStudentsForTeacher(eq("Ali"), eq(77L), any());
        verify(studentRepository, never()).searchStudents(any(), any(), any());
    }

    @Test
    void teacherListUsesOnlyTheirOwnGroupsAndOmitsContactPii() {
        Student student = studentWithContacts();
        when(studentRepository.findAllByTeacher(77L)).thenReturn(List.of(student));

        var response = service.getStudentList(teacher());

        assertTrue(response.isSuccess());
        assertEquals(1, response.getData().size());
        assertNull(response.getData().get(0).getPhoneNumber());
        assertNull(response.getData().get(0).getParentPhone());
        verify(studentRepository).findAllByTeacher(77L);
        verify(studentRepository, never()).findAllByActiveTrue();
    }

    @Test
    void administratorsKeepExistingFullDirectoryFields() {
        Student student = studentWithContacts();
        when(studentRepository.findAllByActiveTrue()).thenReturn(List.of(student));

        var response = service.getStudentList(admin());

        assertEquals("998900000001", response.getData().get(0).getPhoneNumber());
        assertEquals("998900000098", response.getData().get(0).getParentPhone());
    }

    private Student studentWithContacts() {
        User parent = User.builder().id(98L).phone("998900000098").fullName("Parent Person")
                .role(Role.ROLE_PARENT).build();
        Group group = new Group();
        group.setId(15L);
        group.setName("Group A");
        Student student = new Student();
        student.setId(4L);
        student.setFullName("Ali Student");
        student.setPhone("998900000001");
        student.setParent(parent);
        student.setGroup(group);
        return student;
    }

    private CustomUserDetails teacher() {
        return CustomUserDetails.fromUser(User.builder().id(77L).phone("998900000077")
                .fullName("Teacher").role(Role.ROLE_TEACHER).build());
    }

    private CustomUserDetails admin() {
        return CustomUserDetails.fromUser(User.builder().id(1L).phone("998900000000")
                .fullName("Admin").role(Role.ROLE_ADMIN).build());
    }
}
