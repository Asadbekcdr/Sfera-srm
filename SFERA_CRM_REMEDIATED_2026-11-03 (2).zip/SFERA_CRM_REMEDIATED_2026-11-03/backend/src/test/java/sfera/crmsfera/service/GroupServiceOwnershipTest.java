package sfera.crmsfera.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import sfera.crmsfera.dto.GroupDTO;
import sfera.crmsfera.entity.Group;
import sfera.crmsfera.entity.User;
import sfera.crmsfera.entity.enums.Role;
import sfera.crmsfera.exception.ForbiddenException;
import sfera.crmsfera.mapper.GroupMapper;
import sfera.crmsfera.repository.CategoryRepository;
import sfera.crmsfera.repository.GroupRepository;
import sfera.crmsfera.repository.RoomRepository;
import sfera.crmsfera.repository.UserRepository;
import sfera.crmsfera.security.CustomUserDetails;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class GroupServiceOwnershipTest {
    @Mock GroupRepository groupRepository;
    @Mock UserRepository userRepository;
    @Mock RoomRepository roomRepository;
    @Mock GroupMapper groupMapper;
    @Mock CategoryRepository categoryRepository;

    private GroupService service;

    @BeforeEach
    void setUp() {
        service = new GroupService(groupRepository, userRepository, roomRepository, groupMapper, categoryRepository);
    }

    @Test
    void owningTeacherGetsOnlyTeacherRosterMapping() {
        Group group = group(10L, teacherUser(1L));
        GroupDTO dto = GroupDTO.builder().id(10L).build();
        when(groupRepository.findById(10L)).thenReturn(Optional.of(group));
        when(groupMapper.groupDTOForTeacher(group)).thenReturn(dto);

        var response = service.getGroupById(teacher(1L), 10L);

        assertSame(dto, response.getData());
        verify(groupMapper).groupDTOForTeacher(group);
        verify(groupMapper, never()).groupDTO(group);
    }

    @Test
    void unrelatedTeacherCannotReadRosterByChangingGroupId() {
        Group group = group(10L, teacherUser(1L));
        when(groupRepository.findById(10L)).thenReturn(Optional.of(group));

        assertThrows(ForbiddenException.class, () -> service.getGroupById(teacher(2L), 10L));
        verifyNoInteractions(groupMapper);
    }

    @Test
    void studentCannotReadAnEntireGroupRoster() {
        Group group = group(10L, teacherUser(1L));
        when(groupRepository.findById(10L)).thenReturn(Optional.of(group));
        CustomUserDetails student = CustomUserDetails.fromStudent(
                sfera.crmsfera.entity.Student.builder().phone("998900000003").build());

        assertThrows(ForbiddenException.class, () -> service.getGroupById(student, 10L));
        verifyNoInteractions(groupMapper);
    }

    @Test
    void adminRetainsFullGroupDirectoryMapping() {
        Group group = group(10L, teacherUser(1L));
        GroupDTO dto = GroupDTO.builder().id(10L).build();
        when(groupRepository.findById(10L)).thenReturn(Optional.of(group));
        when(groupMapper.groupDTO(group)).thenReturn(dto);

        var response = service.getGroupById(admin(), 10L);

        assertSame(dto, response.getData());
        verify(groupMapper).groupDTO(group);
    }

    private Group group(Long id, User teacher) {
        Group group = new Group();
        group.setId(id);
        group.setTeacher(teacher);
        return group;
    }

    private User teacherUser(Long id) {
        return User.builder().id(id).role(Role.ROLE_TEACHER).build();
    }

    private CustomUserDetails teacher(Long id) {
        return CustomUserDetails.fromUser(User.builder().id(id).role(Role.ROLE_TEACHER).build());
    }

    private CustomUserDetails admin() {
        return CustomUserDetails.fromUser(User.builder().id(99L).role(Role.ROLE_ADMIN).build());
    }
}
