package sfera.crmsfera.service;

import sfera.crmsfera.configuration.TrackAction;
import sfera.crmsfera.dto.ApiResponse;
import sfera.crmsfera.dto.request.ReqEvent;
import sfera.crmsfera.dto.request.ReqEventDTO;
import sfera.crmsfera.dto.request.ReqGroupNotif;
import sfera.crmsfera.entity.Event;
import sfera.crmsfera.entity.Group;
import sfera.crmsfera.entity.enums.ActionType;
import sfera.crmsfera.entity.enums.MarkCategoryStatus;
import sfera.crmsfera.exception.DataNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import sfera.crmsfera.repository.EventRepository;
import sfera.crmsfera.repository.GroupRepository;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Service
@RequiredArgsConstructor
public class EventService {
    private final EventRepository eventRepository;
    private final GroupRepository groupRepository;
    private final CopyOnWriteArrayList<SseEmitter> emitters = new CopyOnWriteArrayList<>();
    private final NotificationService notificationService;


    @TrackAction(
            type = ActionType.EVENT_CREATED,
            description = "Event yaratildi"
    )
    public ApiResponse<String> addEvent(ReqEvent reqEvent){
        List<Group> groups = groupRepository.findAllById(reqEvent.getGroupIds());
        if (groups.isEmpty()) {
            return ApiResponse.error("Group not found");
        }

        if (reqEvent.getDate().isBefore(LocalDate.now())) {
            return ApiResponse.error("Date is before now");
        }

        LocalTime startTime = LocalTime.parse(reqEvent.getStartTime());
        LocalTime endTime = LocalTime.parse(reqEvent.getEndTime());

        Event event = Event.builder()
                .name(reqEvent.getName())
                .description(reqEvent.getDescription())
                .date(reqEvent.getDate())
                .startTime(startTime)
                .endTime(endTime)
                .groupList(groups)
                .build();
        eventRepository.save(event);

        // Notification yuborish
        groups.forEach(group -> notificationService.sendGroupNotification(ReqGroupNotif.builder()
                        .groupId(group.getId())
                        .title("Sfera Academy xabarnomasi")
                        .description("Bizda  " + reqEvent.getDate() + " sanada " + reqEvent.getName() + " nomli tadbir bulib o'tadi. " +
                                " Boshlanish vaqti: " + startTime + " Tugash vaqti: " + endTime)
                .build()));

        // Real-timega malumot yuborish uchun
        sendToAll(reqEvent().getData());
        return ApiResponse.success(null, "Success");
    }


    public ApiResponse<String> updateEvent(ReqEventDTO reqEventDTO){
        Event event = eventRepository.findById(reqEventDTO.getId()).orElseThrow(
                () -> new DataNotFoundException("Event not found")
        );

        List<Group> groups = groupRepository.findAllById(reqEventDTO.getGroupIds());
        if (groups.isEmpty()) {
            return ApiResponse.error("Group not found");
        }

        LocalTime startTime = LocalTime.parse(reqEventDTO.getStartTime());
        LocalTime endTime = LocalTime.parse(reqEventDTO.getEndTime());

        event.setName(reqEventDTO.getName());
        event.setDescription(reqEventDTO.getDescription());
        event.setDate(reqEventDTO.getDate());
        event.setStartTime(startTime);
        event.setEndTime(endTime);
        event.setGroupList(groups);
        eventRepository.save(event);
        return ApiResponse.success(null, "Success");
    }


    public ApiResponse<String> deleteEvent(Long eventId){
        Event event = eventRepository.findById(eventId).orElseThrow(
                () -> new DataNotFoundException("Event not found")
        );
        event.setActive(false);

        eventRepository.save(event);
        return ApiResponse.success(null, "Success");
    }


    public SseEmitter addEmitter() {
        SseEmitter emitter = new SseEmitter(0L);

        emitter.onCompletion(() -> emitters.remove(emitter));
        emitter.onTimeout(() -> {
            emitters.remove(emitter);
            emitter.complete();
        });
        emitter.onError(e -> {
            emitters.remove(emitter);
            emitter.completeWithError(e);
        });

        emitters.add(emitter);

        try {
            emitter.send(SseEmitter.event().name("connected").data("ok"));
        } catch (IOException e) {
            emitters.remove(emitter);
            emitter.completeWithError(e);
        }

        return emitter;
    }

    public void sendToAll(Object data) {
        for (SseEmitter emitter : emitters) {
            try {
                emitter.send(SseEmitter.event()
                        .name("events")
                        .data(data));
            } catch (Exception e) {
                emitters.remove(emitter);
                emitter.complete();
            }
        }
    }


    public ApiResponse<List<ReqEventDTO>> getByDate(LocalDate date){
        List<ReqEventDTO> reqEvents = new ArrayList<>();
        for (Event event : eventRepository.findAllByDate(date)) {
            List<String> groupNames = event.getGroupList().stream().map(Group::getName).toList();
            ReqEventDTO reqEvent = ReqEventDTO.builder()
                    .id(event.getId())
                    .name(event.getName())
                    .description(event.getDescription())
                    .date(event.getDate())
                    .startTime(event.getStartTime().toString())
                    .endTime(event.getEndTime().toString())
                    .groupNames(groupNames)
                    .color(color(event.getDate()))
                    .build();
            reqEvents.add(reqEvent);
        }
        return ApiResponse.success(reqEvents, "Success");
    }





    public ApiResponse<List<ReqEventDTO>> reqEvent(){
        List<ReqEventDTO> reqEvents = new ArrayList<>();
        for (Event event : eventRepository.findAll()) {
            List<String> groupNames = event.getGroupList().stream().map(Group::getName).toList();
            ReqEventDTO reqEvent = ReqEventDTO.builder()
                    .id(event.getId())
                    .name(event.getName())
                    .description(event.getDescription())
                    .date(event.getDate())
                    .startTime(event.getStartTime().toString())
                    .endTime(event.getEndTime().toString())
                    .groupNames(groupNames)
                    .color(color(event.getDate()))
                    .build();
            reqEvents.add(reqEvent);
        }
        return ApiResponse.success(reqEvents, "Success");
    }


    private String color(LocalDate date){
        LocalDate today = LocalDate.now();
        if (date.isEqual(today)) {
            return MarkCategoryStatus.QIZIL.name();
        } else if (date.isAfter(today)) {
            return MarkCategoryStatus.YASHIL.name();
        } else {
            return MarkCategoryStatus.SARIQ.name();
        }
    }


}
