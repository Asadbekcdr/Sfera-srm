package sfera.crmsfera.entity.enums;

public enum PaymentStatus {
    PENDING_APPROVAL,
    APPROVED,
    REJECTED,
    REFUNDED
}
