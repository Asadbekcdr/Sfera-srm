package sfera.crmsfera.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Index;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Column;
import jakarta.persistence.Version;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import sfera.crmsfera.entity.base.BaseEntity;
import sfera.crmsfera.entity.enums.PaymentStatus;

import java.math.BigDecimal;
import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
@Entity
@Table(name = "payments", indexes = {
        @Index(name = "idx_payment_student", columnList = "student_id"),
        @Index(name = "idx_payment_status", columnList = "status"),
        @Index(name = "idx_payment_paid_at", columnList = "paid_at")
})
public class Payment extends BaseEntity {
    @Version
    private Long version;

    @ManyToOne(optional = false)
    private Student student;

    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal amount;

    @Column(nullable = false, length = 32)
    private String paymentMethod;

    @Column(nullable = false, unique = true, length = 120)
    private String idempotencyKey;

    @Column(length = 120)
    private String referenceNumber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private PaymentStatus status;

    private Instant paidAt;

    @Column(length = 500)
    private String rejectionReason;

    @Column(nullable = false, length = 32)
    private String submittedBy;

    @Column(length = 32)
    private String approvedBy;

    private Instant approvedAt;
}
