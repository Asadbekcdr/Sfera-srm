package sfera.crmsfera.controller;

import sfera.crmsfera.dto.ApiResponse;
import sfera.crmsfera.dto.request.ReqTask;
import sfera.crmsfera.dto.response.ResTask;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import sfera.crmsfera.service.TaskService;
import sfera.crmsfera.security.CustomUserDetails;

import java.util.List;

@RestController
@RequestMapping("/tasks")
@RequiredArgsConstructor
public class TaskController {

    private final TaskService taskService;


   @PostMapping
   @PreAuthorize("hasAnyRole('ROLE_MANAGER','ROLE_ADMIN','ROLE_SUPER_ADMIN','ROLE_TEACHER')")
    public ResponseEntity<ApiResponse<String>> saveTask(@AuthenticationPrincipal CustomUserDetails current,
                                                         @RequestBody ReqTask reqTask){
       return ResponseEntity.ok(taskService.createTask(current, reqTask));
   }


   @PutMapping({"/update", "/{taskId}"})
   @PreAuthorize("hasAnyRole('ROLE_MANAGER','ROLE_ADMIN','ROLE_SUPER_ADMIN','ROLE_TEACHER')")
    public ResponseEntity<ApiResponse<String>> updateTask(@AuthenticationPrincipal CustomUserDetails current,
                                                          @PathVariable(required = false) Long taskId,
                                                          @RequestBody ReqTask reqTask){
       Long effectiveTaskId = taskId != null ? taskId : reqTask.getTaskId();
       return ResponseEntity.ok(taskService.updateTask(current, effectiveTaskId, reqTask));
   }


   @DeleteMapping("/{taskId}")
   @PreAuthorize("hasAnyRole('ROLE_MANAGER','ROLE_ADMIN','ROLE_SUPER_ADMIN')")
    public ResponseEntity<ApiResponse<String>> deleteTask(@AuthenticationPrincipal CustomUserDetails current,
                                                          @PathVariable Long taskId){
       return ResponseEntity.ok(taskService.deleteTask(current, taskId));
   }


   @GetMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<List<ResTask>>> getAllTasks(@AuthenticationPrincipal CustomUserDetails current){
       return ResponseEntity.ok(taskService.getAllTasks(current));
   }


   @GetMapping("/{taskId}")
   @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<ResTask>> getTask(@AuthenticationPrincipal CustomUserDetails current,
                                                        @PathVariable Long taskId){
       return ResponseEntity.ok(taskService.getTask(current, taskId));
   }


}
