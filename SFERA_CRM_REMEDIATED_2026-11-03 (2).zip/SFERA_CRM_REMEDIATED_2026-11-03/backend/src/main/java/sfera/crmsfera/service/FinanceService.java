package sfera.crmsfera.service;

import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import sfera.crmsfera.dto.ApiResponse;
import sfera.crmsfera.dto.request.ReqPayment;
import sfera.crmsfera.entity.Payment;
import sfera.crmsfera.entity.Student;
import sfera.crmsfera.entity.enums.PaymentStatus;
import sfera.crmsfera.repository.PaymentRepository;
import sfera.crmsfera.repository.StudentRepository;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class FinanceService {
    private final PaymentRepository paymentRepository;
    private final StudentRepository studentRepository;

    private void requireFinance(String role) {
        if (!List.of("ROLE_FINANCE", "ROLE_ADMIN", "ROLE_SUPER_ADMIN", "ROLE_DIRECTOR").contains(role)) {
            throw new AccessDeniedException("Finance permission required");
        }
    }

    private Map<String, Object> paymentMap(Payment payment) {
        Student student = payment.getStudent();
        String[] names = (student.getFullName() == null ? "" : student.getFullName()).trim().split("\\s+", 2);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("id", String.valueOf(payment.getId()));
        result.put("invoiceId", "INV-" + payment.getId());
        result.put("studentId", String.valueOf(student.getId()));
        result.put("studentFirstName", names.length > 0 ? names[0] : "");
        result.put("studentLastName", names.length > 1 ? names[1] : "");
        result.put("groupName", student.getGroup() == null ? null : student.getGroup().getName());
        result.put("courseName", student.getGroup() == null || student.getGroup().getCategory() == null ? null : student.getGroup().getCategory().getName());
        result.put("amount", payment.getAmount().doubleValue());
        result.put("paymentMethod", payment.getPaymentMethod());
        result.put("referenceNumber", payment.getReferenceNumber());
        result.put("status", payment.getStatus().name());
        result.put("rejectionReason", payment.getRejectionReason());
        result.put("paidAt", payment.getPaidAt() == null ? null : payment.getPaidAt().toString());
        result.put("createdAt", payment.getCreatedAt() == null ? null : payment.getCreatedAt().toString());
        return result;
    }

    @Transactional
    public ApiResponse<Map<String, Object>> create(String role, String actorPhone, ReqPayment request) {
        requireFinance(role);
        String idempotencyKey = request.getIdempotencyKey().trim();
        String paymentMethod = request.getPaymentMethod().trim();
        String referenceNumber = request.getReferenceNumber() == null || request.getReferenceNumber().isBlank()
                ? null : request.getReferenceNumber().trim();
        var existing = paymentRepository.findByIdempotencyKey(idempotencyKey);
        if (existing.isPresent()) {
            Payment prior = existing.get();
            boolean sameRequest = prior.getStudent() != null
                    && Objects.equals(prior.getStudent().getId(), request.getStudentId())
                    && prior.getAmount() != null
                    && prior.getAmount().compareTo(request.getAmount().setScale(2)) == 0
                    && Objects.equals(prior.getPaymentMethod(), paymentMethod)
                    && Objects.equals(prior.getReferenceNumber(), referenceNumber)
                    && Objects.equals(prior.getSubmittedBy(), actorPhone);
            if (sameRequest) return ApiResponse.success(paymentMap(prior), "Payment already registered");
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Idempotency key has already been used for a different payment request");
        }
        Student student = studentRepository.findById(request.getStudentId())
                .orElseThrow(() -> new IllegalArgumentException("Student not found"));
        Payment payment = Payment.builder()
                .student(student)
                .amount(request.getAmount().setScale(2))
                .paymentMethod(paymentMethod)
                .idempotencyKey(idempotencyKey)
                .referenceNumber(referenceNumber)
                .status(PaymentStatus.PENDING_APPROVAL)
                .submittedBy(actorPhone)
                .build();
        return ApiResponse.success(paymentMap(paymentRepository.save(payment)), "Payment created");
    }

    @Transactional
    public ApiResponse<Map<String, Object>> approve(String role, String actorPhone, Long id) {
        if (!List.of("ROLE_ADMIN", "ROLE_SUPER_ADMIN").contains(role)) {
            throw new AccessDeniedException("Only Admin can approve payments");
        }
        Payment payment = paymentRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Payment not found"));
        if (actorPhone.equals(payment.getSubmittedBy())) {
            throw new AccessDeniedException("Payment creator cannot approve the same payment");
        }
        if (payment.getStatus() != PaymentStatus.PENDING_APPROVAL)
            throw new IllegalStateException("Only pending payments can be approved");
        payment.setStatus(PaymentStatus.APPROVED);
        payment.setPaidAt(payment.getPaidAt() == null ? Instant.now() : payment.getPaidAt());
        payment.setApprovedBy(actorPhone);
        payment.setApprovedAt(Instant.now());
        return ApiResponse.success(paymentMap(paymentRepository.save(payment)), "Payment approved");
    }

    @Transactional
    public ApiResponse<Map<String, Object>> reject(String role, String actorPhone, Long id, String reason) {
        if (!List.of("ROLE_ADMIN", "ROLE_SUPER_ADMIN").contains(role)) {
            throw new AccessDeniedException("Only Admin can reject payments");
        }
        Payment payment = paymentRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Payment not found"));
        if (actorPhone.equals(payment.getSubmittedBy())) {
            throw new AccessDeniedException("Payment creator cannot reject the same payment");
        }
        if (payment.getStatus() != PaymentStatus.PENDING_APPROVAL)
            throw new IllegalStateException("Only pending payments can be rejected");
        payment.setStatus(PaymentStatus.REJECTED);
        if (reason == null || reason.isBlank()) throw new IllegalArgumentException("Rejection reason is required");
        payment.setRejectionReason(reason.trim());
        return ApiResponse.success(paymentMap(paymentRepository.save(payment)), "Payment rejected");
    }

    public ApiResponse<Map<String, Object>> payments(String role, String status, int page, int pageSize, String from, String to, String q) {
        requireFinance(role);
        PaymentStatus parsedStatus = status == null || status.isBlank() || "all".equalsIgnoreCase(status)
                ? null : PaymentStatus.valueOf(status.trim().toUpperCase());
        Instant fromInstant = parseDate(from, false);
        Instant toInstant = parseDate(to, true);
        int safePage = Math.max(page - 1, 0);
        int safeSize = Math.min(Math.max(pageSize, 1), 100);
        Page<Payment> result = paymentRepository.search(parsedStatus, fromInstant, toInstant, q,
                PageRequest.of(safePage, safeSize, Sort.by(Sort.Direction.DESC, "createdAt")));
        List<Map<String, Object>> items = result.getContent().stream().map(this::paymentMap).toList();
        return ApiResponse.success(Map.of("items", items, "page", safePage + 1, "pageSize", safeSize,
                "total", result.getTotalElements(), "totalPages", result.getTotalPages()), "Success");
    }

    private Instant parseDate(String value, boolean endOfDay) {
        if (value == null || value.isBlank()) return null;
        try {
            return Instant.parse(value);
        } catch (Exception ignored) {
            LocalDate date = LocalDate.parse(value);
            return (endOfDay ? date.plusDays(1) : date).atStartOfDay().toInstant(ZoneOffset.UTC);
        }
    }

    public ApiResponse<Map<String, Object>> summary(String role) {
        requireFinance(role);
        Instant to = Instant.now();
        Instant from = to.minus(365, ChronoUnit.DAYS);
        BigDecimal collected = paymentRepository.sumAmount(PaymentStatus.APPROVED, from, to);
        BigDecimal refunded = paymentRepository.sumAmount(PaymentStatus.REFUNDED, from, to);
        long paymentCount = paymentRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThan(from, to);
        long pendingPaymentCount = paymentRepository.countByStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThan(
                PaymentStatus.PENDING_APPROVAL, from, to);
        long approvedPaymentCount = paymentRepository.countByStatusAndPaidAtGreaterThanEqualAndPaidAtLessThan(
                PaymentStatus.APPROVED, from, to);
        long refundCount = paymentRepository.countByStatusAndPaidAtGreaterThanEqualAndPaidAtLessThan(
                PaymentStatus.REFUNDED, from, to);

        Map<String, Object> counts = new LinkedHashMap<>();
        counts.put("invoices", null);
        counts.put("pendingInvoices", null);
        counts.put("partiallyPaidInvoices", null);
        counts.put("overdueInvoices", null);
        counts.put("payments", paymentCount);
        counts.put("pendingPayments", pendingPaymentCount);
        counts.put("approvedPayments", approvedPaymentCount);
        counts.put("refunds", refundCount);

        Map<String, Object> summary = new LinkedHashMap<>();
        summary.put("currency", "UZS");
        summary.put("periodDays", 365);
        summary.put("invoicesIssued", null);
        summary.put("collectedRevenue", collected.doubleValue());
        summary.put("outstandingBalance", null);
        summary.put("overdueBalance", null);
        summary.put("totalRefunded", refunded.doubleValue());
        summary.put("netRevenue", collected.subtract(refunded).doubleValue());
        summary.put("collectionRate", null);
        summary.put("counts", counts);
        return ApiResponse.success(summary, "Success");
    }
}
