package sfera.crmsfera.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import sfera.crmsfera.dto.AttendanceDto;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReqAttendanceBulk {
    private Long groupId;
    private LocalDate sessionDate;
    private List<AttendanceDto> records;
}
