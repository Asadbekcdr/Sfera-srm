package sfera.crmsfera.configuration;

import io.swagger.v3.oas.models.ExternalDocumentation;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {
    private static final String SECURITY_SCHEME_NAME = "bearerAuth";

//    @Bean
//    public OpenAPI customOpenAPI() {
//        return new OpenAPI()
//                .info(new Info()
//                        .title("Nazorat V2")
//                        .description("Bu API hujjatlari loyihangiz uchun Swagger orqali avtomatik yaratiladi.")
//                        .version("2.0.0")
//                        .contact(new Contact()
//                                .name("Quvonchbek Bobomurodov")
//                                .email("quvonchbekbobomurodov9@gmail.com")
//                                .url("https://sferaacademy.uz"))
//                        .license(new License()
//                                .name("Apache 2.0")
//                                .url("https://springdoc.org")))
//                .servers(Arrays.asList(
//                        new Server().url("http://5.189.158.5:8082").description("Production server"),
//                        new Server().url("https://nazorat.sferaacademy.uz:8082").description("Production server"),
//                        new Server().url("http://localhost:8082").description("Local server")
//                ))
//                .externalDocs(new ExternalDocumentation()
//                        .description("Full Documentation")
//                        .url("https://your-docs-link.com"))
//                .addSecurityItem(new SecurityRequirement().addList(SECURITY_SCHEME_NAME))
//                .components(new io.swagger.v3.oas.models.Components()
//                        .addSecuritySchemes(SECURITY_SCHEME_NAME,
//                                new SecurityScheme()
//                                        .name(SECURITY_SCHEME_NAME)
//                                        .type(SecurityScheme.Type.HTTP)
//                                        .scheme("bearer")
//                                        .bearerFormat("JWT")
//                        )
//                );
//    }


    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .addServersItem(new Server().url("http://localhost:8082"))
                .info(new Info()
                        .title("SFERA ACADEMY")
                        .description("Bu API hujjatlari loyihangiz uchun Swagger orqali avtomatik yaratiladi.")
                        .version("3.0.0")
                        .contact(new Contact()
                                .name("Haqqulov Sardor")
                                .email("haqqulovsardor51@gmail.com")
                                .url("https://sferaacademy.uz"))
                )
                .externalDocs(new ExternalDocumentation()
                        .description("Nimadir")
                        .url("https://nimadir.com"))
                .addSecurityItem(new SecurityRequirement().addList(SECURITY_SCHEME_NAME))
                .components(new io.swagger.v3.oas.models.Components()
                        .addSecuritySchemes(SECURITY_SCHEME_NAME,
                                new SecurityScheme()
                                        .name(SECURITY_SCHEME_NAME)
                                        .type(SecurityScheme.Type.HTTP)
                                        .scheme("bearer")
                                        .bearerFormat("JWT")
                        )
                );
    }
}
