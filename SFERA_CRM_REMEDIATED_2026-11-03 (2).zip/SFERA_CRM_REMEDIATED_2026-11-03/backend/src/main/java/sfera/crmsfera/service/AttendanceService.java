package sfera.crmsfera.service;

import sfera.crmsfera.configuration.TrackAction;
import sfera.crmsfera.dto.ApiResponse;
import sfera.crmsfera.dto.AttendanceDto;
import sfera.crmsfera.entity.Attendance;
import sfera.crmsfera.entity.Group;
import sfera.crmsfera.entity.Student;
import sfera.crmsfera.entity.enums.ActionType;
import sfera.crmsfera.entity.enums.AttendaceEnum;
import sfera.crmsfera.exception.DataNotFoundException;
import sfera.crmsfera.exception.ForbiddenException;
import lombok.RequiredArgsConstructor;
import sfera.crmsfera.mapper.AttendanceMapper;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import sfera.crmsfera.repository.AttendanceRepository;
import sfera.crmsfera.repository.GroupRepository;
import sfera.crmsfera.repository.StudentRepository;

import java.util.List;
import java.util.Map;
import java.time.LocalDate;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ConcurrentHashMap;

@Service
@RequiredArgsConstructor
public class AttendanceService {
    private final AttendanceRepository attendanceRepository;
    private final GroupRepository groupRepository;
    private final StudentRepository studentRepository;
    private final AttendanceMapper attendanceMapper;
    private final Map<Long, List<SseEmitter>> emittersByGroup = new ConcurrentHashMap<>();



    @TrackAction(
            type = ActionType.ATTENDANCE_TAKEN,
            description = "Davomat olindi"
    )
    public ApiResponse<String> saveAttendance(sfera.crmsfera.security.CustomUserDetails current, Long groupId, List<AttendanceDto> attendanceDtoList){
        Group group = groupRepository.findById(groupId).orElseThrow(
                () -> new DataNotFoundException("Group not found")
        );
        assertCanManageGroup(current, group);

        for (AttendanceDto attendanceDto : attendanceDtoList) {
            Student student = studentRepository.findById(attendanceDto.getStudentId()).orElseThrow(
                    () -> new DataNotFoundException("Student not found")
            );
            if (attendanceDto.getDate() == null || attendanceDto.getDate().isAfter(LocalDate.now())) {
                throw new IllegalArgumentException("Kelajak sana uchun davomat kiritib bo‘lmaydi");
            }
            if (student.getGroup() == null || !group.getId().equals(student.getGroup().getId())) {
                throw new ForbiddenException("Teacher faqat shu guruh studentlari uchun davomat kiritishi mumkin");
            }

            if (attendanceRepository.findByStudentIdAndDate(student.getId(), attendanceDto.getDate()) == null) {
                Attendance attendance = Attendance.builder()
                        .group(group)
                        .student(student)
                        .date(attendanceDto.getDate())
                        .status(attendanceDto.getStatus())
                        .description(attendanceDto.getStatus().equals(AttendaceEnum.KELDI) ?
                                null : attendanceDto.getDescription())
                        .build();
                attendanceRepository.save(attendance);
            } else {
                Attendance attendance =
                        attendanceRepository.findByStudentIdAndDate(student.getId(), attendanceDto.getDate());
                attendance.setStatus(attendanceDto.getStatus());
                attendance.setDescription(attendanceDto.getStatus().equals(AttendaceEnum.KELDI) ?
                        null : attendanceDto.getDescription());
                attendanceRepository.save(attendance);
            }

        }

        sendToGroup(group.getId(), getAllAttendanceByGroup(group.getId()));
        return ApiResponse.success(null, "Success");
    }


    public ApiResponse<String> deleteAttendance(sfera.crmsfera.security.CustomUserDetails current, Long attendanceId){
        Attendance attendance = attendanceRepository.findById(attendanceId).orElseThrow(
                () -> new DataNotFoundException("Attendance not found")
        );
        Long id = attendance.getGroup().getId();
        assertCanManageGroup(current, attendance.getGroup());
        attendanceRepository.delete(attendance);

        sendToGroup(id, getAllAttendanceByGroup(id));
        return ApiResponse.success(null, "Success");
    }


    public ApiResponse<AttendanceDto> getAttendance(sfera.crmsfera.security.CustomUserDetails current, Long attendanceId){
        Attendance attendance = attendanceRepository.findById(attendanceId).orElseThrow(
                () -> new DataNotFoundException("Attendance not found")
        );
        assertCanReadAttendance(current, attendance);

        return ApiResponse.success(attendanceMapper.toDto(attendance), "Success");
    }


    public List<AttendanceDto> getAllAttendanceByGroup(Long groupId) {
        return attendanceRepository
                .findAllByGroupIdOrderByCreatedAtDesc(groupId)
                .stream()
                .map(attendanceMapper::toDto)
                .toList();
    }

    public SseEmitter subscribe(Long groupId) {
        SseEmitter emitter = createEmitter();
        List<SseEmitter> groupEmitters = emittersByGroup.computeIfAbsent(groupId, ignored -> new CopyOnWriteArrayList<>());
        groupEmitters.add(emitter);

        emitter.onCompletion(() -> removeEmitter(groupId, emitter));
        emitter.onTimeout(() -> removeEmitter(groupId, emitter));
        emitter.onError(e -> removeEmitter(groupId, emitter));

        return emitter;
    }

    protected SseEmitter createEmitter() {
        return new SseEmitter(0L); // cheksiz timeout
    }

    // Only subscribers authorized for the changed group receive this snapshot.
    public void sendToGroup(Long groupId, Object data) {
        List<SseEmitter> groupEmitters = emittersByGroup.get(groupId);
        if (groupEmitters == null) return;
        for (SseEmitter emitter : groupEmitters) {
            try {
                emitter.send(
                        SseEmitter.event()
                                .name("attendance")
                                .data(data)
                );
            } catch (Exception e) {
                removeEmitter(groupId, emitter);
            }
        }
    }

    private void removeEmitter(Long groupId, SseEmitter emitter) {
        List<SseEmitter> groupEmitters = emittersByGroup.get(groupId);
        if (groupEmitters == null) return;
        groupEmitters.remove(emitter);
        if (groupEmitters.isEmpty()) emittersByGroup.remove(groupId, groupEmitters);
    }

    public void assertCanReadGroup(sfera.crmsfera.security.CustomUserDetails current, Long groupId) {
        Group group = groupRepository.findById(groupId).orElseThrow(() -> new DataNotFoundException("Group not found"));
        String role = current.getRole();
        if ("ROLE_ADMIN".equals(role) || "ROLE_SUPER_ADMIN".equals(role)) return;
        if ("ROLE_TEACHER".equals(role) && group.getTeacher() != null && group.getTeacher().getId().equals(current.getUser().getId())) return;
        if ("ROLE_STUDENT".equals(role) && current.getStudent() != null && current.getStudent().getGroup() != null && groupId.equals(current.getStudent().getGroup().getId())) return;
        throw new ForbiddenException("Bu guruh davomatiga kirish taqiqlangan");
    }

    private void assertCanReadAttendance(sfera.crmsfera.security.CustomUserDetails current, Attendance attendance) {
        String role = current.getRole();
        if ("ROLE_ADMIN".equals(role) || "ROLE_SUPER_ADMIN".equals(role)) return;

        if ("ROLE_TEACHER".equals(role)
                && attendance.getGroup() != null
                && attendance.getGroup().getTeacher() != null
                && current.getUser() != null
                && attendance.getGroup().getTeacher().getId().equals(current.getUser().getId())) return;

        Student student = attendance.getStudent();
        if ("ROLE_STUDENT".equals(role)
                && student != null
                && current.getStudent() != null
                && student.getId().equals(current.getStudent().getId())) return;

        if ("ROLE_PARENT".equals(role)
                && student != null
                && student.getParent() != null
                && current.getUser() != null
                && student.getParent().getId().equals(current.getUser().getId())) return;

        throw new ForbiddenException("Bu davomat yozuviga kirish taqiqlangan");
    }

    private void assertCanManageGroup(sfera.crmsfera.security.CustomUserDetails current, Group group) {
        String role = current.getRole();
        if ("ROLE_ADMIN".equals(role) || "ROLE_SUPER_ADMIN".equals(role)) return;
        if ("ROLE_TEACHER".equals(role) && group.getTeacher() != null && group.getTeacher().getId().equals(current.getUser().getId())) return;
        throw new ForbiddenException("Faqat guruhga biriktirilgan teacher yoki admin davomatni boshqarishi mumkin");
    }













}
