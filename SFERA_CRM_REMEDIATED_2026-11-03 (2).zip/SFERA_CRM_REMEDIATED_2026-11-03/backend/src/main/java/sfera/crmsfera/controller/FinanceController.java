package sfera.crmsfera.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import sfera.crmsfera.dto.ApiResponse;
import sfera.crmsfera.dto.request.ReqPayment;
import sfera.crmsfera.security.CustomUserDetails;
import sfera.crmsfera.service.FinanceService;

import java.util.Map;

@RestController
@RequestMapping("/api/v1/finance")
@RequiredArgsConstructor
public class FinanceController {
    private final FinanceService financeService;

    @GetMapping("/summary")
    @PreAuthorize("hasAnyRole('ROLE_FINANCE','ROLE_ADMIN','ROLE_SUPER_ADMIN','ROLE_DIRECTOR')")
    public ResponseEntity<ApiResponse<Map<String, Object>>> summary(@AuthenticationPrincipal CustomUserDetails current) {
        return ResponseEntity.ok(financeService.summary(current.getRole()));
    }

    @GetMapping("/payments")
    @PreAuthorize("hasAnyRole('ROLE_FINANCE','ROLE_ADMIN','ROLE_SUPER_ADMIN','ROLE_DIRECTOR')")
    public ResponseEntity<ApiResponse<Map<String, Object>>> payments(
            @AuthenticationPrincipal CustomUserDetails current,
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "20") int pageSize,
            @RequestParam(required = false) String from,
            @RequestParam(required = false) String to,
            @RequestParam(required = false) String q) {
        return ResponseEntity.ok(financeService.payments(current.getRole(), status, page, pageSize, from, to, q));
    }

    @PostMapping("/payments")
    @PreAuthorize("hasAnyRole('ROLE_FINANCE','ROLE_ADMIN','ROLE_SUPER_ADMIN')")
    public ResponseEntity<ApiResponse<Map<String, Object>>> create(
            @AuthenticationPrincipal CustomUserDetails current,
            @Valid @RequestBody ReqPayment request) {
        return ResponseEntity.ok(financeService.create(current.getRole(), current.getUsername(), request));
    }

    @PostMapping("/payments/{id}/approve")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_SUPER_ADMIN')")
    public ResponseEntity<ApiResponse<Map<String, Object>>> approve(
            @AuthenticationPrincipal CustomUserDetails current,
            @PathVariable Long id) {
        return ResponseEntity.ok(financeService.approve(current.getRole(), current.getUsername(), id));
    }

    @PostMapping("/payments/{id}/reject")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_SUPER_ADMIN')")
    public ResponseEntity<ApiResponse<Map<String, Object>>> reject(
            @AuthenticationPrincipal CustomUserDetails current,
            @PathVariable Long id,
            @RequestBody Map<String, String> body) {
        return ResponseEntity.ok(financeService.reject(current.getRole(), current.getUsername(), id, body.get("reason")));
    }
}
