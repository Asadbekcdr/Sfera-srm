package sfera.crmsfera.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ReqLogin {
    @NotBlank
    @Pattern(regexp = "^998(9[012345789]|6[0123456789]|7[0123456789]|8[0123456789]|3[0123456789]|5[0123456789])[0-9]{7}$", message = "Telefon raqam xato kiritilgan")
    private String phone;

    @NotBlank
    private String password;
}
