package sfera.crmsfera.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import sfera.crmsfera.repository.ActionEventRepository;
import sfera.crmsfera.service.ActionEventService;

@RestController
@RequestMapping("/action")
@RequiredArgsConstructor
public class ActionEventController {
    private final ActionEventService eventService;
    private final ActionEventRepository actionEventRepository;

    @GetMapping
    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_SUPER_ADMIN')")
    public SseEmitter sseEmitter(){
        SseEmitter emitter = eventService.subscribe();

        try {
            // Dastlabki ma'lumotni yuboramiz
            emitter.send(
                    SseEmitter.event()
                            .name("system-action")
                            .data(actionEventRepository.findAll())
            );
        } catch (Exception e) {
            emitter.completeWithError(e);
        }

        return emitter;
    }
}
