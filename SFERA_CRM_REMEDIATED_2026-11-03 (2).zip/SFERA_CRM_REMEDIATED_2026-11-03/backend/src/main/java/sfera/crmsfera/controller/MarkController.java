package sfera.crmsfera.controller;

import sfera.crmsfera.dto.ApiResponse;
import sfera.crmsfera.dto.request.ReqMark;
import sfera.crmsfera.dto.request.ReqMarkDTO;
import sfera.crmsfera.dto.response.ResMark;
import sfera.crmsfera.dto.response.ResPageable;
import sfera.crmsfera.entity.enums.PeriodFilter;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import sfera.crmsfera.security.CustomUserDetails;
import sfera.crmsfera.service.MarkService;

@RestController
@RequestMapping("/mark")
@RequiredArgsConstructor
public class MarkController {
    private final MarkService markService;

    @PostMapping
    @Operation(description = "MarkStatus = KUNLIK_BAHO, IMTIHON_BAHO\n " +
            "Agar imtihon baho bulsa faqat totalScore tuldiriladi, qolgani keremas")
    @PreAuthorize("hasRole('ROLE_TEACHER')")
    public ResponseEntity<ApiResponse<String>> saveMark(@AuthenticationPrincipal CustomUserDetails current,
                                                        @RequestBody ReqMark reqMark){
        return ResponseEntity.ok(markService.saveMark(current, reqMark));
    }



    @PutMapping("/update")
    @PreAuthorize("hasRole('ROLE_TEACHER')")
    @Operation(description = "MarkStatus = KUNLIK_BAHO, IMTIHON_BAHO\n " +
            "Agar imtihon baho bulsa faqat totalScore tuldiriladi, qolgani keremas")
    public ResponseEntity<ApiResponse<String>> updateMark(@AuthenticationPrincipal CustomUserDetails current,
                                                          @RequestBody ReqMarkDTO reqMarkDTO){
        return ResponseEntity.ok(markService.updateMark(current, reqMarkDTO));
    }


    @DeleteMapping("/{markId}")
    @PreAuthorize("hasRole('ROLE_TEACHER')")
    @Operation(description = "MarkStatus = KUNLIK_BAHO, IMTIHON_BAHO\n " +
            "Agar imtihon baho bulsa faqat totalScore tuldiriladi, qolgani keremas")
    public ResponseEntity<ApiResponse<String>> deleteMark(@AuthenticationPrincipal CustomUserDetails current,
                                                          @PathVariable Long markId){
        return ResponseEntity.ok(markService.deleteMark(current, markId));
    }


    @GetMapping("/byGroup/{groupId}")
    @Operation(summary = "Faqat admin uchun barcha marklarni kurish")
    @PreAuthorize("hasAnyAuthority('ROLE_ADMIN','ROLE_SUPER_ADMIN')")
    public ResponseEntity<ApiResponse<ResPageable>> getForAdmin(@AuthenticationPrincipal CustomUserDetails current,
                                                                @RequestParam(required = false) String keyword,
                                                                @PathVariable Long groupId,
                                                                @RequestParam(defaultValue = "0") int page,
                                                                @RequestParam(defaultValue = "10") int size){
        return ResponseEntity.ok(markService.getAllMarkForAdmin(current, keyword,groupId, page, size));
    }


    @GetMapping("/myMarks")
    @Operation(summary = "Teacher, Student, Parent uziga tegishli baholarni kurish")
    @PreAuthorize("hasAnyRole('ROLE_TEACHER', 'ROLE_PARENT', 'STUDENT','ROLE_SUPER_ADMIN')")
    public ResponseEntity<ApiResponse<ResPageable>> getMyMarks(@AuthenticationPrincipal CustomUserDetails customUserDetails,
                                                               @RequestParam PeriodFilter filter,
                                                               @RequestParam(defaultValue = "0") int page,
                                                               @RequestParam(defaultValue = "10") int size){
        return ResponseEntity.ok(markService.getMyMarks(customUserDetails,filter, page, size));
    }


    @GetMapping("/{markId}")
    public ResponseEntity<ApiResponse<ResMark>> getONeMark(@AuthenticationPrincipal CustomUserDetails current,
                                                            @PathVariable Long markId){
        return ResponseEntity.ok(markService.getOneMark(current, markId));
    }


    @GetMapping("/groups/{groupId}/archive-marks")
    @PreAuthorize("hasRole('ROLE_TEACHER')")
    public ResponseEntity<ApiResponse<ResPageable>> archiveMarks(
            @AuthenticationPrincipal CustomUserDetails cud,
            @PathVariable Long groupId,
            @RequestParam(required = false) String keyword,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        return ResponseEntity.ok(markService.getGroupByArchiveMarks(cud, groupId, keyword, page, size));
    }

}
