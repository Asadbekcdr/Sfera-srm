package sfera.crmsfera.security;

import sfera.crmsfera.entity.Student;
import sfera.crmsfera.entity.User;
import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

@Getter
public class CustomUserDetails implements UserDetails {

    private final User user;
    private final Student student;

    private final String fullName;
//    private final Long telegramId;
    private final String phone;
    private final String password;
    private final String role;
    private final String imgUrl;
    private final boolean active;

    public CustomUserDetails(User user) {
        this.user = user;
        this.student = null;
//        this.telegramId = user.getTelegramId();
        this.fullName = user.getFullName();
        this.phone = user.getPhone();
        this.password = user.getPassword();
        this.role = user.getRole().name();
        this.imgUrl = user.getImageUrl();
        this.active = user.isActive();
    }

    public CustomUserDetails(Student student) {
        this.user = null;
        this.student = student;
        this.fullName = student.getFullName();
//        this.telegramId = student.getTelegramId();
        this.phone = student.getPhone();
        this.password = student.getPassword();
        this.role = "ROLE_STUDENT";
        this.imgUrl = student.getImgUrl();
        this.active = student.isActive();
    }

    public boolean isUser() {
        return user != null;
    }

    public boolean isStudent() {
        return student != null;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of((GrantedAuthority) () -> role);
    }

    @Override public String getPassword() { return password; }
    @Override public String getUsername() { return phone; }
    @Override public boolean isAccountNonExpired() { return true; }
    @Override public boolean isAccountNonLocked() { return true; }
    @Override public boolean isCredentialsNonExpired() { return true; }
    @Override public boolean isEnabled() { return active; }

    public static CustomUserDetails fromUser(User user) {
        return new CustomUserDetails(user);
    }

    public static CustomUserDetails fromStudent(Student student) {
        return new CustomUserDetails(student);
    }



}

