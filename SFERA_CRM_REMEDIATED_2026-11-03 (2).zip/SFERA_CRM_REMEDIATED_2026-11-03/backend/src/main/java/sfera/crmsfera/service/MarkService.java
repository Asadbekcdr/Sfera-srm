package sfera.crmsfera.service;

import sfera.crmsfera.configuration.TrackAction;
import sfera.crmsfera.dto.ApiResponse;
import sfera.crmsfera.dto.request.ReqMark;
import sfera.crmsfera.dto.request.ReqMarkDTO;
import sfera.crmsfera.dto.response.ResMark;
import sfera.crmsfera.dto.response.ResPageable;
import sfera.crmsfera.entity.Mark;
import sfera.crmsfera.entity.Student;
import sfera.crmsfera.exception.BadRequestException;
import sfera.crmsfera.exception.DataNotFoundException;
import lombok.RequiredArgsConstructor;
import sfera.crmsfera.mapper.MarkMapper;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import sfera.crmsfera.repository.MarkRepository;
import sfera.crmsfera.repository.StudentRepository;
import sfera.crmsfera.repository.UserRepository;
import sfera.crmsfera.security.CustomUserDetails;
import sfera.crmsfera.entity.enums.*;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class MarkService {
    private final MarkRepository markRepository;
    private final StudentRepository studentRepository;
    private final MarkMapper markMapper;
    private final UserRepository userRepository;


    @TrackAction(
            type = ActionType.MARK_CREATED,
            description = "Baho quyildi"
    )
    public ApiResponse<String> saveMark(CustomUserDetails current, ReqMark reqMark){
        Student student = studentRepository.findById(reqMark.getStudentId()).orElseThrow(
                () -> new DataNotFoundException("Student not found"));
        assertTeacherOwnsStudent(current, student);


        Mark mark;
        if (reqMark.getMarkStatus().equals(MarkStatus.KUNLIK_BAHO)){
            int activity = clampScore10(reqMark.getActivityScore(), "activityScore");
            int homework = clampScore10(reqMark.getHomeworkScore(), "homeworkScore");

            int score = (activity+ homework);
            mark = Mark.builder()
                    .student(student)
                    .status(reqMark.getMarkStatus())
                    .homeworkScore(homework)
                    .activeScore(activity)
                    .totalScore(score)
                    .date(reqMark.getDate())
                    .markCategoryStatus(markCategoryStatus(score))
                    .build();
        } else {

            mark = Mark.builder()
                    .student(student)
                    .status(reqMark.getMarkStatus())
                    .homeworkScore(null)
                    .activeScore(null)
                    .totalScore(clampTotal10(reqMark.getTotalScore()))
                    .date(reqMark.getDate())
                    .markCategoryStatus(markCategoryStatus(reqMark.getTotalScore()))
                    .build();
        }

        plusCoin(mark.getTotalScore(), student); //coin hisoblash uchun

        markRepository.save(mark);
        return ApiResponse.success(null, "Success");
    }


    @TrackAction(
            type = ActionType.MARK_UPDATED,
            description = "Baho tahrirlandi")
    public ApiResponse<String> updateMark(CustomUserDetails current, ReqMarkDTO reqMarkDTO ){
        Mark mark = markRepository.findById(reqMarkDTO.getId()).orElseThrow(
                () -> new DataNotFoundException("Mark not found"));
        assertTeacherOwnsStudent(current, mark.getStudent());

        Student student = studentRepository.findById(reqMarkDTO.getStudentId()).orElseThrow(
                () -> new DataNotFoundException("Student not found"));
        assertTeacherOwnsStudent(current, student);

        LocalDate today = LocalDate.now();
        if (mark.getDate() != null && mark.getDate().isBefore(today)) {
            throw new BadRequestException("O'tgan kun bahosini o'zgartirib bo'lmaydi");
        }
        Integer oldTotal = mark.getTotalScore();

        if (reqMarkDTO.getMarkStatus().equals(MarkStatus.KUNLIK_BAHO)){

            int activity = clampScore10(reqMarkDTO.getActivityScore(), "activityScore");
            int homework = clampScore10(reqMarkDTO.getHomeworkScore(), "homeworkScore");

            int score = (activity+ homework);
            mark.setStatus(reqMarkDTO.getMarkStatus());
            mark.setHomeworkScore(homework);
            mark.setActiveScore(activity);
            mark.setTotalScore(score);
            mark.setMarkCategoryStatus(markCategoryStatus(score));
            mark.setStudent(student);
        } else {
            mark.setStatus(reqMarkDTO.getMarkStatus());
            mark.setActiveScore(null);
            mark.setHomeworkScore(null);
            mark.setTotalScore(clampTotal10(reqMarkDTO.getTotalScore()));
            mark.setStudent(student);
            mark.setMarkCategoryStatus(markCategoryStatus(reqMarkDTO.getTotalScore()));
        }
        applyCoinDiff(oldTotal, mark.getTotalScore(), student);

        markRepository.save(mark);
        return ApiResponse.success(null, "Success");
    }



    public ApiResponse<String> deleteMark(CustomUserDetails current, Long markId){
        Mark mark = markRepository.findById(markId).orElseThrow(
                () -> new DataNotFoundException("Mark not found"));
        assertTeacherOwnsStudent(current, mark.getStudent());

        mark.setActive(false);
        markRepository.save(mark);
        return ApiResponse.success(null, "Success");
    }




    public ApiResponse<ResPageable> getAllMarkForAdmin(CustomUserDetails current, String keyword, Long groupId, int page, int size){
        if (current == null || !(Role.ROLE_ADMIN.name().equals(current.getRole())
                || Role.ROLE_SUPER_ADMIN.name().equals(current.getRole()))) {
            throw new org.springframework.security.access.AccessDeniedException("Bu guruh baholarini ko‘rishga ruxsat yo‘q");
        }

        Page<Mark> markPage = markRepository.findAllMark(keyword, groupId, PageRequest.of(page, size));

        isFoundMark(markPage.getTotalElements());

        List<ResMark> marks = markPage.getContent()
                .stream()
                .map(markMapper::toMarkDTO)
                .toList();

        ResPageable resPageable = ResPageable.builder()
                .page(page)
                .size(size)
                .totalElements(markPage.getTotalElements())
                .totalPage(markPage.getTotalPages())
                .body(marks)
                .build();

        return ApiResponse.success(resPageable, "Success");
    }



    public ApiResponse<ResPageable> getMyMarks(CustomUserDetails customUserDetails, PeriodFilter filter, int page, int size){
        Page<Mark> markPage;
        PageRequest pageRequest = PageRequest.of(page, size);

        LocalDate now = LocalDate.now();
        LocalDate startDate;
        LocalDate endDate;

        switch (filter) {

            case DAY:
                startDate = now;
                endDate = now;
                break;

            case WEEKLY:
                startDate = now.with(DayOfWeek.MONDAY);
                endDate = startDate.plusDays(6);
                break;

            case MONTH:
                startDate = now.withDayOfMonth(1);
                endDate = now.withDayOfMonth(now.lengthOfMonth());
                break;

            case YEAR:
                startDate = now.withDayOfYear(1);
                endDate = now.withDayOfYear(now.lengthOfYear());
                break;

            default:
                throw new IllegalArgumentException("Invalid filter");
        }

        if (customUserDetails.getRole().equals(Role.ROLE_TEACHER.name())) {

            userRepository.findByPhoneAndActiveTrue(customUserDetails.getPhone())
                    .orElseThrow(() -> new DataNotFoundException("Teacher not found"));

            String createdBy = customUserDetails.getPhone();

            markPage = markRepository
                    .findAllByCreatedByAndDateBetweenAndActiveTrue(
                            createdBy,
                            startDate,
                            endDate,
                            pageRequest
                    );

        } else if (customUserDetails.getRole().equals(Role.ROLE_SUPER_ADMIN.name())) {

            markPage = markRepository
                    .findAllByDateBetweenAndActiveTrue(
                            startDate,
                            endDate,
                            pageRequest
                    );

        } else {

            Student student = studentRepository
                    .findByPhone(customUserDetails.getPhone())
                    .orElseThrow(() -> new DataNotFoundException("Student not found"));

            markPage = markRepository
                    .findAllByStudentIdAndDateBetweenAndActiveTrue(
                            student.getId(),
                            startDate,
                            endDate,
                            pageRequest
                    );
        }

        isFoundMark(markPage.getTotalElements());

        List<ResMark> marks = markPage.getContent()
                .stream()
                .map(markMapper::toDTO)
                .toList();

        ResPageable resPageable = ResPageable.builder()
                .page(page)
                .size(size)
                .totalElements(markPage.getTotalElements())
                .totalPage(markPage.getTotalPages())
                .body(marks)
                .build();
        return ApiResponse.success(resPageable, "Success");

    }

    public ApiResponse<ResPageable> getGroupByArchiveMarks(CustomUserDetails cud,Long groupId, String keyword, int page, int size){
        PageRequest pr = PageRequest.of(page, size);

        String createdBy = null;

        if (cud.getRole().equals(Role.ROLE_TEACHER.name())) {
            userRepository.findByPhoneAndActiveTrue(cud.getPhone())
                    .orElseThrow(() -> new DataNotFoundException("Teacher not found"));
            createdBy = cud.getPhone();
        } else if (!cud.getRole().equals(Role.ROLE_SUPER_ADMIN.name())) {
            throw new BadRequestException("Ruxsat yo'q");
        }

        LocalDate today = LocalDate.now();

        Page<Mark> markPage = markRepository.findArchiveMarksByGroup(
                groupId, today, keyword, createdBy, pr);

        isFoundMark(markPage.getTotalElements());

        List<ResMark> body = markPage.getContent()
                .stream()
                .map(markMapper::toMarkDTO)
                .toList();

        ResPageable res = ResPageable.builder()
                .page(page)
                .size(size)
                .totalElements(markPage.getTotalElements())
                .totalPage(markPage.getTotalPages())
                .body(body)
                .build();

        return ApiResponse.success(res, "Success");
    }



    public ApiResponse<ResMark> getOneMark(CustomUserDetails current, Long markId){
        Mark mark = markRepository.findById(markId).orElseThrow(
                () -> new DataNotFoundException("Mark not found")
        );
        assertCanReadMark(current, mark);

        return ApiResponse.success(markMapper.toFullDTO(mark), "Success");
    }

    private void assertCanReadMark(CustomUserDetails current, Mark mark) {
        String role = current.getRole();
        if (Role.ROLE_ADMIN.name().equals(role) || Role.ROLE_SUPER_ADMIN.name().equals(role)) return;

        if (Role.ROLE_TEACHER.name().equals(role)
                && current.getUser() != null
                && mark.getStudent() != null
                && mark.getStudent().getGroup() != null
                && mark.getStudent().getGroup().getTeacher() != null
                && current.getUser().getId() != null
                && current.getUser().getId().equals(mark.getStudent().getGroup().getTeacher().getId())) return;

        Student student = mark.getStudent();
        if ("ROLE_STUDENT".equals(role)
                && student != null
                && current.getStudent() != null
                && student.getId().equals(current.getStudent().getId())) return;

        if (Role.ROLE_PARENT.name().equals(role)
                && student != null
                && student.getParent() != null
                && current.getUser() != null
                && student.getParent().getId().equals(current.getUser().getId())) return;

        throw new org.springframework.security.access.AccessDeniedException("Bu baho yozuviga kirish taqiqlangan");
    }

    private void assertTeacherOwnsStudent(CustomUserDetails current, Student student) {
        if (current == null || student == null || !Role.ROLE_TEACHER.name().equals(current.getRole())
                || current.getUser() == null || current.getUser().getId() == null
                || student.getGroup() == null || student.getGroup().getTeacher() == null
                || !current.getUser().getId().equals(student.getGroup().getTeacher().getId())) {
            throw new org.springframework.security.access.AccessDeniedException("Teacher faqat o‘z guruhidagi student bahosini boshqarishi mumkin");
        }
    }




    private void plusCoin(int score, Student student){
        int add = 0;

        if (score == 5) {
            add = 3;
        } else if (score == 4) {
            add = 2;
        } else if (score == 3) {
            add = 1;
        }

        if (add > 0) {
            student.setCoin(student.getCoin() + add);
            studentRepository.save(student);
        }
    }



    private MarkCategoryStatus markCategoryStatus(int score){
        if (score >= 8) {
            return MarkCategoryStatus.YASHIL;
        } else if (score >= 4 || score == 3) {
            return MarkCategoryStatus.SARIQ;
        } else {
            return MarkCategoryStatus.QIZIL;
        }
    }


    private void isFoundMark(long totalMark){
        if (totalMark == 0){
            ApiResponse.error("Mark not found");
        }
    }

    private int clampScore10(Integer score, String field) {
        if (score == null) throw new IllegalArgumentException(field + " is required");
        if (score < 0 || score > 5) {
            throw new IllegalArgumentException(field + " must be between 0 and 5");
        }
        return score;
    }

    private int clampTotal10(Integer total) {
        if (total == null) throw new IllegalArgumentException("totalScore is required");
        if (total < 0 || total > 100) {
            throw new IllegalArgumentException("totalScore must be between 0 and 5");
        }
        return total;
    }

    private void applyCoinDiff(Integer oldScore, Integer newScore, Student student) {
        int oldVal = oldScore == null ? 0 : oldScore;
        int newVal = newScore == null ? 0 : newScore;

        int diff = newVal - oldVal;
        if (diff != 0) {
            student.setCoin(student.getCoin() + diff);
            studentRepository.save(student);
        }
    }


}
