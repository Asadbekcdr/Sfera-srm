package sfera.crmsfera.controller;

import sfera.crmsfera.dto.ApiResponse;
import sfera.crmsfera.dto.AttendanceDto;
import sfera.crmsfera.dto.request.ReqAttendanceBulk;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;
import sfera.crmsfera.service.AttendanceService;
import sfera.crmsfera.security.CustomUserDetails;

import java.util.List;

@RestController
@RequestMapping("/attendance")
@RequiredArgsConstructor
public class AttendanceController {
    private final AttendanceService attendanceService;

    @PostMapping
    @PreAuthorize("hasAnyRole('ROLE_TEACHER','ROLE_ADMIN','ROLE_SUPER_ADMIN')")
    @Operation(summary = "Guruh buyicha davomat qilish",
            description = "AttendanceEnum -> KELDI, KELMADI, SABABLI \n " +
                    "Keldi bulsa status description null buladi, aks holda desciption yoziladi")
    public ResponseEntity<ApiResponse<String>> saveAttendance(@AuthenticationPrincipal CustomUserDetails current,
                                                              @RequestParam Long groupId,
                                                              @RequestBody List<AttendanceDto> attendanceDtoList) {
        return ResponseEntity.ok(attendanceService.saveAttendance(current, groupId, attendanceDtoList));
    }

    @PostMapping("/bulk")
    @PreAuthorize("hasAnyRole('ROLE_TEACHER','ROLE_ADMIN','ROLE_SUPER_ADMIN')")
    public ResponseEntity<ApiResponse<String>> saveAttendanceBulk(@AuthenticationPrincipal CustomUserDetails current,
                                                                  @RequestBody ReqAttendanceBulk request) {
        if (request.getGroupId() == null || request.getSessionDate() == null
                || request.getRecords() == null || request.getRecords().isEmpty()) {
            throw new sfera.crmsfera.exception.BadRequestException("groupId, sessionDate va records talab qilinadi");
        }
        List<AttendanceDto> records = request.getRecords().stream().map(record -> {
            record.setDate(request.getSessionDate());
            return record;
        }).toList();
        return ResponseEntity.ok(attendanceService.saveAttendance(current, request.getGroupId(), records));
    }


    @DeleteMapping("/attendanceId")
    @PreAuthorize("hasAnyRole('ROLE_TEACHER','ROLE_ADMIN','ROLE_SUPER_ADMIN')")
    public ResponseEntity<ApiResponse<String>> deleteAttendance(@AuthenticationPrincipal CustomUserDetails current, @RequestParam Long attendanceId) {
        return ResponseEntity.ok(attendanceService.deleteAttendance(current, attendanceId));
    }



    @GetMapping("/{attendanceId}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<AttendanceDto>> getAttendance(@AuthenticationPrincipal CustomUserDetails current,
                                                                     @PathVariable Long attendanceId) {
        return ResponseEntity.ok(attendanceService.getAttendance(current, attendanceId));
    }


    @GetMapping("/stream/{groupId}")
    @PreAuthorize("hasAnyRole('ROLE_TEACHER','ROLE_ADMIN','ROLE_SUPER_ADMIN','ROLE_STUDENT')")
    public SseEmitter stream(@AuthenticationPrincipal CustomUserDetails current, @PathVariable Long groupId) {
        attendanceService.assertCanReadGroup(current, groupId);
        SseEmitter emitter = attendanceService.subscribe(groupId);

        try {
            // Dastlabki ma'lumotni yuboramiz
            emitter.send(
                    SseEmitter.event()
                            .name("attendance")
                            .data(attendanceService.getAllAttendanceByGroup(groupId))
            );
        } catch (Exception e) {
            emitter.completeWithError(e);
        }

        return emitter;
    }
}
