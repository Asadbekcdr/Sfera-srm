# Release evidence index

These are command outputs from the 2026-10-30 sandbox verification. `RELEASE_TEST_REPORT.md` records the exact results and explains intermediate failures that were corrected before the final runs.

- `frontend-install.log`, `tool-versions.txt`: lockfile install and tool versions.
- `frontend-typecheck.log`, `frontend-lint.log`, `frontend-full-test.log`, `frontend-build.log`: final frontend verification.
- `backend-compile.log`: Maven compile-only verification.
- `backend-fresh-migrations-test.log`: full tests against a newly created PostgreSQL database with Flyway V1–V3.
- `legacy-schema-import.log`, `backend-legacy-upgrade-test.log`: schema-only legacy fixture import and full Flyway baseline/upgrade tests.

Database usernames and URLs in logs identify disposable local test fixtures. No production credentials were used. The Maven JWT configuration used a test-only secret supplied through the process environment; it is not stored in this bundle.
