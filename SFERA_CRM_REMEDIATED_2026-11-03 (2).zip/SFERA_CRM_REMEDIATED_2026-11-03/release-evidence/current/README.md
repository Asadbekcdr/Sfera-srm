# Current verification evidence — 2026-11-03

This directory contains the raw output from final validation after the production backend-mode guard change. The source of truth for release status is the repository-root `CURRENT_REMEDIATION_STATUS_UZ.md`; status remains **BLOCKED**.

| Check | Command / environment | Result | Raw output |
|---|---|---:|---|
| Frontend browser suite | `pnpm test` (Chromium via Vitest) | 159 tests in 32 files passed; exit 0 | `frontend-test.log` |
| TypeScript | `pnpm exec tsc -b --pretty false` | exit 0 | `frontend-tsc.log` |
| Lint | `pnpm lint` | exit 0; 0 errors, 29 warnings | `frontend-lint.log` |
| Frontend production build | `pnpm build` | exit 0 | `frontend-build.log` |
| Backend suite with PostgreSQL | `./mvnw test` against fresh test-only PostgreSQL 16.15 database `sfera_ready_final_20261103` | 44 tests; 0 failures, 0 errors, 0 skipped; Flyway migrations V1–V3; BUILD SUCCESS | `backend-fresh-postgres-test.log` |

## Important scope limits

- The PostgreSQL database was test-only and must not be used as a production database. Fresh-schema migration and ORM boot were exercised; legacy populated database upgrade was not.
- No complete 7-role end-to-end/browser acceptance matrix or production deployment smoke test was run. Tenant isolation, full business workflows and external integrations remain incomplete; see `CURRENT_REMEDIATION_STATUS_UZ.md`.
- Backend output contains nonfatal warnings: a Flyway community metadata request returned HTTP 401 while Maven continued successfully; migration scripts skipped some already-existing objects with `IF NOT EXISTS`; Lombok builder/equals-hashCode, Mockito dynamic Java-agent, Hibernate/JPA and Spring Security configuration warnings remain. These do not change the reported test exit code, but are not represented as resolved.
- Frontend lint reports 29 warnings (and zero errors); those warnings have not been suppressed or counted as clean.
- The earlier failed attempts before the successful final run are disclosed in `CURRENT_REMEDIATION_STATUS_UZ.md` with their specific causes and resolutions. Final logs above show only the final successful reruns.
