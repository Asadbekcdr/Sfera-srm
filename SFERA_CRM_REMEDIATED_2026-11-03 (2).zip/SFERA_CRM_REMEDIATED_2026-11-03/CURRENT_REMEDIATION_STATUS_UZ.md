# SFERA CRM — одоогийн засварын төлөв (2026-11-03)

## Шийдвэр

**BLOCKED — production-д бэлэн гэж зарлахгүй.** Энэ багцад эх код дээр бодит өөрчлөлт хийж, шинээр нэмсэн security regression-үүдийг PostgreSQL-той бодит Spring context дээр ажиллуулсан. Гэвч academy/tenant тусгаарлалт, auth/session, finance ledger, сурагч/эцэг эхийн lifecycle, хэд хэдэн модуль хоорондын API интеграц зэрэг P0/P1 шаардлага үлдсэн тул бүрэн ашиглалтад бэлэн гэж дүгнэх үндэс байхгүй.

## Энэ удаа код дээр хэрэгжүүлсэн засвар

1. `AdminController`-ийн `/admin/**` унших, жагсаах, профайл шинэчлэх, устгах endpoint бүрт Admin/Super Admin authorization нэмэв. Admin үүсгэх endpoint-үүд өмнөх шигээ Super Admin-only хэвээр.
2. Method-security `AccessDeniedException`-ийг global handler буруу `500` болгож байсан. Одоо `403` болон тогтвортой `ApiResponse` буцаана; expected denial дээр stack trace бүрэн хэвлэхгүй.
3. Student жагсаалтын controller нь authenticated principal-ийг service рүү дамжуулдаг болов. Teacher-д pagination/search нь зөвхөн тухайн teacher-ийн group-уудыг SQL/JPA түвшинд шүүнэ; утасны дугаараар teacher хайлт/тоолох параметр хэрэглэхгүй. Teacher response-д сурагчийн болон эцэг эхийн утас, эцэг эхийн ID/нэр орохгүй. Admin/Super Admin-ын directory contract хэвээр.
4. Group detail/roster endpoint-ээс Student болон Parent role-уудыг хаав. Service давхар тухайн group-ийн teacher-ийг authenticated teacher-тэй тулган шалгана. Teacher зөвхөн өөрийн group-ийг үзэж, roster-ийн contact талбаруудыг багасгасан DTO авна; admin бүтэн DTO авна.
5. Maven wrapper-ийг архивт executable биш ирснийг засаж executable горимд оруулав (`backend/mvnw`, mode `0755`).
6. Нэмсэн regressions: Admin route role matrix, student directory scope/PII, group roster ownership, бодит PostgreSQL дээр teacher-scoped JPA query.
7. Frontend-ийн shared backend-mode guard production build-д үргэлж backend-ийг шаарддаг болгож, `VITE_API_ENABLED=false` тохиргоогоор production-д API-г унтрааж local/demo горимд шилжихийг хориглов. Үүнийг нотлох browser regression нэмэгдсэн. Энэ guard нь local/demo implementation бүхий бүх дэлгэцийг автоматаар API-д шилжүүлээгүй.

Эдгээр засвар нь **бүх tenant асуудлыг шийдээгүй**. Group ownership нь одоо teacher-ийн group холбоосоор scope хийнэ; academy_id/tenant model байхгүй тул academy хоорондын тусгаарлалтыг баталгаажуулах боломжгүй.

## Эцсийн туршилтын бодит үр дүн

Доорх нь энэ багцын код дээр 2026-11-03-нд дахин ажиллуулсан үр дүн. Raw лог файлууд `release-evidence/current/` дотор байна.

| Шалгалт | Бодит үр дүн | Тайлбар |
|---|---:|---|
| `pnpm test` | **159 PASS / 32 test files** | Chromium/Vitest browser suite |
| `pnpm exec tsc -b --pretty false` | **PASS, exit 0** | TypeScript project check |
| `pnpm lint` | **PASS, exit 0** | 0 error, 29 warning |
| `pnpm build` | **PASS, exit 0** | Frontend production bundle үүссэн |
| Backend `./mvnw test` | **44 PASS, 0 failure/error/skip** | Цоо шинэ, зөвхөн тестэд зориулсан PostgreSQL `sfera_ready_final_20261103` дээр; Flyway V1, V2, V3 амжилттай |
| Шинэ focused security regression-үүд | **15 PASS** | Admin, student directory, group ownership, Postgres query |

Test DB-д Flyway-ийн дараах амжилттай хувилбарууд шалгагдсан: `1`, `2`, `3`. Maven build амжилттай болсон боловч Flyway community metadata URL руу metadata fetch хийхэд 401 warning гарсан; мөн Lombok builder, Mockito dynamic Java agent, Hibernate/JPA болон Spring Security configuration warning-ууд үлдсэн. V2/V3 migration нь V1-д үүссэн зарим relation/column-ыг idempotent `IF NOT EXISTS`-ээр skip хийсэн тухай PostgreSQL warning гаргасан. Энэ нь production-shaped upgrade эсвэл tenant isolation test биш.

## Эхний оролдлогын алдааг нуусангүй

Final PASS-ээс өмнө дараах бодит алдаанууд гарсан бөгөөд log/report-д тэмдэглэв:

- Архивын `backend/mvnw` 0644 permission-тэй байсан тул шууд `./mvnw` эхний оролдлого `Permission denied` / exit 126 болсон. Executable bit-ийг сэргээж, дараагийн эцсийн backend suite-ийг шууд `./mvnw test` гэж амжилттай ажиллуулав.
- Эхний `@WebMvcTest` slice нь JWT dependency-гүйгээс context нээж чадаагүй. Туршилтыг зохиомлоор PASS болгоогүй; бодит Spring Boot security context-д шилжүүлэв.
- Бодит method-security test нь access denial response `403` бус `500` байсныг илрүүлсэн. Production exception handler-ийг зассаны дараа denial-ууд `403` болсон; эцсийн role matrix PASS.
- Эхний PostgreSQL ownership test fixture Lombok builder-ээр `active=false` үлдэж, query хоосон үр дүн өгсөн. Fixture-ийг active төлөвт оруулсны дараа бодит query test болон эцсийн backend suite PASS болсон.

Эдгээрийн эцсийн run-ууд амжилттай ч завсрын алдаа гарсныг санаатайгаар арилгаагүй. Эцсийн туршилтын raw логт command output, test totals, exit code хадгалагдсан.

## Үлдсэн P0/P1 blockers

### P0 — нээлттэй

- **Academy/tenant boundary байхгүй.** Одоогийн үндсэн `User`, `Student`, `Group` schema-д academy relation/id байхгүй. Finance, group, events, notifications болон бусад resource-уудад академиар баталгаатай шүүлт хэрэгжсэн гэж нотлох боломжгүй. Teacher-ийн student directory-г group-аар шүүсэн ч энэ нь academy тусгаарлалттай адил биш.
- **Student/Parent-ийн бүх өгөгдөлд эзэмшигчийн хамгаалалт бүрэн биш.** Энэ удаа student lists болон group detail засагдсан боловч бусад ID-based attendance/mark/notification/event/export/file болон санхүүгийн бүх замд academy болон эзэмшлийн бүрэн матриц ажиллуулаагүй.

### P1 — нээлттэй

- JWT browser JavaScript унших cookie-д хадгалагддаг; logout сервер талын token/session цуцлахгүй; password өөрчлөлтийн дараах өмнөх token invalidation, refresh/revocation, login throttling болон account enumeration хамгаалалт хийгдээгүй.
- Frontend Parent-ийг Student гэж map хийдэг; Clerk-ийн тусдаа route/provider Spring JWT-тай зэрэгцэж байна. Эцэг эх ба сурагчийн тусдаа, PostgreSQL-аас авдаг бүрэн портал, ownership E2E байхгүй.
- Lead/course/enrollment болон invoice/debtor endpoint-уудын заримыг frontend дуудаж байгаа ч backend contract алга. Каноник invoice/payment allocation/refund/reversal/receipt/reconciliation ledger байхгүй; төлбөрийн огноо, invoice ID, status/filter contract-ийн зөрүү үлдсэн.
- Student болон Course lifecycle-ийн browser-local storage / seeded data ажиллагаа, teacher assignment/submission/grade workflows-ийн PostgreSQL persistence, Manager-ийн бүрэн lead/group/course lifecycle бүрэн шийдэгдээгүй. API-mode screen бүрийн fake data/false success-ийг бүрэн цэвэрлээгүй.
- Attendance-д untouched сурагчдыг автоматаар absent болгох, `late`/`excused`-ийг нэг backend утгад нэгтгэх, bulk write atomicity ба duplicate constraint-ийн асуудлууд үлдсэн.
- Notification болон generic event/SSE delivery recipient/group/academy-аар бүрэн scope хийгдээгүй; protected file upload/download болон Telegram delivery active integration байхгүй; audit event coverage/scope дутуу.
- Acceptance шаардсан бүх 7 role-ийн backend+browser end-to-end workflow ажиллуулаагүй. Legacy schema upgrade, production deployment, CORS/preflight, real external notification providers, backup/restore, concurrency/load security тест энэ удаад BLOCKED/NOT RUN.

## Release gate

Энэ archive нь өмнөх SFERA код дээр засвар оруулсан, тесттэй **үргэлжлүүлсэн ажлын build** юм; нөлөөлөл нь бүгд арилсан эсвэл production-ready гэсэн утгагүй. P0/P1 асуудлууд бүрэн хаагдаж, tenant schema/authorization дизайн баталгаажиж, бүх role-ийн Postgres E2E ба API contract tests PASS болох хүртэл production-д гаргахгүй.
